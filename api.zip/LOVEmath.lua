---
-- Provides system-independent mathematical functions.
-- 
-- @module LOVEmath
-- 

---
-- Converts a color from gamma-space (sRGB) to linear-space (RGB). This is useful when doing gamma-correct rendering using colors created based on what they look like on-screen.
-- 
-- Gamma-space sRGB has more precision in the lower end than linear RGB. Using this function to convert from sRGB to RGB can result in non-integer color values, which get truncated to integers and lose precision when used with other functions such as love.graphics.setColor.
-- @function [parent = #LOVEmath] gammaToLinear
-- @param #number r The red channel of the sRGB color to convert.
-- @param #number g The green channel of the sRGB color to convert.
-- @param #number b The blue channel of the sRGB color to convert.
-- @return #number lr The red channel of the converted color in linear RGB space.
-- @return #number lg The green channel of the converted color in linear RGB space.
-- @return #number lb The blue channel of the converted color in linear RGB space.
-- 

---
-- Gets the seed of the random number generator.
-- 
-- The state is split into two numbers due to Lua's use of doubles for all number values - doubles can't accurately represent integer values above 2^53.
-- @function [parent = #LOVEmath] getRandomSeed
-- @return #number low Integer number representing the lower 32 bits of the random number generator's 64 bit state value.
-- @return #number high Integer number representing the higher 32 bits of the random number generator's 64 bit state value.
-- 

---
-- Gets the current state of the random number generator. This returns an opaque implementation-dependent string which is only useful for later use with RandomGenerator:setState.
-- 
-- This is different from RandomGenerator:getSeed in that getState gets the RandomGenerator's current state, whereas getSeed gets the previously set seed number.
-- 
-- The value of the state string does not depend on the current operating system.
-- @function [parent = #LOVEmath] getRandomState
-- @return #string state The current state of the RandomGenerator object, represented as a string.
-- 

---
-- Checks whether a polygon is convex.
-- 
-- PolygonShapes in love.physics, some forms of Mesh, and polygons drawn with love.graphics.polygon must be simple convex polygons.
-- @function [parent = #LOVEmath] isConvex
-- @param #table vertices The vertices of the polygon as a table in the form of {x1, y1, x2, y2, x3, y3, ...}.
-- @return #boolean convex Whether the given polygon is convex.
-- 

---
-- Converts a color from linear-space (RGB) to gamma-space (sRGB). This is useful when storing linear RGB color values in an image, because the linear RGB color space has less precision than sRGB for dark colors, which can result in noticeable color banding when drawing.
-- 
-- In general, colors chosen based on what they look like on-screen are already in gamma-space and should not be double-converted. Colors calculated using math are often in the linear RGB space.
-- @function [parent = #LOVEmath] linearToGamma
-- @param #number lr The red channel of the linear RGB color to convert.
-- @param #number lg The green channel of the linear RGB color to convert.
-- @param #number lb The blue channel of the linear RGB color to convert.
-- @return #number cr The red channel of the converted color in gamma sRGB space.
-- @return #number cg The green channel of the converted color in gamma sRGB space.
-- @return #number cb The blue channel of the converted color in gamma sRGB space.
-- 

---
-- Creates a new BezierCurve object.
-- 
-- The number of vertices in the control polygon determines the degree of the curve, e.g. three vertices define a quadratic (degree 2) Bézier curve, four vertices define a cubic (degree 3) Bézier curve, etc.
-- @function [parent = #LOVEmath] newBezierCurve
-- @param #table vertices The vertices of the control polygon as a table in the form of {x1, y1, x2, y2, x3, y3, ...}.
-- @return LOVEmath#BezierCurve curve A Bézier curve object.
-- 

---
-- Creates a new RandomGenerator object which is completely independent of other RandomGenerator objects and random functions.
-- @function [parent = #LOVEmath] newRandomGenerator
-- @return LOVEmath#RandomGenerator rng A Random Number Generator object.
-- 

---
-- Generates a Simplex noise value in 1-4 dimensions.
-- 
-- Simplex noise is closely related to Perlin noise. It is widely used for procedural content generation.
-- @function [parent = #LOVEmath] noise
-- @param #number x The number used to generate the noise value.
-- @return #number value The noise value in the range of [0, 1].
-- 

---
-- Generates a pseudo random number in a platform independent way.
-- @function [parent = #LOVEmath] random
-- @return #number number The pseudo random number.
-- 

---
-- Get a normally distributed pseudo random number.
-- @function [parent = #LOVEmath] randomNormal
-- @param #number stddev Standard deviation of the distribution.
-- @param #number mean The mean of the distribution.
-- @return #number number Normally distributed random number with variance (stddev)² and the specified mean.
-- 

---
-- Sets the seed of the random number generator using the specified integer number.
-- @function [parent = #LOVEmath] setRandomSeed
-- @param #number seed The integer number with which you want to seed the randomization. Must be within the range of [1, 2^53].
-- 

---
-- Gets the current state of the random number generator. This returns an opaque implementation-dependent string which is only useful for later use with RandomGenerator:setState.
-- 
-- This is different from RandomGenerator:getSeed in that getState gets the RandomGenerator's current state, whereas getSeed gets the previously set seed number.
-- 
-- The value of the state string does not depend on the current operating system.
-- @function [parent = #LOVEmath] setRandomState
-- @param #string state The current state of the RandomGenerator object, represented as a string.
-- 

---
-- Triangulate a simple polygon.
-- @function [parent = #LOVEmath] triangulate
-- @param #table polygon Polygon to triangulate. Must not intersect itself.
-- @return #table triangles List of triangles the polygon is composed of, in the form of {{x1, y1, x2, y2, x3, y3}, {x1, y1, x2, y2, x3, y3}, ...}.
-- 


return nil
