--------------------------------------------------------------------------------
-- Provides system-independent mathematical functions.
-- 
-- @module LOVEmath
-- 

-------------------------------------------------------------------------------
-- A Bézier curve object that can evaluate and render Bézier curves of arbitrary degree.
-- @type BezierCurve
-- @extends love#Object

-------------------------------------------------------------------------------
-- Evaluate Bézier curve at parameter t. The parameter must be between 0 and 1 (inclusive).
-- 
-- This function can be used to move objects along paths or tween parameters. However it should not be used to render the curve, see BezierCurve:render for that purpose.
-- @function[parent=#BezierCurve] evalulate
-- @param self self 
-- @param #number t Where to evaluate the curve.
-- @return #number x x coordinate of the curve at parameter t.
-- @return #number y y coordinate of the curve at parameter t.
-- 

-------------------------------------------------------------------------------
-- Get coordinates of the i-th control point. Indices start with 1.
-- @function[parent=#BezierCurve] getControlPoint
-- @param self self 
-- @param #number i Index of the control point.
-- @return #number x Position of the control point along the x axis.
-- @return #number y Position of the control point along the y axis.
-- 

-------------------------------------------------------------------------------
-- Get the number of control points in the Bézier curve.
-- @function[parent=#BezierCurve] getControlPointCount
-- @param self self 
-- @return #number count The number of control points.
-- 

-------------------------------------------------------------------------------
-- Get degree of the Bézier curve. The degree is equal to number-of-control-points - 1.
-- @function[parent=#BezierCurve] getDegree
-- @param self self 
-- @return #number degree Degree of the Bézier curve.
-- 

-------------------------------------------------------------------------------
-- Get the derivative of the Bézier curve.
-- 
-- This function can be used to rotate sprites moving along a curve in the direction of the movement and compute the direction perpendicular to the curve at some parameter t.
-- @function[parent=#BezierCurve] getDerivative
-- @param self self 
-- @return LOVEmath#BezierCurve derivative The derivative curve.
-- 

-------------------------------------------------------------------------------
-- Gets a BezierCurve that corresponds to the specified segment of this BezierCurve.
-- @function[parent=#BezierCurve] getSegment
-- @param self self 
-- @param #number startpoint The starting point along the curve. Must be between 0 and 1.
-- @param #number endpoint The end of the segment. Must be between 0 and 1.
-- @return LOVEmath#BezierCurve curve A BezierCurve that corresponds to the specified segment.
-- 

-------------------------------------------------------------------------------
-- Insert control point after the i-th control point. Indices start with 1. Negative indices wrap around: -1 is the last control point, -2 the one before the last, etc.
-- @function[parent=#BezierCurve] insertControlPoint
-- @param self self 
-- @param #number x Position of the control point along the x axis.
-- @param #number y Position of the control point along the y axis.
-- @param #number i Index of the control point.
-- 

-------------------------------------------------------------------------------
-- Removes the specified control point.
-- @function[parent=#BezierCurve] removeControlPoint
-- @param self self 
-- @param #number index The index of the control point to remove.
-- 

-------------------------------------------------------------------------------
-- Get a list of coordinates to be used with love.graphics.line.
-- 
-- This function samples the Bézier curve using recursive subdivision. You can control the recursion depth using the depth parameter.
-- 
-- If you are just interested to know the position on the curve given a parameter, use BezierCurve:evalulate.
-- @function[parent=#BezierCurve] render
-- @param self self 
-- @param #number depth Number of recursive subdivision steps.
-- @return #table coordinates List of x,y-coordinate pairs of points on the curve.
-- 

-------------------------------------------------------------------------------
-- Get a list of coordinates on a specific part of the curve, to be used with love.graphics.line.
-- 
-- This function samples the Bézier curve using recursive subdivision. You can control the recursion depth using the depth parameter.
-- 
-- If you are just need to know the position on the curve given a parameter, use BezierCurve:evaluate.
-- @function[parent=#BezierCurve] renderSegment
-- @param self self 
-- @param #number startpoint The starting point along the curve. Must be between 0 and 1.
-- @param #number endpoint The end of the segment to render. Must be between 0 and 1.
-- @param #number depth Number of recursive subdivision steps.
-- @return #table coordinates List of x,y-coordinate pairs of points on the curve.
-- 

-------------------------------------------------------------------------------
-- Rotate the Bézier curve by an angle.
-- @function[parent=#BezierCurve] rotate
-- @param self self 
-- @param #number angle Rotation angle in radians.
-- @param #number ox X coordinate of the rotation center.
-- @param #number oy Y coordinate of the rotation center.
-- 

-------------------------------------------------------------------------------
-- Scale the Bézier curve by a factor.
-- @function[parent=#BezierCurve] scale
-- @param self self 
-- @param #number s Scale factor.
-- @param #number ox X coordinate of the scaling center.
-- @param #number oy Y coordinate of the scaling center.
-- 

-------------------------------------------------------------------------------
-- Set coordinates of the i-th control point. Indices start with 1.
-- @function[parent=#BezierCurve] setControlPoint
-- @param self self 
-- @param #number i Index of the control point.
-- @param #number ox Position of the control point along the x axis.
-- @param #number oy Position of the control point along the y axis.
-- 

-------------------------------------------------------------------------------
-- Move the Bézier curve by an offset.
-- @function[parent=#BezierCurve] translate
-- @param self self 
-- @param #number dx Offset along the x axis.
-- @param #number dy Offset along the y axis.
-- 


-------------------------------------------------------------------------------
-- Represents byte data compressed using a specific algorithm.
-- 
-- love.math.decompress can be used to de-compress the data.
-- @type CompressedData
-- @extends love#Data
-- @extends love#Object

-------------------------------------------------------------------------------
-- Gets the compression format of the CompressedData.
-- @function[parent=#CompressedData] getFormat
-- @param self self 
-- @return LOVEmath#CompressedDataFormat format The format of the CompressedData.
-- 


-------------------------------------------------------------------------------
-- A random number generation object which has its own random state.
-- @type RandomGenerator
-- @extends love#Object

-------------------------------------------------------------------------------
-- Gets the state of the random number generator.
-- 
-- The state is split into two numbers due to Lua's use of doubles for all number values - doubles can't accurately represent integer values above 2^53.
-- @function[parent=#RandomGenerator] getSeed
-- @param self self 
-- @return #number low Integer number representing the lower 32 bits of the random number generator's 64 bit state value.
-- @return #number high Integer number representing the higher 32 bits of the random number generator's 64 bit state value.
-- 

-------------------------------------------------------------------------------
-- Gets the current state of the random number generator. This returns an opaque implementation-dependent string which is only useful for later use with RandomGenerator:setState.
-- 
-- This is different from RandomGenerator:getSeed in that getState gets the RandomGenerator's current state, whereas getSeed gets the previously set seed number.
-- 
-- The value of the state string does not depend on the current operating system.
-- @function[parent=#RandomGenerator] getState
-- @param self self 
-- @return #string state The current state of the RandomGenerator object, represented as a string.
-- 

-------------------------------------------------------------------------------
-- Generates a pseudo-random number in a platform independent manner.
-- @function[parent=#RandomGenerator] random
-- @param self self 
-- @return #number number The pseudo random number.
-- 

-------------------------------------------------------------------------------
-- Generates a pseudo-random number in a platform independent manner.
-- @function[parent=#RandomGenerator] random
-- @param self self 
-- @param #number max The maximum possible value it should return.
-- @return #number number The pseudo-random integer number.
-- 

-------------------------------------------------------------------------------
-- Generates a pseudo-random number in a platform independent manner.
-- @function[parent=#RandomGenerator] random
-- @param self self 
-- @param #number min The minimum possible value it should return.
-- @param #number max The maximum possible value it should return.
-- @return #number number The pseudo-random integer number.
-- 

-------------------------------------------------------------------------------
-- Get a normally distributed pseudo random number.
-- @function[parent=#RandomGenerator] randomNormal
-- @param self self 
-- @param #number stddev Standard deviation of the distribution.
-- @param #number mean The mean of the distribution.
-- @return #number number Normally distributed random number with variance (stddev)² and the specified mean.
-- 

-------------------------------------------------------------------------------
-- Sets the seed of the random number generator using the specified integer number.
-- @function[parent=#RandomGenerator] setSeed
-- @param self self 
-- @param #number seed The integer number with which you want to seed the randomization. Must be within the range of [1, 2^53].
-- 

-------------------------------------------------------------------------------
-- Sets the seed of the random number generator using the specified integer number.
-- @function[parent=#RandomGenerator] setSeed
-- @param self self 
-- @param #number low The lower 32 bits of the state value. Must be within the range of [0, 2^32 - 1].
-- @param #number high The higher 32 bits of the state value. Must be within the range of [0, 2^32 - 1].
-- 

-------------------------------------------------------------------------------
-- Sets the current state of the random number generator. The value used as an argument for this function is an opaque implementation-dependent string and should only originate from a previous call to RandomGenerator:getState.
-- 
-- This is different from RandomGenerator:setSeed in that setState directly sets the RandomGenerator's current implementation-dependent state, whereas setSeed gives it a new seed value.
-- 
-- The effect of the state string does not depend on the current operating system.
-- @function[parent=#RandomGenerator] setState
-- @param self self 
-- @param #string state The new state of the RandomGenerator object, represented as a string. This should originate from a previous call to RandomGenerator:getState.
-- 


-------------------------------------------------------------------------------
-- Compresses a string or data using a specific compression algorithm.
-- @function[parent=#LOVEmath] compress
-- @param #string rawstring The raw (un-compressed) string to compress.
-- @param LOVEmath#CompressedDataFormat format The format to use when compressing the string.
-- @param #number level The level of compression to use, between 0 and 9. -1 indicates the default level. The meaning of this argument depends on the compression format being used.
-- @return LOVEmath#CompressedData compressedData A new Data object containing the compressed version of the string.
-- 

-------------------------------------------------------------------------------
-- Compresses a string or data using a specific compression algorithm.
-- @function[parent=#LOVEmath] compress
-- @param love#Data data A Data object containing the raw (un-compressed) data to compress.
-- @param LOVEmath#CompressedDataFormat format The format to use when compressing the data.
-- @param #number level The level of compression to use, between 0 and 9. -1 indicates the default level. The meaning of this argument depends on the compression format being used.
-- @return LOVEmath#CompressedData compressedData A new Data object containing the compressed version of the raw data.
-- 

-------------------------------------------------------------------------------
-- Decompresses a CompressedData or previously compressed string or Data object.
-- @function[parent=#LOVEmath] decompress
-- @param LOVEmath#CompressedData compressedData The compressed data to decompress.
-- @return #string rawstring A string containing the raw decompressed data.
-- 

-------------------------------------------------------------------------------
-- Decompresses a CompressedData or previously compressed string or Data object.
-- @function[parent=#LOVEmath] decompress
-- @param #string compressedString A string containing data previously compressed with love.math.compress.
-- @param LOVEmath#CompressedDataFormat format The format that was used to compress the given string.
-- @return #string rawstring A string containing the raw decompressed data.
-- 

-------------------------------------------------------------------------------
-- Decompresses a CompressedData or previously compressed string or Data object.
-- @function[parent=#LOVEmath] decompress
-- @param love#Data data A Data object containing data previously compressed with love.math.compress.
-- @param LOVEmath#CompressedDataFormat format The format that was used to compress the given data.
-- @return #string rawstring A string containing the raw decompressed data.
-- 

-------------------------------------------------------------------------------
-- Converts a color from gamma-space (sRGB) to linear-space (RGB). This is useful when doing gamma-correct rendering and you need to do math in linear RGB in the few cases where LÖVE doesn't handle conversions automatically.
-- @function[parent=#LOVEmath] gammaToLinear
-- @param #number r The red channel of the sRGB color to convert.
-- @param #number g The green channel of the sRGB color to convert.
-- @param #number b The blue channel of the sRGB color to convert.
-- @return #number lr The red channel of the converted color in linear RGB space.
-- @return #number lg The green channel of the converted color in linear RGB space.
-- @return #number lb The blue channel of the converted color in linear RGB space.
-- 

-------------------------------------------------------------------------------
-- Converts a color from gamma-space (sRGB) to linear-space (RGB). This is useful when doing gamma-correct rendering and you need to do math in linear RGB in the few cases where LÖVE doesn't handle conversions automatically.
-- @function[parent=#LOVEmath] gammaToLinear
-- @param #table color An array with the red, green, and blue channels of the sRGB color to convert.
-- @return #number lr The red channel of the converted color in linear RGB space.
-- @return #number lg The green channel of the converted color in linear RGB space.
-- @return #number lb The blue channel of the converted color in linear RGB space.
-- 

-------------------------------------------------------------------------------
-- Converts a color from gamma-space (sRGB) to linear-space (RGB). This is useful when doing gamma-correct rendering and you need to do math in linear RGB in the few cases where LÖVE doesn't handle conversions automatically.
-- @function[parent=#LOVEmath] gammaToLinear
-- @param #number c The value of a color channel in sRGB space to convert.
-- @return #number lc The value of the color channel in linear RGB space.
-- 

-------------------------------------------------------------------------------
-- Gets the seed of the random number generator.
-- 
-- The state is split into two numbers due to Lua's use of doubles for all number values - doubles can't accurately represent integer values above 2^53.
-- @function[parent=#LOVEmath] getRandomSeed
-- @return #number low Integer number representing the lower 32 bits of the random number generator's 64 bit state value.
-- @return #number high Integer number representing the higher 32 bits of the random number generator's 64 bit state value.
-- 

-------------------------------------------------------------------------------
-- Gets the current state of the random number generator. This returns an opaque implementation-dependent string which is only useful for later use with RandomGenerator:setState.
-- 
-- This is different from RandomGenerator:getSeed in that getState gets the RandomGenerator's current state, whereas getSeed gets the previously set seed number.
-- 
-- The value of the state string does not depend on the current operating system.
-- @function[parent=#LOVEmath] getRandomState
-- @return #string state The current state of the RandomGenerator object, represented as a string.
-- 

-------------------------------------------------------------------------------
-- Checks whether a polygon is convex.
-- 
-- PolygonShapes in love.physics, some forms of Mesh, and polygons drawn with love.graphics.polygon must be simple convex polygons.
-- @function[parent=#LOVEmath] isConvex
-- @param #table vertices The vertices of the polygon as a table in the form of {x1, y1, x2, y2, x3, y3, ...}.
-- @return #boolean convex Whether the given polygon is convex.
-- 

-------------------------------------------------------------------------------
-- Checks whether a polygon is convex.
-- 
-- PolygonShapes in love.physics, some forms of Mesh, and polygons drawn with love.graphics.polygon must be simple convex polygons.
-- @function[parent=#LOVEmath] isConvex
-- @param #number x1 The position of the first vertex of the polygon on the x-axis.
-- @param #number y1 The position of the first vertex of the polygon on the y-axis.
-- @param #number x2 The position of the second vertex of the polygon on the x-axis.
-- @param #number y2 The position of the second vertex of the polygon on the y-axis.
-- @param #number x3 The position of the third vertex of the polygon on the x-axis.
-- @param #number y3 The position of the third vertex of the polygon on the y-axis.
-- @param #number ... Additional vertices.
-- @return #boolean convex Whether the given polygon is convex.
-- 

-------------------------------------------------------------------------------
-- Converts a color from linear-space (RGB) to gamma-space (sRGB). This is useful when storing linear RGB color values in an image, because the linear RGB color space has less precision than sRGB for dark colors, which can result in noticeable color banding when drawing.
-- 
-- In general, colors chosen based on what they look like on-screen are already in gamma-space and should not be double-converted. Colors calculated using math are often in the linear RGB space.
-- @function[parent=#LOVEmath] linearToGamma
-- @param #number lr The red channel of the linear RGB color to convert.
-- @param #number lg The green channel of the linear RGB color to convert.
-- @param #number lb The blue channel of the linear RGB color to convert.
-- @return #number cr The red channel of the converted color in gamma sRGB space.
-- @return #number cg The green channel of the converted color in gamma sRGB space.
-- @return #number cb The blue channel of the converted color in gamma sRGB space.
-- 

-------------------------------------------------------------------------------
-- Converts a color from linear-space (RGB) to gamma-space (sRGB). This is useful when storing linear RGB color values in an image, because the linear RGB color space has less precision than sRGB for dark colors, which can result in noticeable color banding when drawing.
-- 
-- In general, colors chosen based on what they look like on-screen are already in gamma-space and should not be double-converted. Colors calculated using math are often in the linear RGB space.
-- @function[parent=#LOVEmath] linearToGamma
-- @param #table color An array with the red, green, and blue channels of the linear RGB color to convert.
-- @return #number cr The red channel of the converted color in gamma sRGB space.
-- @return #number cg The green channel of the converted color in gamma sRGB space.
-- @return #number cb The blue channel of the converted color in gamma sRGB space.
-- 

-------------------------------------------------------------------------------
-- Converts a color from linear-space (RGB) to gamma-space (sRGB). This is useful when storing linear RGB color values in an image, because the linear RGB color space has less precision than sRGB for dark colors, which can result in noticeable color banding when drawing.
-- 
-- In general, colors chosen based on what they look like on-screen are already in gamma-space and should not be double-converted. Colors calculated using math are often in the linear RGB space.
-- @function[parent=#LOVEmath] linearToGamma
-- @param #number lc The value of a color channel in linear RGB space to convert.
-- @return #number c The value of the color channel in gamma sRGB space.
-- 

-------------------------------------------------------------------------------
-- Creates a new BezierCurve object.
-- 
-- The number of vertices in the control polygon determines the degree of the curve, e.g. three vertices define a quadratic (degree 2) Bézier curve, four vertices define a cubic (degree 3) Bézier curve, etc.
-- @function[parent=#LOVEmath] newBezierCurve
-- @param #table vertices The vertices of the control polygon as a table in the form of {x1, y1, x2, y2, x3, y3, ...}.
-- @return LOVEmath#BezierCurve curve A Bézier curve object.
-- 

-------------------------------------------------------------------------------
-- Creates a new BezierCurve object.
-- 
-- The number of vertices in the control polygon determines the degree of the curve, e.g. three vertices define a quadratic (degree 2) Bézier curve, four vertices define a cubic (degree 3) Bézier curve, etc.
-- @function[parent=#LOVEmath] newBezierCurve
-- @param #number x1 The position of the first vertex of the control polygon on the x-axis.
-- @param #number y1 The position of the first vertex of the control polygon on the y-axis.
-- @param #number x2 The position of the second vertex of the control polygon on the x-axis.
-- @param #number y2 The position of the second vertex of the control polygon on the y-axis.
-- @param #number x3 The position of the third vertex of the control polygon on the x-axis.
-- @param #number y3 The position of the third vertex of the control polygon on the y-axis.
-- @param #number ... Additional vertices.
-- @return LOVEmath#BezierCurve curve A Bézier curve object.
-- 

-------------------------------------------------------------------------------
-- Creates a new RandomGenerator object which is completely independent of other RandomGenerator objects and random functions.
-- @function[parent=#LOVEmath] newRandomGenerator
-- @return LOVEmath#RandomGenerator rng A Random Number Generator object.
-- 

-------------------------------------------------------------------------------
-- Creates a new RandomGenerator object which is completely independent of other RandomGenerator objects and random functions.
-- @function[parent=#LOVEmath] newRandomGenerator
-- @param #number low The lower 32 bits of the state number to use for this instance of the object.
-- @param #number high The higher 32 bits of the state number to use for this instance of the object.
-- @return LOVEmath#RandomGenerator rng A Random Number Generator object.
-- 

-------------------------------------------------------------------------------
-- Creates a new RandomGenerator object which is completely independent of other RandomGenerator objects and random functions.
-- @function[parent=#LOVEmath] newRandomGenerator
-- @param #string seed A state of a RandomGenerator object returned by RandomGenerator:getState.
-- @return LOVEmath#RandomGenerator rng A Random Number Generator object.
-- 

-------------------------------------------------------------------------------
-- Generates a Simplex or Perlin noise value in 1-4 dimensions.
-- 
-- Simplex noise is closely related to Perlin noise. It is widely used for procedural content generation.
-- 
-- There are many webpages which discuss Perlin and Simplex noise in detail.
-- @function[parent=#LOVEmath] noise
-- @param #number x The number used to generate the noise value.
-- @return #number value The noise value in the range of [0, 1].
-- 

-------------------------------------------------------------------------------
-- Generates a Simplex or Perlin noise value in 1-4 dimensions.
-- 
-- Simplex noise is closely related to Perlin noise. It is widely used for procedural content generation.
-- 
-- There are many webpages which discuss Perlin and Simplex noise in detail.
-- @function[parent=#LOVEmath] noise
-- @param #number x The first value of the 2-dimensional vector used to generate the noise value.
-- @param #number y The second value of the 2-dimensional vector used to generate the noise value.
-- @return #number value The noise value in the range of [0, 1].
-- 

-------------------------------------------------------------------------------
-- Generates a Simplex or Perlin noise value in 1-4 dimensions.
-- 
-- Simplex noise is closely related to Perlin noise. It is widely used for procedural content generation.
-- 
-- There are many webpages which discuss Perlin and Simplex noise in detail.
-- @function[parent=#LOVEmath] noise
-- @param #number x The first value of the 3-dimensional vector used to generate the noise value.
-- @param #number y The second value of the 3-dimensional vector used to generate the noise value.
-- @param #number z The third value of the 3-dimensional vector used to generate the noise value.
-- @return #number value The noise value in the range of [0, 1].
-- 

-------------------------------------------------------------------------------
-- Generates a Simplex or Perlin noise value in 1-4 dimensions.
-- 
-- Simplex noise is closely related to Perlin noise. It is widely used for procedural content generation.
-- 
-- There are many webpages which discuss Perlin and Simplex noise in detail.
-- @function[parent=#LOVEmath] noise
-- @param #number x The first value of the 4-dimensional vector used to generate the noise value.
-- @param #number y The second value of the 4-dimensional vector used to generate the noise value.
-- @param #number z The third value of the 4-dimensional vector used to generate the noise value.
-- @param #number w The fourth value of the 4-dimensional vector used to generate the noise value.
-- @return #number value The noise value in the range of [0, 1].
-- 

-------------------------------------------------------------------------------
-- Generates a pseudo-random number in a platform independent manner.
-- @function[parent=#LOVEmath] random
-- @return #number number The pseudo-random number.
-- 

-------------------------------------------------------------------------------
-- Generates a pseudo-random number in a platform independent manner.
-- @function[parent=#LOVEmath] random
-- @param #number max The maximum possible value it should return.
-- @return #number number The pseudo-random integer number.
-- 

-------------------------------------------------------------------------------
-- Generates a pseudo-random number in a platform independent manner.
-- @function[parent=#LOVEmath] random
-- @param #number min The minimum possible value it should return.
-- @param #number max The maximum possible value it should return.
-- @return #number number The pseudo-random integer number.
-- 

-------------------------------------------------------------------------------
-- Get a normally distributed pseudo random number.
-- @function[parent=#LOVEmath] randomNormal
-- @param #number stddev Standard deviation of the distribution.
-- @param #number mean The mean of the distribution.
-- @return #number number Normally distributed random number with variance (stddev)² and the specified mean.
-- 

-------------------------------------------------------------------------------
-- Sets the seed of the random number generator using the specified integer number.
-- @function[parent=#LOVEmath] setRandomSeed
-- @param #number seed The integer number with which you want to seed the randomization. Must be within the range of [1, 2^53].
-- 

-------------------------------------------------------------------------------
-- Sets the seed of the random number generator using the specified integer number.
-- @function[parent=#LOVEmath] setRandomSeed
-- @param #number low The lower 32 bits of the state value. Must be within the range of [0, 2^32 - 1].
-- @param #number high The higher 32 bits of the state value. Must be within the range of [0, 2^32 - 1].
-- 

-------------------------------------------------------------------------------
-- Gets the current state of the random number generator. This returns an opaque implementation-dependent string which is only useful for later use with RandomGenerator:setState.
-- 
-- This is different from RandomGenerator:getSeed in that getState gets the RandomGenerator's current state, whereas getSeed gets the previously set seed number.
-- 
-- The value of the state string does not depend on the current operating system.
-- @function[parent=#LOVEmath] setRandomState
-- @param #string state The current state of the RandomGenerator object, represented as a string.
-- 

-------------------------------------------------------------------------------
-- Triangulate a simple polygon.
-- @function[parent=#LOVEmath] triangulate
-- @param #table polygon Polygon to triangulate. Must not intersect itself.
-- @return #table triangles List of triangles the polygon is composed of, in the form of {{x1, y1, x2, y2, x3, y3}, {x1, y1, x2, y2, x3, y3}, ...}.
-- 

-------------------------------------------------------------------------------
-- Triangulate a simple polygon.
-- @function[parent=#LOVEmath] triangulate
-- @param #number x1 The position of the first vertex of the polygon on the x-axis.
-- @param #number y1 The position of the first vertex of the polygon on the y-axis.
-- @param #number x2 The position of the second vertex of the polygon on the x-axis.
-- @param #number y2 The position of the second vertex of the polygon on the y-axis.
-- @param #number x3 The position of the third vertex of the polygon on the x-axis.
-- @param #number y3 The position of the third vertex of the polygon on the y-axis.
-- @param #number ... Additional vertices.
-- @return #table triangles List of triangles the polygon is composed of, in the form of {{x1, y1, x2, y2, x3, y3}, {x1, y1, x2, y2, x3, y3}, ...}.
-- 


return nil
