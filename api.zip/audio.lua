--------------------------------------------------------------------------------
-- Provides an interface to create noise with the user's speakers.
-- 
-- @module audio
-- 

-------------------------------------------------------------------------------
-- A Source represents audio you can play back. You can do interesting things with Sources, like set the volume, pitch, and its position relative to the listener.
-- @type Source
-- @extends love#Object

-------------------------------------------------------------------------------
-- Creates an identical copy of the Source in the stopped state.
-- 
-- Static Sources will use significantly less memory and take much less time to be created if Source:clone is used to create them instead of love.audio.newSource, so this method should be preferred when making multiple Sources which play the same sound.
-- 
-- Cloned Sources inherit all the set-able state of the original Source, but they are initialized stopped.
-- @function[parent=#Source] clone
-- @param self self 
-- @return audio#Source source The new identical copy of this Source.
-- 

-------------------------------------------------------------------------------
-- Returns the reference and maximum distance of the source.
-- @function[parent=#Source] getAttenuationDistances
-- @param self self 
-- @return #number ref The reference distance.
-- @return #number max The maximum distance.
-- 

-------------------------------------------------------------------------------
-- Gets the number of channels in the Source. Only 1-channel (mono) Sources can use directional and positional effects.
-- @function[parent=#Source] getChannels
-- @param self self 
-- @return #number channels 1 for mono, 2 for stereo.
-- 

-------------------------------------------------------------------------------
-- Gets the Source's directional volume cones. Together with Source:setDirection, the cone angles allow for the Source's volume to vary depending on its direction.
-- @function[parent=#Source] getCone
-- @param self self 
-- @return #number innerAngle The inner angle from the Source's direction, in radians. The Source will play at normal volume if the listener is inside the cone defined by this angle.
-- @return #number outerAngle The outer angle from the Source's direction, in radians. The Source will play at a volume between the normal and outer volumes, if the listener is in between the cones defined by the inner and outer angles.
-- @return #number outerVolume The Source's volume when the listener is outside both the inner and outer cone angles.
-- 

-------------------------------------------------------------------------------
-- Gets the direction of the Source.
-- @function[parent=#Source] getDirection
-- @param self self 
-- @return #number x The X part of the direction vector.
-- @return #number y The Y part of the direction vector.
-- @return #number z The Z part of the direction vector.
-- 

-------------------------------------------------------------------------------
-- Gets the duration of the Source. For streaming Sources it may not always be sample-accurate, and may return -1 if the duration cannot be determined at all.
-- @function[parent=#Source] getDuration
-- @param self self 
-- @param audio#TimeUnit unit The time unit for the return value.
-- @return #number duration The duration of the Source, or -1 if it cannot be determined.
-- 

-------------------------------------------------------------------------------
-- Gets the current pitch of the Source.
-- @function[parent=#Source] getPitch
-- @param self self 
-- @return #number pitch The pitch, where 1.0 is normal.
-- 

-------------------------------------------------------------------------------
-- Gets the position of the Source.
-- @function[parent=#Source] getPosition
-- @param self self 
-- @return #number x The X position of the Source.
-- @return #number y The Y position of the Source.
-- @return #number z The Z position of the Source.
-- 

-------------------------------------------------------------------------------
-- Returns the rolloff factor of the source.
-- @function[parent=#Source] getRolloff
-- @param self self 
-- @return #number rolloff The rolloff factor.
-- 

-------------------------------------------------------------------------------
-- Gets the type (static or stream) of the Source.
-- @function[parent=#Source] getType
-- @param self self 
-- @return audio#SourceType sourcetype The type of the source.
-- 

-------------------------------------------------------------------------------
-- Gets the velocity of the Source.
-- @function[parent=#Source] getVelocity
-- @param self self 
-- @return #number x The X part of the velocity vector.
-- @return #number y The Y part of the velocity vector.
-- @return #number z The Z part of the velocity vector.
-- 

-------------------------------------------------------------------------------
-- Gets the current volume of the Source.
-- @function[parent=#Source] getVolume
-- @param self self 
-- @return #number volume The volume of the Source, where 1.0 is normal volume.
-- 

-------------------------------------------------------------------------------
-- Returns the volume limits of the source.
-- @function[parent=#Source] getVolumeLimits
-- @param self self 
-- @return #number min The minimum volume.
-- @return #number max The maximum volume.
-- 

-------------------------------------------------------------------------------
-- Returns whether the Source will loop.
-- @function[parent=#Source] isLooping
-- @param self self 
-- @return #boolean loop True if the Source will loop, false otherwise.
-- 

-------------------------------------------------------------------------------
-- Returns whether the Source is paused.
-- @function[parent=#Source] isPaused
-- @param self self 
-- @return #boolean paused True if the Source is paused, false otherwise.
-- 

-------------------------------------------------------------------------------
-- Returns whether the Source is playing.
-- @function[parent=#Source] isPlaying
-- @param self self 
-- @return #boolean playing True if the Source is playing, false otherwise.
-- 

-------------------------------------------------------------------------------
-- Returns whether the Source is stopped.
-- @function[parent=#Source] isStopped
-- @param self self 
-- @return #boolean stopped True if the Source is stopped, false otherwise.
-- 

-------------------------------------------------------------------------------
-- Pauses the Source.
-- @function[parent=#Source] pause
-- @param self self 
-- 

-------------------------------------------------------------------------------
-- Starts playing the Source.
-- @function[parent=#Source] play
-- @param self self 
-- @return #boolean success True if the Source started playing successfully, false otherwise.
-- 

-------------------------------------------------------------------------------
-- Resumes a paused Source.
-- @function[parent=#Source] resume
-- @param self self 
-- 

-------------------------------------------------------------------------------
-- Rewinds a Source.
-- @function[parent=#Source] rewind
-- @param self self 
-- 

-------------------------------------------------------------------------------
-- Sets the playing position of the Source.
-- @function[parent=#Source] seek
-- @param self self 
-- @param #number position The position to seek to.
-- @param audio#TimeUnit unit The unit of the position value.
-- 

-------------------------------------------------------------------------------
-- Sets the direction vector of the Source. A zero vector makes the source non-directional.
-- @function[parent=#Source] setDirection
-- @param self self 
-- @param #number x The X part of the direction vector.
-- @param #number y The Y part of the direction vector.
-- @param #number z The Z part of the direction vector.
-- 

-------------------------------------------------------------------------------
-- Sets the reference and maximum distance of the source.
-- @function[parent=#Source] setAttenuationDistances
-- @param self self 
-- @param #number ref The new reference distance.
-- @param #number max The new maximum distance.
-- 

-------------------------------------------------------------------------------
-- Sets the Source's directional volume cones. Together with Source:setDirection, the cone angles allow for the Source's volume to vary depending on its direction.
-- @function[parent=#Source] setCone
-- @param self self 
-- @param #number innerAngle The inner angle from the Source's direction, in radians. The Source will play at normal volume if the listener is inside the cone defined by this angle.
-- @param #number outerAngle The outer angle from the Source's direction, in radians. The Source will play at a volume between the normal and outer volumes, if the listener is in between the cones defined by the inner and outer angles.
-- @param #number outerVolume The Source's volume when the listener is outside both the inner and outer cone angles.
-- 

-------------------------------------------------------------------------------
-- Sets whether the Source should loop.
-- @function[parent=#Source] setLooping
-- @param self self 
-- @param #boolean loop True if the source should loop, false otherwise.
-- 

-------------------------------------------------------------------------------
-- Sets the pitch of the Source.
-- @function[parent=#Source] setPitch
-- @param self self 
-- @param #number pitch Calculated with regard to 1 being the base pitch. Each reduction by 50 percent equals a pitch shift of -12 semitones (one octave reduction). Each doubling equals a pitch shift of 12 semitones (one octave increase). Zero is not a legal value.
-- 

-------------------------------------------------------------------------------
-- Sets the position of the Source.
-- @function[parent=#Source] setPosition
-- @param self self 
-- @param #number x The X position of the Source.
-- @param #number y The Y position of the Source.
-- @param #number z The Z position of the Source.
-- 

-------------------------------------------------------------------------------
-- Sets the rolloff factor.
-- @function[parent=#Source] setRolloff
-- @param self self 
-- @param #number rolloff The new rolloff factor.
-- 

-------------------------------------------------------------------------------
-- Sets the velocity of the Source.
-- 
-- This does not change the position of the Source, but is used to calculate the doppler effect.
-- @function[parent=#Source] setVelocity
-- @param self self 
-- @param #number x The X part of the velocity vector.
-- @param #number y The Y part of the velocity vector.
-- @param #number z The Z part of the velocity vector.
-- 

-------------------------------------------------------------------------------
-- Sets the volume of the Source.
-- @function[parent=#Source] setVolume
-- @param self self 
-- @param #number volume The volume of the Source, where 1.0 is normal volume.
-- 

-------------------------------------------------------------------------------
-- Sets the volume limits of the source. The limits have to be numbers from 0 to 1.
-- @function[parent=#Source] setVolumeLimits
-- @param self self 
-- @param #number min The minimum volume.
-- @param #number max The maximum volume.
-- 

-------------------------------------------------------------------------------
-- Stops a Source.
-- @function[parent=#Source] stop
-- @param self self 
-- 

-------------------------------------------------------------------------------
-- Gets the currently playing position of the Source.
-- @function[parent=#Source] tell
-- @param self self 
-- @param audio#TimeUnit unit The type of unit for the return value.
-- @return #number position The currently playing position of the Source.
-- 


-------------------------------------------------------------------------------
-- Returns the distance attenuation model.
-- @function[parent=#audio] getDistanceModel
-- @return audio#DistanceModel model The current distance model. The default is 'inverseclamped'.
-- 

-------------------------------------------------------------------------------
-- Gets the current global scale factor for velocity-based doppler effects.
-- @function[parent=#audio] getDopplerScale
-- @return #number scale The current doppler scale factor.
-- 

-------------------------------------------------------------------------------
-- Returns the number of sources which are currently playing or paused.
-- @function[parent=#audio] getSourceCount
-- @return #number numSources The number of sources which are currently playing or paused.
-- 

-------------------------------------------------------------------------------
-- Returns the orientation of the listener.
-- @function[parent=#audio] getOrientation
-- @return #number fx The X component of the forward vector of the listener orientation.
-- @return #number fy The Y component of the forward vector of the listener orientation.
-- @return #number fz The Z component of the forward vector of the listener orientation.
-- @return #number ux The X component of the up vector of the listener orientation.
-- @return #number uy The Y component of the up vector of the listener orientation.
-- @return #number uz The Z component of the up vector of the listener orientation.
-- 

-------------------------------------------------------------------------------
-- Returns the position of the listener.
-- @function[parent=#audio] getPosition
-- @return #number x The X position of the listener.
-- @return #number y The Y position of the listener.
-- @return #number z The Z position of the listener.
-- 

-------------------------------------------------------------------------------
-- Returns the velocity of the listener.
-- @function[parent=#audio] getVelocity
-- @return #number x The X velocity of the listener.
-- @return #number y The Y velocity of the listener.
-- @return #number z The Z velocity of the listener.
-- 

-------------------------------------------------------------------------------
-- Returns the master volume.
-- @function[parent=#audio] getVolume
-- @return #number volume The current master volume.
-- 

-------------------------------------------------------------------------------
-- Creates a new Source from a file or SoundData. Sources created from SoundData are always static.
-- @function[parent=#audio] newSource
-- @param #string filename The filepath to create a Source from.
-- @param audio#SourceType type Streaming or static source.
-- @return audio#Source source A new Source that can play the specified audio.
-- 

-------------------------------------------------------------------------------
-- Creates a new Source from a file or SoundData. Sources created from SoundData are always static.
-- @function[parent=#audio] newSource
-- @param filesystem#File file A File pointing to an audio file.
-- @param audio#SourceType type Streaming or static source.
-- @return audio#Source source A new Source that can play the specified audio.
-- 

-------------------------------------------------------------------------------
-- Creates a new Source from a file or SoundData. Sources created from SoundData are always static.
-- @function[parent=#audio] newSource
-- @param sound#Decoder decoder The Decoder to create a Source from.
-- @param audio#SourceType type Streaming or static source.
-- @return audio#Source source A new Source that can play the specified audio.
-- 

-------------------------------------------------------------------------------
-- Creates a new Source from a file or SoundData. Sources created from SoundData are always static.
-- @function[parent=#audio] newSource
-- @param sound#SoundData soundData The SoundData to create a Source from.
-- @return audio#Source source A new Source that can play the specified audio. The SourceType of the returned audio is "static".
-- 

-------------------------------------------------------------------------------
-- Creates a new Source from a file or SoundData. Sources created from SoundData are always static.
-- @function[parent=#audio] newSource
-- @param filesystem#FileData fileData The FileData to create a Source from.
-- @return audio#Source source A new Source that can play the specified audio.
-- 

-------------------------------------------------------------------------------
-- Pauses all audio
-- @function[parent=#audio] pause
-- 

-------------------------------------------------------------------------------
-- Pauses all audio
-- @function[parent=#audio] pause
-- @param audio#Source source The source on which to pause the playback.
-- 

-------------------------------------------------------------------------------
-- Plays the specified Source.
-- @function[parent=#audio] play
-- @param audio#Source source The Source to play.
-- 

-------------------------------------------------------------------------------
-- Resumes all audio
-- @function[parent=#audio] resume
-- 

-------------------------------------------------------------------------------
-- Resumes all audio
-- @function[parent=#audio] resume
-- @param audio#Source source The source on which to resume the playback.
-- 

-------------------------------------------------------------------------------
-- Rewinds all playing audio.
-- @function[parent=#audio] rewind
-- 

-------------------------------------------------------------------------------
-- Rewinds all playing audio.
-- @function[parent=#audio] rewind
-- @param audio#Source source The source to rewind.
-- 

-------------------------------------------------------------------------------
-- Sets the distance attenuation model.
-- @function[parent=#audio] setDistanceModel
-- @param audio#DistanceModel model The new distance model.
-- 

-------------------------------------------------------------------------------
-- Sets a global scale factor for velocity-based doppler effects. The default scale value is 1.
-- @function[parent=#audio] setDopplerScale
-- @param #number scale The new doppler scale factor. The scale must be greater than 0.
-- 

-------------------------------------------------------------------------------
-- Sets the orientation of the listener.
-- @function[parent=#audio] setOrientation
-- @param #number fx The X component of the forward vector of the listener orientation.
-- @param #number fy The Y component of the forward vector of the listener orientation.
-- @param #number fz The Z component of the forward vector of the listener orientation.
-- @param #number ux The X component of the up vector of the listener orientation.
-- @param #number uy The Y component of the up vector of the listener orientation.
-- @param #number uz The Z component of the up vector of the listener orientation.
-- 

-------------------------------------------------------------------------------
-- Sets the position of the listener, which determines how sounds play.
-- @function[parent=#audio] setPosition
-- @param #number x The X position of the listener.
-- @param #number y The Y position of the listener.
-- @param #number z The Z position of the listener.
-- 

-------------------------------------------------------------------------------
-- Sets the velocity of the listener.
-- @function[parent=#audio] setVelocity
-- @param #number x The X velocity of the listener.
-- @param #number y The Y velocity of the listener.
-- @param #number z The Z velocity of the listener.
-- 

-------------------------------------------------------------------------------
-- Sets the master volume.
-- @function[parent=#audio] setVolume
-- @param #number volume 1.0f is max and 0.0f is off.
-- 

-------------------------------------------------------------------------------
-- Stops all playing audio.
-- @function[parent=#audio] stop
-- 

-------------------------------------------------------------------------------
-- Stops all playing audio.
-- @function[parent=#audio] stop
-- @param audio#Source source The source on which to stop the playback.
-- 


return nil
