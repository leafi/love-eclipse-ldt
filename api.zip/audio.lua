---
-- Provides an interface to create noise with the user's speakers.
-- 
-- @module audio
-- 

---
-- Returns the distance attenuation model.
-- @function [parent = #audio] getDistanceModel
-- @return audio#DistanceModel model The current distance model.
-- 

---
-- Returns the number of sources which are currently playing or paused.
-- @function [parent = #audio] getSourceCount
-- @return #number numSources The number of sources which are currently playing or paused.
-- 

---
-- Returns the orientation of the listener.
-- @function [parent = #audio] getOrientation
-- @return #number fx The X component of the forward vector of the listener orientation.
-- @return #number fy The Y component of the forward vector of the listener orientation.
-- @return #number fz The Z component of the forward vector of the listener orientation.
-- @return #number ux The X component of the up vector of the listener orientation.
-- @return #number uy The Y component of the up vector of the listener orientation.
-- @return #number uz The Z component of the up vector of the listener orientation.
-- 

---
-- Returns the position of the listener.
-- @function [parent = #audio] getPosition
-- @return #number x The X position of the listener.
-- @return #number y The Y position of the listener.
-- @return #number z The Z position of the listener.
-- 

---
-- Returns the velocity of the listener.
-- @function [parent = #audio] getVelocity
-- @return #number x The X velocity of the listener.
-- @return #number y The Y velocity of the listener.
-- @return #number z The Z velocity of the listener.
-- 

---
-- Returns the master volume.
-- @function [parent = #audio] getVolume
-- @return #number volume The current master volume.
-- 

---
-- Creates a new Source from a file or SoundData. Sources created from SoundData are always static.
-- @function [parent = #audio] newSource
-- @param #string filename The filepath to create a Source from.
-- @param audio#SourceType type Streaming or static source.
-- @return audio#Source source A new Source that can play the specified audio.
-- 

---
-- Pauses all audio
-- @function [parent = #audio] pause
-- 

---
-- Plays the specified Source.
-- @function [parent = #audio] play
-- @param audio#Source source The Source to play.
-- 

---
-- Resumes all audio
-- @function [parent = #audio] resume
-- 

---
-- Rewinds all playing audio.
-- @function [parent = #audio] rewind
-- 

---
-- Sets the distance attenuation model.
-- @function [parent = #audio] setDistanceModel
-- @param audio#DistanceModel model The new distance model.
-- 

---
-- Sets the orientation of the listener.
-- @function [parent = #audio] setOrientation
-- @param #number fx The X component of the forward vector of the listener orientation.
-- @param #number fy The Y component of the forward vector of the listener orientation.
-- @param #number fz The Z component of the forward vector of the listener orientation.
-- @param #number ux The X component of the up vector of the listener orientation.
-- @param #number uy The Y component of the up vector of the listener orientation.
-- @param #number uz The Z component of the up vector of the listener orientation.
-- 

---
-- Sets the position of the listener, which determines how sounds play.
-- @function [parent = #audio] setPosition
-- @param #number x The X position of the listener.
-- @param #number y The Y position of the listener.
-- @param #number z The Z position of the listener.
-- 

---
-- Sets the velocity of the listener.
-- @function [parent = #audio] setVelocity
-- @param #number x The X velocity of the listener.
-- @param #number y The Y velocity of the listener.
-- @param #number z The Z velocity of the listener.
-- 

---
-- Sets the master volume.
-- @function [parent = #audio] setVolume
-- @param #number volume 1.0f is max and 0.0f is off.
-- 

---
-- Stops all playing audio.
-- @function [parent = #audio] stop
-- 


return nil
