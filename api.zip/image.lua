--------------------------------------------------------------------------------
-- Provides an interface to decode encoded image data.
-- 
-- @module image
-- 

-------------------------------------------------------------------------------
-- Represents compressed image data designed to stay compressed in RAM.
-- 
-- CompressedImageData encompasses standard compressed texture formats such as DXT1, DXT5, and BC5 / 3Dc.
-- 
-- You can't draw CompressedImageData directly to the screen. See Image for that.
-- @type CompressedImageData
-- @extends love#Data
-- @extends love#Object

-------------------------------------------------------------------------------
-- Gets the width and height of the CompressedImageData.
-- @function[parent=#CompressedImageData] getDimensions
-- @param self self 
-- @return #number width The width of the CompressedImageData.
-- @return #number height The height of the CompressedImageData.
-- 

-------------------------------------------------------------------------------
-- Gets the width and height of the CompressedImageData.
-- @function[parent=#CompressedImageData] getDimensions
-- @param self self 
-- @param #number level A mipmap level. Must be in the range of [1, CompressedImageData:getMipmapCount()].
-- @return #number width The width of the CompressedImageData.
-- @return #number height The height of the CompressedImageData.
-- 

-------------------------------------------------------------------------------
-- Gets the format of the CompressedImageData.
-- @function[parent=#CompressedImageData] getFormat
-- @param self self 
-- @return image#CompressedImageFormat format The format of the CompressedImageData.
-- 

-------------------------------------------------------------------------------
-- Gets the height of the CompressedImageData.
-- @function[parent=#CompressedImageData] getHeight
-- @param self self 
-- @return #number height The height of the CompressedImageData.
-- 

-------------------------------------------------------------------------------
-- Gets the height of the CompressedImageData.
-- @function[parent=#CompressedImageData] getHeight
-- @param self self 
-- @param #number level A mipmap level. Must be in the range of [1,  CompressedImageData:getMipmapCount()].
-- @return #number height The height of the CompressedImageData.
-- 

-------------------------------------------------------------------------------
-- Gets the number of mipmap levels in the CompressedImageData. The base mipmap level (original image) is included in the count.
-- @function[parent=#CompressedImageData] getMipmapCount
-- @param self self 
-- @param #number mipmaps The number of mipmap levels stored in the CompressedImageData.
-- 

-------------------------------------------------------------------------------
-- Gets the width of the CompressedImageData.
-- @function[parent=#CompressedImageData] getWidth
-- @param self self 
-- @return #number width The width of the CompressedImageData.
-- 

-------------------------------------------------------------------------------
-- Gets the width of the CompressedImageData.
-- @function[parent=#CompressedImageData] getWidth
-- @param self self 
-- @param #number level A mipmap level. Must be in the range of [1, CompressedImageData:getMipmapCount()].
-- @return #number width The width of the CompressedImageData.
-- 


-------------------------------------------------------------------------------
-- Raw (decoded) image data.
-- 
-- You can't draw ImageData directly to screen. See Image for that.
-- @type ImageData
-- @extends love#Data
-- @extends love#Object

-------------------------------------------------------------------------------
-- Encodes the ImageData and optionally writes it to the save directory.
-- @function[parent=#ImageData] encode
-- @param self self 
-- @param image#ImageFormat format The format to encode the image as.
-- @param #string filename The filename to write the file to. If nil, no file will be written but the FileData will still be returned.
-- @return filesystem#FileData filedata The encoded image as a new FileData object.
-- 

-------------------------------------------------------------------------------
-- Gets the width and height of the ImageData.
-- @function[parent=#ImageData] getDimensions
-- @param self self 
-- @return #number width The width of the ImageData.
-- @return #number height The height of the ImageData.
-- 

-------------------------------------------------------------------------------
-- Gets the height of the ImageData.
-- @function[parent=#ImageData] getHeight
-- @param self self 
-- @return #number height The height of the ImageData.
-- 

-------------------------------------------------------------------------------
-- Gets the pixel at the specified position.
-- 
-- Valid x and y values start at 0 and go up to image width and height minus 1.
-- @function[parent=#ImageData] getPixel
-- @param self self 
-- @param #number x The position of the pixel on the x-axis.
-- @param #number y The position of the pixel on the y-axis.
-- @return #number r The red component (0-255).
-- @return #number g The green component (0-255).
-- @return #number b The blue component (0-255).
-- @return #number a The alpha component (0-255).
-- 

-------------------------------------------------------------------------------
-- Gets the width of the ImageData.
-- @function[parent=#ImageData] getWidth
-- @param self self 
-- @return #number width The width of the ImageData.
-- 

-------------------------------------------------------------------------------
-- Transform an image by applying a function to every pixel.
-- 
-- This function is a higher order function. It takes another function as a parameter, and calls it once for each pixel in the ImageData.
-- 
-- The function parameter is called with six parameters for each pixel in turn. The parameters are numbers that represent the x and y coordinates of the pixel and its red, green, blue and alpha values. The function parameter can return up to four number values, which become the new r, g, b and a values of the pixel. If the function returns fewer values, the remaining components are set to 0.
-- @function[parent=#ImageData] mapPixel
-- @param self self 
-- @param pixelFunction Function parameter to apply to every pixel.
-- 

-------------------------------------------------------------------------------
-- Paste into ImageData from another source ImageData.
-- @function[parent=#ImageData] paste
-- @param self self 
-- @param image#ImageData source Source ImageData from which to copy.
-- @param #number dx Destination top-left position on x-axis.
-- @param #number dy Destination top-left position on y-axis.
-- @param #number sx Source top-left position on x-axis.
-- @param #number sy Source top-left position on y-axis.
-- @param #number sw Source width.
-- @param #number sh Source height.
-- 

-------------------------------------------------------------------------------
-- Sets the color of a pixel.
-- 
-- Valid x and y values start at 0 and go up to image width and height minus 1.
-- @function[parent=#ImageData] setPixel
-- @param self self 
-- @param #number x The position of the pixel on the x-axis.
-- @param #number y The position of the pixel on the y-axis.
-- @param #number r The red component (0-255).
-- @param #number g The green component (0-255).
-- @param #number b The blue component (0-255).
-- @param #number a The alpha component (0-255).
-- 


-------------------------------------------------------------------------------
-- Determines whether a file can be loaded as CompressedImageData.
-- @function[parent=#image] isCompressed
-- @param #string filename The filename of the potentially compressed image file.
-- @return #boolean compressed Whether the file can be loaded as CompressedImageData or not.
-- 

-------------------------------------------------------------------------------
-- Determines whether a file can be loaded as CompressedImageData.
-- @function[parent=#image] isCompressed
-- @param filesystem#FileData fileData A FileData potentially containing a compressed image.
-- @return #boolean compressed Whether the FileData can be loaded as CompressedImageData or not.
-- 

-------------------------------------------------------------------------------
-- Create a new CompressedImageData object from a compressed image file. LÖVE supports several compressed texture formats, enumerated in the CompressedImageFormat page.
-- @function[parent=#image] newCompressedData
-- @param #string filename The filename of the compressed image file.
-- @return image#CompressedImageData compressedImageData The new CompressedImageData object.
-- 

-------------------------------------------------------------------------------
-- Create a new CompressedImageData object from a compressed image file. LÖVE supports several compressed texture formats, enumerated in the CompressedImageFormat page.
-- @function[parent=#image] newCompressedData
-- @param filesystem#FileData fileData A FileData containing a compressed image.
-- @return image#CompressedImageData compressedImageData The new CompressedImageData object.
-- 

-------------------------------------------------------------------------------
-- Create a new ImageData object.
-- @function[parent=#image] newImageData
-- @param #number width The width of the ImageData.
-- @param #number height The height of the ImageData.
-- @return image#ImageData imageData The new blank ImageData object. Each pixel's color values, (including the alpha values!) will be set to zero.
-- 

-------------------------------------------------------------------------------
-- Create a new ImageData object.
-- @function[parent=#image] newImageData
-- @param #number width The width of the ImageData.
-- @param #number height The height of the ImageData.
-- @param #string data The data to load into the ImageData.
-- @return image#ImageData imageData The new ImageData object.
-- 

-------------------------------------------------------------------------------
-- Create a new ImageData object.
-- @function[parent=#image] newImageData
-- @param #string filename The filename of the image file.
-- @return image#ImageData imageData The new ImageData object.
-- 

-------------------------------------------------------------------------------
-- Create a new ImageData object.
-- @function[parent=#image] newImageData
-- @param filesystem#FileData filedata The encoded file data to decode into image data.
-- @return image#ImageData imageData The new ImageData object.
-- 


return nil
