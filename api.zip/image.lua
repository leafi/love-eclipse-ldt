---
-- Provides an interface to decode encoded image data.
-- 
-- @module image
-- 

---
-- Determines whether a file can be loaded as CompressedData.
-- @function [parent = #image] isCompressed
-- @param #string filename The filename of the potentially compressed image file.
-- @return #boolean compressed Whether the file can be loaded as CompressedData or not.
-- 

---
-- Create a new CompressedData object from a compressed image file. LÖVE currently supports DDS files compressed with the DXT1, DXT5, and BC5 / 3Dc formats.
-- @function [parent = #image] newCompressedData
-- @param #string filename The filename of the compressed image file.
-- @return image#CompressedData compressedData The new CompressedData object.
-- 

---
-- Create a new ImageData object.
-- @function [parent = #image] newImageData
-- @param #number width The width of the ImageData.
-- @param #number height The height of the ImageData.
-- @return image#ImageData imageData The new ImageData object.
-- 


return nil
