--------------------------------------------------------------------------------
-- Provides an interface to the user's joystick.
-- 
-- @module joystick
-- 

-------------------------------------------------------------------------------
-- Represents a physical joystick.
-- @type Joystick
-- @extends love#Object

-------------------------------------------------------------------------------
-- Gets the direction of each axis.
-- @function[parent=#Joystick] getAxes
-- @param self self 
-- @return #number axisDir1 Direction of axis1.
-- @return #number axisDir2 Direction of axis2.
-- @return #number axisDirN Direction of axisN.
-- 

-------------------------------------------------------------------------------
-- Gets the direction of an axis.
-- @function[parent=#Joystick] getAxis
-- @param self self 
-- @param #number axis The index of the axis to be checked.
-- @return #number direction Current value of the axis.
-- 

-------------------------------------------------------------------------------
-- Gets the number of axes on the joystick.
-- @function[parent=#Joystick] getAxisCount
-- @param self self 
-- @return #number axes The number of axes available.
-- 

-------------------------------------------------------------------------------
-- Gets the number of buttons on the joystick.
-- @function[parent=#Joystick] getButtonCount
-- @param self self 
-- @return #number buttons The number of buttons available.
-- 

-------------------------------------------------------------------------------
-- Gets a stable GUID unique to the type of the physical joystick which does not change over time. For example, all Sony Dualshock 3 controllers in OS X have the same GUID. The value is platform-dependent.
-- @function[parent=#Joystick] getGUID
-- @param self self 
-- @return #string guid The Joystick type's OS-dependent unique identifier.
-- 

-------------------------------------------------------------------------------
-- Gets the direction of a virtual gamepad axis. If the Joystick isn't recognized as a gamepad or isn't connected, this function will always return 0.
-- @function[parent=#Joystick] getGamepadAxis
-- @param self self 
-- @param joystick#GamepadAxis axis The virtual axis to be checked.
-- @return #number direction Current value of the axis.
-- 

-------------------------------------------------------------------------------
-- Gets the button, axis or hat that a virtual gamepad input is bound to.
-- @function[parent=#Joystick] getGamepadMapping
-- @param self self 
-- @param joystick#GamepadAxis axis The virtual gamepad axis to get the binding for.
-- @return joystick#JoystickInputType inputtype The type of input the virtual gamepad axis is bound to.
-- @return #number inputindex The index of the Joystick's button, axis or hat that the virtual gamepad axis is bound to.
-- @return joystick#JoystickHat hatdirection The direction of the hat, if the virtual gamepad axis is bound to a hat. nil otherwise.
-- 

-------------------------------------------------------------------------------
-- Gets the button, axis or hat that a virtual gamepad input is bound to.
-- @function[parent=#Joystick] getGamepadMapping
-- @param self self 
-- @param joystick#GamepadAxis button The virtual gamepad button to get the binding for.
-- @return joystick#JoystickInputType inputtype The type of input the virtual gamepad button is bound to.
-- @return #number inputindex The index of the Joystick's button, axis or hat that the virtual gamepad button is bound to.
-- @return joystick#JoystickHat hatdirection The direction of the hat, if the virtual gamepad button is bound to a hat. nil otherwise.
-- 

-------------------------------------------------------------------------------
-- Gets the direction of a hat.
-- @function[parent=#Joystick] getHat
-- @param self self 
-- @param #number hat The index of the hat to be checked.
-- @return joystick#JoystickHat direction The direction the hat is pushed.
-- 

-------------------------------------------------------------------------------
-- Gets the number of hats on the joystick.
-- @function[parent=#Joystick] getHatCount
-- @param self self 
-- @return #number hats How many hats the joystick has.
-- 

-------------------------------------------------------------------------------
-- Gets the joystick's unique identifier. The identifier will remain the same for the life of the game, even when the Joystick is disconnected and reconnected, but it will change when the game is re-launched.
-- @function[parent=#Joystick] getID
-- @param self self 
-- @return #number id The Joystick's unique identifier. Remains the same as long as the game is running.
-- @return #number instanceid Unique instance identifier. Changes every time the Joystick is reconnected. nil if the Joystick is not connected.
-- 

-------------------------------------------------------------------------------
-- Gets the name of the joystick.
-- @function[parent=#Joystick] getName
-- @param self self 
-- @return #string name The name of the joystick.
-- 

-------------------------------------------------------------------------------
-- Gets the current vibration motor strengths on a Joystick with rumble support.
-- @function[parent=#Joystick] getVibration
-- @param self self 
-- @return #number left Current strength of the left vibration motor on the Joystick.
-- @return #number right Current strength of the right vibration motor on the Joystick.
-- 

-------------------------------------------------------------------------------
-- Gets whether the Joystick is connected.
-- @function[parent=#Joystick] isConnected
-- @param self self 
-- @return #boolean connected True if the Joystick is currently connected, false otherwise.
-- 

-------------------------------------------------------------------------------
-- Checks if a button on the Joystick is pressed.
-- 
-- LÖVE 0.9.0 had a bug which required the button indices passed to Joystick:isDown to be 0-based instead of 1-based, for example button 1 would be 0 for this function. It was fixed in 0.9.1.
-- @function[parent=#Joystick] isDown
-- @param self self 
-- @param #number ... The index of a button to check.
-- @return #boolean anyDown True if any supplied button is down, false if not.
-- 

-------------------------------------------------------------------------------
-- Gets whether the Joystick is recognized as a gamepad. If this is the case, the Joystick's buttons and axes can be used in a standardized manner across different operating systems and joystick models via Joystick:getGamepadAxis and related functions.
-- 
-- LÖVE automatically recognizes most popular controllers with a similar layout to the Xbox 360 controller as gamepads, but you can add more with love.joystick.setGamepadMapping.
-- @function[parent=#Joystick] isGamepad
-- @param self self 
-- @return #boolean isgamepad True if the Joystick is recognized as a gamepad, false otherwise.
-- 

-------------------------------------------------------------------------------
-- Checks if a virtual gamepad button on the Joystick is pressed. If the Joystick is not recognized as a Gamepad or isn't connected, then this function will always return false.
-- @function[parent=#Joystick] isGamepadDown
-- @param self self 
-- @param joystick#GamepadButton ... The gamepad button to check.
-- @return #boolean anyDown True if any supplied button is down, false if not.
-- 

-------------------------------------------------------------------------------
-- Gets whether the Joystick supports vibration.
-- @function[parent=#Joystick] isVibrationSupported
-- @param self self 
-- @return #boolean supported True if rumble / force feedback vibration is supported on this Joystick, false if not.
-- 

-------------------------------------------------------------------------------
-- Sets the vibration motor speeds on a Joystick with rumble support.
-- @function[parent=#Joystick] setVibration
-- @param self self 
-- @param #number left Strength of the left vibration motor on the Joystick. Must be in the range of [0, 1].
-- @param #number right Strength of the right vibration motor on the Joystick. Must be in the range of [0, 1].
-- @return #boolean success True if the vibration was successfully applied, false if not.
-- 

-------------------------------------------------------------------------------
-- Sets the vibration motor speeds on a Joystick with rumble support.
-- @function[parent=#Joystick] setVibration
-- @param self self 
-- @return #boolean success True if the vibration was successfully disabled, false if not.
-- 

-------------------------------------------------------------------------------
-- Sets the vibration motor speeds on a Joystick with rumble support.
-- @function[parent=#Joystick] setVibration
-- @param self self 
-- @param #number left Strength of the left vibration motor on the Joystick. Must be in the range of [0, 1].
-- @param #number right Strength of the right vibration motor on the Joystick. Must be in the range of [0, 1].
-- @param #number duration The duration of the vibration in seconds. A negative value means infinite duration.
-- @return #boolean success True if the vibration was successfully applied, false if not.
-- 


-------------------------------------------------------------------------------
-- Gets the number of connected joysticks.
-- @function[parent=#joystick] getJoystickCount
-- @return #number joystickcount The number of connected joysticks.
-- 

-------------------------------------------------------------------------------
-- Gets a list of connected Joysticks.
-- @function[parent=#joystick] getJoysticks
-- @return #table joysticks The list of currently connected Joysticks.
-- 

-------------------------------------------------------------------------------
-- Loads a gamepad mappings string or file created with love.joystick.saveGamepadMappings.
-- @function[parent=#joystick] loadGamepadMappings
-- @param #string filename The filename to load the mappings string from.
-- 

-------------------------------------------------------------------------------
-- Loads a gamepad mappings string or file created with love.joystick.saveGamepadMappings.
-- @function[parent=#joystick] loadGamepadMappings
-- @param #string mappings The mappings string to load.
-- 

-------------------------------------------------------------------------------
-- Saves the virtual gamepad mappings of all Joysticks that are recognized as gamepads and have either been recently used or their gamepad bindings have been modified.
-- @function[parent=#joystick] saveGamepadMappings
-- @param #string filename The filename to save the mappings string to.
-- @return #string mappings The mappings string that was written to the file.
-- 

-------------------------------------------------------------------------------
-- Saves the virtual gamepad mappings of all Joysticks that are recognized as gamepads and have either been recently used or their gamepad bindings have been modified.
-- @function[parent=#joystick] saveGamepadMappings
-- @return #string mappings The mappings string.
-- 

-------------------------------------------------------------------------------
-- Binds a virtual gamepad input to a button, axis or hat for all Joysticks of a certain type. For example, if this function is used with a GUID returned by a Dualshock 3 controller in OS X, the binding will affect Joystick:getGamepadAxis and Joystick:isGamepadDown for all Dualshock 3 controllers used with the game when run in OS X.
-- 
-- LÖVE includes built-in gamepad bindings for many common controllers. This function lets you change the bindings or add new ones for types of Joysticks which aren't recognized as gamepads by default.
-- 
-- The virtual gamepad buttons and axes are designed around the Xbox 360 controller layout.
-- @function[parent=#joystick] setGamepadMapping
-- @param #string guid The OS-dependent GUID for the type of Joystick the binding will affect.
-- @param joystick#GamepadButton button The virtual gamepad button to bind.
-- @param joystick#JoystickInputType inputtype The type of input to bind the virtual gamepad button to.
-- @param #number inputindex The index of the axis, button, or hat to bind the virtual gamepad button to.
-- @param joystick#JoystickHat hatdirection The direction of the hat, if the virtual gamepad button will be bound to a hat. nil otherwise.
-- @return #boolean success Whether the virtual gamepad button was successfully bound.
-- 

-------------------------------------------------------------------------------
-- Binds a virtual gamepad input to a button, axis or hat for all Joysticks of a certain type. For example, if this function is used with a GUID returned by a Dualshock 3 controller in OS X, the binding will affect Joystick:getGamepadAxis and Joystick:isGamepadDown for all Dualshock 3 controllers used with the game when run in OS X.
-- 
-- LÖVE includes built-in gamepad bindings for many common controllers. This function lets you change the bindings or add new ones for types of Joysticks which aren't recognized as gamepads by default.
-- 
-- The virtual gamepad buttons and axes are designed around the Xbox 360 controller layout.
-- @function[parent=#joystick] setGamepadMapping
-- @param #string guid The OS-dependent GUID for the type of Joystick the binding will affect.
-- @param joystick#GamepadButton button The virtual gamepad axis to bind.
-- @param joystick#JoystickInputType inputtype The type of input to bind the virtual gamepad axis to.
-- @param #number inputindex The index of the axis, button, or hat to bind the virtual gamepad axis to.
-- @param joystick#JoystickHat hatdirection The direction of the hat, if the virtual gamepad axis will be bound to a hat. nil otherwise.
-- @return #boolean success Whether the virtual gamepad button was successfully bound.
-- 


return nil
