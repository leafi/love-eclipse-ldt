---
-- Provides an interface to the user's joystick.
-- 
-- @module joystick
-- 

---
-- Gets the number of connected joysticks.
-- @function [parent = #joystick] getJoystickCount
-- @return #number joystickcount The number of connected joysticks.
-- 

---
-- Gets a list of connected Joysticks.
-- @function [parent = #joystick] getJoysticks
-- @return #table joysticks The list of currently connected Joysticks.
-- 

---
-- Loads a gamepad mappings string or file created with love.joystick.saveGamepadMappings.
-- @function [parent = #joystick] loadGamepadMappings
-- @param #string filename The filename to load the mappings string from.
-- 

---
-- Saves the virtual gamepad mappings of all Joysticks that are recognized as gamepads and have either been recently used or their gamepad bindings have been modified.
-- @function [parent = #joystick] saveGamepadMappings
-- @param #string filename The filename to save the mappings string to.
-- @return #string mappings The mappings string that was written to the file.
-- 

---
-- Binds a virtual gamepad input to a button, axis or hat for all Joysticks of a certain type. For example, if this function is used with a GUID returned by a Dualshock 3 controller in OS X, the binding will affect Joystick:getGamepadAxis and Joystick:isGamepadDown for all Dualshock 3 controllers used with the game when run in OS X.
-- 
-- LÖVE includes built-in gamepad bindings for many common controllers. This function lets you change the bindings or add new ones for types of Joysticks which aren't recognized as gamepads by default.
-- 
-- The virtual gamepad buttons and axes are designed around the Xbox 360 controller layout.
-- @function [parent = #joystick] setGamepadMapping
-- @param #string guid The OS-dependent GUID for the type of Joystick the binding will affect.
-- @param joystick#GamepadButton button The virtual gamepad button to bind.
-- @param joystick#JoystickInputType inputtype The type of input to bind the virtual gamepad button to.
-- @param #number inputindex The index of the axis, button, or hat to bind the virtual gamepad button to.
-- @param joystick#JoystickHat hatdirection The direction of the hat, if the virtual gamepad button will be bound to a hat. nil otherwise.
-- @return #boolean success Whether the virtual gamepad button was successfully bound.
-- 


return nil
