---
-- Provides an interface to the user's keyboard.
-- 
-- @module keyboard
-- 

---
-- Gets the key corresponding to the given hardware scancode.
-- 
-- The location of a key is based on the keyboard's current language layout, whereas scancodes are the layout-independent representations of where the physical keys are.
-- 
-- For example, the key located where "q" is on a U.S. keyboard has the scancode "q". When using a U.S. keyboard layout it produces the key "q", but when using a French keyboard layout it produces the key "a".
-- 
-- Scancodes are useful for creating default controls that have the same physical locations on on all systems.
-- @function [parent = #keyboard] getKeyFromScancode
-- @param #string scancode The scancode to get the key from.
-- @return keyboard#KeyConstant key The key corresponding to the given scancode, or "unknown" if the scancode doesn't map to a KeyConstant on the current system.
-- 

---
-- Gets the hardware scancode corresponding to the given key.
-- 
-- The location of a key is based on the keyboard's current language layout, whereas scancodes are the layout-independent representations of where the physical keys are.
-- 
-- For example, the key located where "q" is on a U.S. keyboard has the scancode "q". When using a U.S. keyboard layout it produces the key "q", but when using a French keyboard layout it produces the key "a".
-- 
-- Scancodes are useful for creating default controls that have the same physical locations on on all systems.
-- @function [parent = #keyboard] getScancodeFromKey
-- @param keyboard#KeyConstant key The key to get the scancode from.
-- @return #string scancode The scancode corresponding to the given key, or "unknown" if the given key has no known physical representation on the current system.
-- 

---
-- Gets whether key repeat is enabled.
-- @function [parent = #keyboard] hasKeyRepeat
-- @return #boolean enabled Whether key repeat is enabled.
-- 

---
-- Gets whether text input events are enabled.
-- @function [parent = #keyboard] hasTextInput
-- @return #boolean enabled Whether text input events are enabled.
-- 

---
-- Checks whether a certain key is down. Not to be confused with love.keypressed or love.keyreleased.
-- @function [parent = #keyboard] isDown
-- @param keyboard#KeyConstant key The key to check.
-- @return #boolean down True if the key is down, false if not.
-- 

---
-- Enables or disables key repeat. It is disabled by default.
-- 
-- The interval between repeats depends on the user's system settings.
-- @function [parent = #keyboard] setKeyRepeat
-- @param #boolean enable Whether repeat keypress events should be enabled when a key is held down.
-- 

---
-- Enables or disables text input events. It is enabled by default.
-- @function [parent = #keyboard] setTextInput
-- @param #boolean enable Whether text input events should be enabled.
-- 


return nil
