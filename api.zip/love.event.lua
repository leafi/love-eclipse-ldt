--------------------------------------------------------------------------------
-- Manages events, like keypresses.
-- 
-- @module love.event
-- 

-------------------------------------------------------------------------------
-- Clears the event queue.
-- @function[parent=#love.event] clear
-- 

-------------------------------------------------------------------------------
-- Returns an iterator for messages in the event queue.
-- @function[parent=#love.event] poll
-- @return i Iterator function usable in a for loop.
-- 

-------------------------------------------------------------------------------
-- Pump events into the event queue. This is a low-level function, and is usually not called by the user, but by love.run. Note that this does need to be called for any OS to think you're still running, and if you want to handle OS-generated events at all (think callbacks). love.event.pump can only be called from the main thread, but afterwards, the rest of love.event can be used from any other thread.
-- @function[parent=#love.event] pump
-- 

-------------------------------------------------------------------------------
-- Adds an event to the event queue.
-- @function[parent=#love.event] push
-- @param love.event#Event e The name of the event.
-- @param a First event argument.
-- @param b Second event argument.
-- @param c Third event argument.
-- @param d Fourth event argument.
-- 

-------------------------------------------------------------------------------
-- Adds the quit event to the queue.
-- 
-- The quit event is a signal for the event handler to close LÖVE. It's possible to abort the exit process with the love.quit callback.
-- @function[parent=#love.event] quit
-- 

-------------------------------------------------------------------------------
-- Adds the quit event to the queue.
-- 
-- The quit event is a signal for the event handler to close LÖVE. It's possible to abort the exit process with the love.quit callback.
-- @function[parent=#love.event] quit
-- @param #number exitstatus The program exit status to use when closing the application.
-- 

-------------------------------------------------------------------------------
-- Adds the quit event to the queue.
-- 
-- The quit event is a signal for the event handler to close LÖVE. It's possible to abort the exit process with the love.quit callback.
-- @function[parent=#love.event] quit
-- @param #string "restart" Restarts the game without relaunching the executable. This cleanly shuts down the main Lua state instance and creates a brand new one.
-- 

-------------------------------------------------------------------------------
-- Like love.event.poll but blocks until there is an event in the queue.
-- @function[parent=#love.event] wait
-- @return love.event#Event e The type of event.
-- @return a First event argument.
-- @return b Second event argument.
-- @return c Third event argument.
-- @return d Fourth event argument.
-- 


return nil
