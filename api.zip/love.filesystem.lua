--------------------------------------------------------------------------------
-- Provides an interface to the user's filesystem.
-- 
-- @module love.filesystem
-- 

-------------------------------------------------------------------------------
-- Represents a file on the filesystem.
-- @type File
-- @extends love#Object

-------------------------------------------------------------------------------
-- Closes a file.
-- @function[parent=#File] close
-- @param self self 
-- @return #boolean success Whether closing was successful.
-- 

-------------------------------------------------------------------------------
-- Flushes any buffered written data in the file to the disk.
-- @function[parent=#File] flush
-- @param self self 
-- @return #boolean success Whether the file successfully flushed any buffered data to the disk.
-- @return #string err The error string, if an error occurred and the file could not be flushed.
-- 

-------------------------------------------------------------------------------
-- Gets the buffer mode of a file.
-- @function[parent=#File] getBuffer
-- @param self self 
-- @return love.filesystem#BufferMode mode The current buffer mode of the file.
-- @return #number size The maximum size in bytes of the file's buffer.
-- 

-------------------------------------------------------------------------------
-- Gets the filename that the File object was created with. If the file object originated from the love.filedropped callback, the filename will be the full platform-dependent file path.
-- @function[parent=#File] getFilename
-- @param self self 
-- @return #string filename The filename of the File.
-- 

-------------------------------------------------------------------------------
-- Gets the FileMode the file has been opened with.
-- @function[parent=#File] getMode
-- @param self self 
-- @return love.filesystem#FileMode mode The mode this file has been opened with.
-- 

-------------------------------------------------------------------------------
-- Returns the file size.
-- @function[parent=#File] getSize
-- @param self self 
-- @return #number size The file size
-- 

-------------------------------------------------------------------------------
-- Gets whether end-of-file has been reached.
-- @function[parent=#File] isEOF
-- @param self self 
-- @return #boolean eof Whether EOF has been reached.
-- 

-------------------------------------------------------------------------------
-- Gets whether the file is open.
-- @function[parent=#File] isOpen
-- @param self self 
-- @return #boolean open True if the file is currently open, false otherwise.
-- 

-------------------------------------------------------------------------------
-- Iterate over all the lines in a file
-- @function[parent=#File] lines
-- @param self self 
-- @return iterator The iterator (can be used in for loops)
-- 

-------------------------------------------------------------------------------
-- Open the file for write, read or append.
-- 
-- If you are getting the error message "Could not set write directory", try setting the save directory. This is done either with love.filesystem.setIdentity or by setting the identity field in love.conf.
-- @function[parent=#File] open
-- @param self self 
-- @param love.filesystem#FileMode mode The mode to open the file in.
-- @return #boolean success True on success, false otherwise.
-- 

-------------------------------------------------------------------------------
-- Read a number of bytes from a file.
-- @function[parent=#File] read
-- @param self self 
-- @param #number bytes The number of bytes to read
-- @return #string contents The contents of the read bytes.
-- @return #number size How many bytes have been read.
-- 

-------------------------------------------------------------------------------
-- Seek to a position in a file.
-- @function[parent=#File] seek
-- @param self self 
-- @param #number position The position to seek to.
-- @return #boolean success Whether the operation was successful.
-- 

-------------------------------------------------------------------------------
-- Sets the buffer mode for a file opened for writing or appending. Files with buffering enabled will not write data to the disk until the buffer size limit is reached, depending on the buffer mode.
-- @function[parent=#File] setBuffer
-- @param self self 
-- @param love.filesystem#BufferMode mode The buffer mode to use.
-- @param #number size The maximum size in bytes of the file's buffer.
-- @return #boolean success Whether the buffer mode was successfully set.
-- @return #string errorstr The error string, if the buffer mode could not be set and an error occurred.
-- 

-------------------------------------------------------------------------------
-- Returns the position in the file.
-- @function[parent=#File] tell
-- @param self self 
-- @return #number pos The current position.
-- 

-------------------------------------------------------------------------------
-- Write data to a file.
-- @function[parent=#File] write
-- @param self self 
-- @param #string data The data to write.
-- @param #number size How many bytes to write.
-- @return #boolean success Whether the operation was successful.
-- 


-------------------------------------------------------------------------------
-- Data representing the contents of a file.
-- @type FileData
-- @extends love#Data
-- @extends love#Object

-------------------------------------------------------------------------------
-- Gets the extension of the FileData.
-- @function[parent=#FileData] getExtension
-- @param self self 
-- @return #string ext The extension of the file the FileData represents.
-- 

-------------------------------------------------------------------------------
-- Gets the filename of the FileData.
-- @function[parent=#FileData] getFilename
-- @param self self 
-- @return #string name The name of the file the FileData represents.
-- 


-------------------------------------------------------------------------------
-- Append data to an existing file.
-- @function[parent=#love.filesystem] append
-- @param #string name The name (and path) of the file.
-- @param #string data The data that should be written to the file
-- @param #number size How many bytes to write.
-- @return #boolean success True if the operation was successful, or nil if there was an error.
-- @return #string errormsg The error message on failure.
-- 

-------------------------------------------------------------------------------
-- Gets whether love.filesystem follows symbolic links.
-- @function[parent=#love.filesystem] areSymlinksEnabled
-- @return #boolean enable Whether love.filesystem follows symbolic links.
-- 

-------------------------------------------------------------------------------
-- Creates a directory.
-- @function[parent=#love.filesystem] createDirectory
-- @param #string name The directory to create.
-- @return #boolean success True if the directory was created, false if not.
-- 

-------------------------------------------------------------------------------
-- Returns the application data directory (could be the same as getUserDirectory)
-- @function[parent=#love.filesystem] getAppdataDirectory
-- @return #string path The path of the application data directory.
-- 

-------------------------------------------------------------------------------
-- Gets the filesystem paths that will be searched for c libraries when require is called.
-- 
-- The paths string returned by this function is a sequence of path templates separated by semicolons. The argument passed to require will be inserted in place of any question mark ("?") character in each template (after the dot characters in the argument passed to require are replaced by directory separators.) Additionally, any occurrence of a double question mark ("??") will be replaced by the name passed to require and the default library extension for the platform.
-- 
-- The paths are relative to the game's source and save directories, as well as any paths mounted with love.filesystem.mount.
-- @function[parent=#love.filesystem] getCRequirePath
-- @return #string paths The paths that the require function will check for c libraries in love's filesystem.
-- 

-------------------------------------------------------------------------------
-- Returns a table with the names of files and subdirectories in the specified path. The table is not sorted in any way; the order is undefined.
-- 
-- If the path passed to the function exists in the game and the save directory, it will list the files and directories from both places.
-- @function[parent=#love.filesystem] getDirectoryItems
-- @param #string dir The directory.
-- @return #table items A sequence with the names of all files and subdirectories as strings.
-- 

-------------------------------------------------------------------------------
-- Gets the write directory name for your game. Note that this only returns the name of the folder to store your files in, not the full location.
-- @function[parent=#love.filesystem] getIdentity
-- @param #string name The identity that is used as write directory.
-- 

-------------------------------------------------------------------------------
-- Gets information about the specified file or directory.
-- @function[parent=#love.filesystem] getInfo
-- @param #string path The file or directory path to check.
-- @return #table info A table containing information about the specified path, or nil if nothing exists at the path. The table contains the following fields:
-- 

-------------------------------------------------------------------------------
-- Gets information about the specified file or directory.
-- @function[parent=#love.filesystem] getInfo
-- @param #string path The file or directory path to check.
-- @param #table info A table which will be filled in with info about the specified path.
-- @return #table info A table containing information about the specified path, or nil if nothing exists at the path. The table contains the following fields:
-- 

-------------------------------------------------------------------------------
-- Gets the platform-specific absolute path of the directory containing a filepath.
-- 
-- This can be used to determine whether a file is inside the save directory or the game's source .love.
-- @function[parent=#love.filesystem] getRealDirectory
-- @param #string filepath The filepath to get the directory of.
-- @return #string realdir The platform-specific full path of the directory containing the filepath.
-- 

-------------------------------------------------------------------------------
-- Gets the filesystem paths that will be searched when require is called.
-- 
-- The paths string returned by this function is a sequence of path templates separated by semicolons. The argument passed to require will be inserted in place of any question mark ("?") character in each template (after the dot characters in the argument passed to require are replaced by directory separators.)
-- 
-- The paths are relative to the game's source and save directories, as well as any paths mounted with love.filesystem.mount.
-- @function[parent=#love.filesystem] getRequirePath
-- @return #string paths The paths that the require function will check in love's filesystem.
-- 

-------------------------------------------------------------------------------
-- Gets the full path to the designated save directory. This can be useful if you want to use the standard io library (or something else) to read or write in the save directory.
-- @function[parent=#love.filesystem] getSaveDirectory
-- @return #string path The absolute path to the save directory.
-- 

-------------------------------------------------------------------------------
-- Returns the full path to the the .love file or directory. If the game is fused to the LÖVE executable, then the executable is returned.
-- @function[parent=#love.filesystem] getSource
-- @return #string path The full platform-dependent path of the .love file or directory.
-- 

-------------------------------------------------------------------------------
-- Returns the full path to the directory containing the .love file. If the game is fused to the LÖVE executable, then the directory containing the executable is returned.
-- 
-- If love.filesystem.isFused is true, the path returned by this function can be passed to love.filesystem.mount, which will make the directory containing the main game readable by love.filesystem.
-- @function[parent=#love.filesystem] getSourceBaseDirectory
-- @return #string path The full platform-dependent path of the directory containing the .love file.
-- 

-------------------------------------------------------------------------------
-- Returns the path of the user's directory.
-- @function[parent=#love.filesystem] getUserDirectory
-- @return #string path The path of the user's directory.
-- 

-------------------------------------------------------------------------------
-- Gets the current working directory.
-- @function[parent=#love.filesystem] getWorkingDirectory
-- @return #string path The current working directory.
-- 

-------------------------------------------------------------------------------
-- Initializes love.filesystem, will be called internally, so should not be used explicitly.
-- @function[parent=#love.filesystem] init
-- @param #string appname The name of the application binary, typically love.
-- 

-------------------------------------------------------------------------------
-- Gets whether the game is in fused mode or not.
-- 
-- If a game is in fused mode, its save directory will be directly in the Appdata directory instead of Appdata/LOVE/. The game will also be able to load C Lua dynamic libraries which are located in the save directory.
-- 
-- A game is in fused mode if the source .love has been fused to the executable (see Game Distribution), or if "--fused" has been given as a command-line argument when starting the game.
-- @function[parent=#love.filesystem] isFused
-- @return #boolean fused True if the game is in fused mode, false otherwise.
-- 

-------------------------------------------------------------------------------
-- Iterate over the lines in a file.
-- @function[parent=#love.filesystem] lines
-- @param #string name The name (and path) of the file.
-- @return iterator A function that iterates over all the lines in the file.
-- 

-------------------------------------------------------------------------------
-- Loads a Lua file (but does not run it).
-- @function[parent=#love.filesystem] load
-- @param #string name The name (and path) of the file.
-- @param #string errormsg The error message if file could not be opened.
-- @return chunk The loaded chunk.
-- 

-------------------------------------------------------------------------------
-- Mounts a zip file or folder in the game's save directory for reading.
-- @function[parent=#love.filesystem] mount
-- @param #string archive The folder or zip file in the game's save directory to mount.
-- @param #string mountpoint The new path the archive will be mounted to.
-- @return #boolean success True if the archive was successfully mounted, false otherwise.
-- 

-------------------------------------------------------------------------------
-- Mounts a zip file or folder in the game's save directory for reading.
-- @function[parent=#love.filesystem] mount
-- @param #string archive The folder or zip file in the game's save directory to mount.
-- @param #string mountpoint The new path the archive will be mounted to.
-- @param #string appendToPath Whether the archive will be searched when reading a filepath before or after already-mounted archives. This includes the game's source and save directories.
-- @return #boolean success True if the archive was successfully mounted, false otherwise.
-- 

-------------------------------------------------------------------------------
-- Creates a new File object. It needs to be opened before it can be accessed.
-- @function[parent=#love.filesystem] newFile
-- @param #string filename The filename of the file to read.
-- @param love.filesystem#FileMode mode The mode to open the file in.
-- @return love.filesystem#File file The new File object, or nil if an error occurred.
-- @return #string errorstr The error string if an error occurred.
-- 

-------------------------------------------------------------------------------
-- Creates a new FileData object.
-- @function[parent=#love.filesystem] newFileData
-- @param #string contents The contents of the file.
-- @param #string name The name of the file.
-- @param love.filesystem#FileDecoder decoder The method to use when decoding the contents.
-- @return love.filesystem#FileData data Your new FileData.
-- 

-------------------------------------------------------------------------------
-- Creates a new FileData object.
-- @function[parent=#love.filesystem] newFileData
-- @param #string filepath Path to the file.
-- @return love.filesystem#FileData data The new FileData, or nil if an error occurred.
-- @return #string err The error string, if an error occurred.
-- 

-------------------------------------------------------------------------------
-- Read the contents of a file.
-- @function[parent=#love.filesystem] read
-- @param #string name The name (and path) of the file.
-- @param #number bytes How many bytes to read.
-- @return #string contents The file contents.
-- @return #number size How many bytes have been read.
-- 

-------------------------------------------------------------------------------
-- Removes a file or directory.
-- @function[parent=#love.filesystem] remove
-- @param #string name The file or directory to remove.
-- @return #boolean success True if the file/directory was removed, false otherwise.
-- 

-------------------------------------------------------------------------------
-- Sets the filesystem paths that will be searched for c libraries when require is called.
-- 
-- The paths string returned by this function is a sequence of path templates separated by semicolons. The argument passed to require will be inserted in place of any question mark ("?") character in each template (after the dot characters in the argument passed to require are replaced by directory separators.) Additionally, any occurrence of a double question mark ("??") will be replaced by the name passed to require and the default library extension for the platform.
-- 
-- The paths are relative to the game's source and save directories, as well as any paths mounted with love.filesystem.mount.
-- @function[parent=#love.filesystem] setCRequirePath
-- @param #string paths The paths that the require function will check in love's filesystem.
-- 

-------------------------------------------------------------------------------
-- Sets the write directory for your game. Note that you can only set the name of the folder to store your files in, not the location.
-- @function[parent=#love.filesystem] setIdentity
-- @param #string name The new identity that will be used as write directory.
-- @param #boolean appendToPath Whether the identity directory will be searched when reading a filepath before or after the game's source directory and any currently mounted archives.
-- 

-------------------------------------------------------------------------------
-- Sets the filesystem paths that will be searched when require is called.
-- 
-- The paths string given to this function is a sequence of path templates separated by semicolons. The argument passed to require will be inserted in place of any question mark ("?") character in each template (after the dot characters in the argument passed to require are replaced by directory separators.)
-- 
-- The paths are relative to the game's source and save directories, as well as any paths mounted with love.filesystem.mount.
-- @function[parent=#love.filesystem] setRequirePath
-- @param #string paths The paths that the require function will check in love's filesystem.
-- 

-------------------------------------------------------------------------------
-- Sets the source of the game, where the code is present. This function can only be called once, and is normally automatically done by LÖVE.
-- @function[parent=#love.filesystem] setSource
-- @param #string path Absolute path to the game's source folder.
-- 

-------------------------------------------------------------------------------
-- Sets whether love.filesystem follows symbolic links. It is enabled by default in version 0.10.0 and newer, and disabled by default in 0.9.2.
-- @function[parent=#love.filesystem] setSymlinksEnabled
-- @param #boolean enable Whether love.filesystem should follow symbolic links.
-- 

-------------------------------------------------------------------------------
-- Unmounts a zip file or folder previously mounted for reading with love.filesystem.mount.
-- @function[parent=#love.filesystem] unmount
-- @param #string archive The folder or zip file in the game's save directory which is currently mounted.
-- @return #boolean success True if the archive was successfully unmounted, false otherwise.
-- 

-------------------------------------------------------------------------------
-- Write data to a file.
-- 
-- If you are getting the error message "Could not set write directory", try setting the save directory. This is done either with love.filesystem.setIdentity or by setting the identity field in love.conf.
-- @function[parent=#love.filesystem] write
-- @param #string name The name (and path) of the file.
-- @param #string data The string data to write to the file.
-- @param #number size How many bytes to write.
-- @return #boolean success If the operation was successful.
-- @return #string message Error message if operation was unsuccessful.
-- 

-------------------------------------------------------------------------------
-- Write data to a file.
-- 
-- If you are getting the error message "Could not set write directory", try setting the save directory. This is done either with love.filesystem.setIdentity or by setting the identity field in love.conf.
-- @function[parent=#love.filesystem] write
-- @param #string name The name (and path) of the file.
-- @param love#Data data The Data object to write to the file.
-- @param #number size How many bytes to write.
-- @return #boolean success If the operation was successful.
-- @return #string message Error message if operation was unsuccessful.
-- 


return nil
