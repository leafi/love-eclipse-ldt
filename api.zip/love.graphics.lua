--------------------------------------------------------------------------------
-- The primary responsibility for the love.graphics module is the drawing of lines, shapes, text, Images and other Drawable objects onto the screen. Its secondary responsibilities include loading external files (including Images and Fonts) into memory, creating specialized objects (such as ParticleSystems or Framebuffers) and managing screen geometry.
-- 
-- LÖVE's coordinate system is rooted in the upper-left corner of the screen, which is at location (0, 0). The x-axis is horizontal: larger values are further to the right. The y-axis is vertical: larger values are further towards the bottom.
-- 
-- In many cases, you draw images or shapes in terms of their upper-left corner (See the picture above).
-- 
-- Many of the functions are used to manipulate the graphics coordinate system, which is essentially the way coordinates are mapped to the display. You can change the position, scale, and even rotation in this way.
-- 
-- @module love.graphics
-- 

-------------------------------------------------------------------------------
-- A Canvas is used for off-screen rendering. Think of it as an invisible screen that you can draw to, but that will not be visible until you draw it to the actual visible screen. It is also known as "render to texture".
-- 
-- By drawing things that do not change position often (such as background items) to the Canvas, and then drawing the entire Canvas instead of each item, you can reduce the number of draw operations performed each frame.
-- 
-- In versions prior to 0.10.0, not all graphics cards that LÖVE supported could use Canvases. love.graphics.isSupported("canvas") could be used to check for support at runtime.
-- @type Canvas
-- @extends love#Object
-- @extends love#Drawable
-- @extends love.graphics#Texture

-------------------------------------------------------------------------------
-- Gets the width and height of the Canvas.
-- @function[parent=#Canvas] getDimensions
-- @param self self 
-- @return #number width The width of the Canvas, in pixels.
-- @return #number height The height of the Canvas, in pixels.
-- 

-------------------------------------------------------------------------------
-- Gets the filter mode of the Canvas.
-- @function[parent=#Canvas] getFilter
-- @param self self 
-- @return love.graphics#FilterMode min Filter mode used when minifying the canvas.
-- @return love.graphics#FilterMode mag Filter mode used when magnifying the canvas.
-- @return #number anisotropy Maximum amount of anisotropic filtering used.
-- 

-------------------------------------------------------------------------------
-- Gets the texture format of the Canvas.
-- @function[parent=#Canvas] getFormat
-- @param self self 
-- @return love.graphics#CanvasFormat format The format of the Canvas.
-- 

-------------------------------------------------------------------------------
-- Gets the height of the Canvas.
-- @function[parent=#Canvas] getHeight
-- @param self self 
-- @return #number height The height of the Canvas, in pixels.
-- 

-------------------------------------------------------------------------------
-- Gets the number of multisample antialiasing (MSAA) samples used when drawing to the Canvas.
-- 
-- This may be different than the number used as an argument to love.graphics.newCanvas if the system running LÖVE doesn't support that number.
-- @function[parent=#Canvas] getMSAA
-- @param self self 
-- @return #number samples The number of multisample antialiasing samples used by the canvas when drawing to it.
-- 

-------------------------------------------------------------------------------
-- Gets the width of the Canvas.
-- @function[parent=#Canvas] getWidth
-- @param self self 
-- @return #number width The width of the Canvas, in pixels.
-- 

-------------------------------------------------------------------------------
-- Gets the wrapping properties of a Canvas.
-- 
-- This function returns the currently set horizontal and vertical wrapping modes for the Canvas.
-- @function[parent=#Canvas] getWrap
-- @param self self 
-- @return love.graphics#WrapMode horizontal Horizontal wrapping mode of the Canvas.
-- @return love.graphics#WrapMode vertical Vertical wrapping mode of the Canvas.
-- 

-------------------------------------------------------------------------------
-- Generates ImageData from the contents of the Canvas.
-- @function[parent=#Canvas] newImageData
-- @param self self 
-- @return love.image#ImageData data The image data stored in the Canvas.
-- 

-------------------------------------------------------------------------------
-- Generates ImageData from the contents of the Canvas.
-- @function[parent=#Canvas] newImageData
-- @param self self 
-- @param #number x The x-axis of the top-left corner of the area within the Canvas to capture.
-- @param #number y The y-axis of the top-left corner of the area within the Canvas to capture.
-- @param #number width The width of the area within the Canvas to capture.
-- @param #number height The height of the area within the Canvas to capture.
-- @return love.image#ImageData data The new ImageData made from the Canvas' contents.
-- 

-------------------------------------------------------------------------------
-- Render to the Canvas using a function.
-- @function[parent=#Canvas] renderTo
-- @param self self 
-- @param func A function performing drawing operations.
-- 

-------------------------------------------------------------------------------
-- Sets the filter of the Canvas.
-- @function[parent=#Canvas] setFilter
-- @param self self 
-- @param love.graphics#FilterMode min How to scale a canvas down.
-- @param love.graphics#FilterMode mag How to scale a canvas up.
-- @param #number anisotropy Maximum amount of anisotropic filtering used.
-- 

-------------------------------------------------------------------------------
-- Sets the wrapping properties of a Canvas.
-- 
-- This function sets the way the edges of a Canvas are treated if it is scaled or rotated. If the WrapMode is set to "clamp", the edge will not be interpolated. If set to "repeat", the edge will be interpolated with the pixels on the opposing side of the framebuffer.
-- @function[parent=#Canvas] setWrap
-- @param self self 
-- @param love.graphics#WrapMode horizontal Horizontal wrapping mode of the Canvas.
-- @param love.graphics#WrapMode vertical Vertical wrapping mode of the Canvas.
-- 


-------------------------------------------------------------------------------
-- Defines the shape of characters than can be drawn onto the screen.
-- @type Font
-- @extends love#Object

-------------------------------------------------------------------------------
-- Gets the ascent of the Font. The ascent spans the distance between the baseline and the top of the glyph that reaches farthest from the baseline.
-- @function[parent=#Font] getAscent
-- @param self self 
-- @return #number ascent The ascent of the Font in pixels.
-- 

-------------------------------------------------------------------------------
-- Gets the baseline of the Font. Most scripts share the notion of a baseline: an imaginary horizontal line on which characters rest. In some scripts, parts of glyphs lie below the baseline.
-- @function[parent=#Font] getBaseline
-- @param self self 
-- @return #number baseline The baseline of the Font in pixels.
-- 

-------------------------------------------------------------------------------
-- Gets the descent of the Font. The descent spans the distance between the baseline and the lowest descending glyph in a typeface.
-- @function[parent=#Font] getDescent
-- @param self self 
-- @return #number descent The descent of the Font in pixels.
-- 

-------------------------------------------------------------------------------
-- Gets the filter mode for a font.
-- @function[parent=#Font] getFilter
-- @param self self 
-- @return love.graphics#FilterMode min Filter mode used when minifying the font.
-- @return love.graphics#FilterMode mag Filter mode used when magnifying the font.
-- @return #number anisotropy Maximum amount of anisotropic filtering used.
-- 

-------------------------------------------------------------------------------
-- Gets the height of the Font. The height of the font is the size including any spacing; the height which it will need.
-- @function[parent=#Font] getHeight
-- @param self self 
-- @return #number height The height of the Font in pixels.
-- 

-------------------------------------------------------------------------------
-- Gets the line height. This will be the value previously set by Font:setLineHeight, or 1.0 by default.
-- @function[parent=#Font] getLineHeight
-- @param self self 
-- @return #number height The current line height.
-- 

-------------------------------------------------------------------------------
-- Determines the horizontal size a line of text needs. Does not support line-breaks.
-- @function[parent=#Font] getWidth
-- @param self self 
-- @param #string line A line of text.
-- @return #number width The width of the line.
-- 

-------------------------------------------------------------------------------
-- Gets formatting information for text, given a wrap limit.
-- 
-- This function accounts for newlines correctly (i.e. '\n').
-- @function[parent=#Font] getWrap
-- @param self self 
-- @param #string text The text that will be wrapped.
-- @param #number wraplimit The maximum width in pixels of each line that text is allowed before wrapping.
-- @return #number width The maximum width of the wrapped text.
-- @return #table wrappedtext A sequence containing each line of text that was wrapped.
-- 

-------------------------------------------------------------------------------
-- Gets whether the font can render a particular character.
-- @function[parent=#Font] hasGlyphs
-- @param self self 
-- @param #string character A unicode character.
-- @return #boolean hasglyph Whether the font can render the glyph represented by the character.
-- 

-------------------------------------------------------------------------------
-- Gets whether the font can render a particular character.
-- @function[parent=#Font] hasGlyphs
-- @param self self 
-- @param #number codepoint A unicode codepoint number.
-- @return #boolean hasglyph Whether the font can render the glyph represented by the codepoint number.
-- 

-------------------------------------------------------------------------------
-- Sets the fallback fonts. When the Font doesn't contain a glyph, it will substitute the glyph from the next subsequent fallback Fonts. This is akin to setting a "font stack" in Cascading Style Sheets (CSS).
-- @function[parent=#Font] setFallbacks
-- @param self self 
-- @param love.graphics#Font fallbackfont1 The first fallback Font to use.
-- @param love.graphics#Font ... Additional fallback Fonts.
-- 

-------------------------------------------------------------------------------
-- Sets the filter mode for a font.
-- @function[parent=#Font] setFilter
-- @param self self 
-- @param love.graphics#FilterMode min How to scale a font down.
-- @param love.graphics#FilterMode mag How to scale a font up.
-- @param #number anisotropy Maximum amount of anisotropic filtering used.
-- 

-------------------------------------------------------------------------------
-- Sets the line height. When rendering the font in lines the actual height will be determined by the line height multiplied by the height of the font. The default is 1.0.
-- @function[parent=#Font] setLineHeight
-- @param self self 
-- @param #number height The new line height.
-- 


-------------------------------------------------------------------------------
-- A 2D polygon mesh used for drawing arbitrary textured shapes.
-- @type Mesh
-- @extends love#Drawable
-- @extends love#Object

-------------------------------------------------------------------------------
-- Attaches a vertex attribute from a different Mesh onto this Mesh, for use when drawing. This can be used to share vertex attribute data between several different Meshes.
-- @function[parent=#Mesh] attachAttribute
-- @param self self 
-- @param #string name The name of the vertex attribute to attach.
-- @param love.graphics#Mesh mesh The Mesh to get the vertex attribute from.
-- 

-------------------------------------------------------------------------------
-- Gets the mode used when drawing the Mesh.
-- @function[parent=#Mesh] getDrawMode
-- @param self self 
-- @return love.graphics#MeshDrawMode mode The mode used when drawing the Mesh.
-- 

-------------------------------------------------------------------------------
-- Gets the range of vertices used when drawing the Mesh.
-- 
-- If the Mesh's draw range has not been set previously with Mesh:setDrawRange, this function will return nil.
-- @function[parent=#Mesh] getDrawRange
-- @param self self 
-- @return #number min The index of the first vertex used when drawing, or the index of the first value in the vertex map used if one is set for this Mesh.
-- @return #number max The index of the last vertex used when drawing, or the index of the last value in the vertex map used if one is set for this Mesh.
-- 

-------------------------------------------------------------------------------
-- Gets the texture (Image or Canvas) used when drawing the Mesh.
-- @function[parent=#Mesh] getTexture
-- @param self self 
-- @return love.graphics#Texture texture The Image or Canvas to texture the Mesh with when drawing, or nil if none is set.
-- 

-------------------------------------------------------------------------------
-- Gets the properties of a vertex in the Mesh.
-- @function[parent=#Mesh] getVertex
-- @param self self 
-- @param #number index The index of the the vertex you want to retrieve the information for.
-- @return #number attributecomponent The first component of the first vertex attribute in the specified vertex.
-- @return #number ... Additional components of all vertex attributes in the specified vertex.
-- 

-------------------------------------------------------------------------------
-- Gets the properties of a vertex in the Mesh.
-- @function[parent=#Mesh] getVertex
-- @param self self 
-- @param #number index The index of the the vertex you want to retrieve the information for.
-- @return #number x The position of the vertex on the x-axis.
-- @return #number y The position of the vertex on the y-axis.
-- @return #number u The horizontal component of the texture coordinate.
-- @return #number v The vertical component of the texture coordinate.
-- @return #number r The red component of the vertex's color.
-- @return #number g The green component of the vertex's color.
-- @return #number b The blue component of the vertex's color.
-- @return #number a The alpha component of the vertex's color.
-- 

-------------------------------------------------------------------------------
-- Gets the properties of a specific attribute within a vertex in the Mesh.
-- 
-- Meshes without a custom vertex format specified in love.graphics.newMesh have position as their first attribute, texture coordinates as their second attribute, and color as their third attribute.
-- @function[parent=#Mesh] getVertexAttribute
-- @param self self 
-- @param #number vertexindex The index of the the vertex to be modified.
-- @param #number attributeindex The index of the attribute within the vertex to be modified.
-- @return #number value1 The value of the first component of the attribute.
-- @return #number value2 The value of the second component of the attribute.
-- @return #number ... Any additional vertex attribute components.
-- 

-------------------------------------------------------------------------------
-- Returns the total number of vertices in the Mesh.
-- @function[parent=#Mesh] getVertexCount
-- @param self self 
-- @return #number num The total number of vertices in this Mesh.
-- 

-------------------------------------------------------------------------------
-- Gets the vertex format that the Mesh was created with.
-- @function[parent=#Mesh] getVertexFormat
-- @param self self 
-- @return #table format The vertex format of the Mesh, which is a table containing tables for each vertex attribute the Mesh was created with, in the form of {attribute, ...}.
-- 

-------------------------------------------------------------------------------
-- Gets the vertex map for the Mesh. The vertex map describes the order in which the vertices are used when the Mesh is drawn. The vertices, vertex map, and mesh draw mode work together to determine what exactly is displayed on the screen.
-- 
-- If no vertex map has been set previously via Mesh:setVertexMap, then this function will return nil in LÖVE 0.10.0+, or an empty table in 0.9.2 and older.
-- @function[parent=#Mesh] getVertexMap
-- @param self self 
-- @return #table map A table containing a list of vertex indices used when drawing.
-- 

-------------------------------------------------------------------------------
-- Gets whether a specific vertex attribute in the Mesh is enabled. Vertex data from disabled attributes is not used when drawing the Mesh.
-- @function[parent=#Mesh] isAttributeEnabled
-- @param self self 
-- @param #string name The name of the vertex attribute to enable or disable.
-- @return #boolean enabled Whether the vertex attribute is used when drawing this Mesh.
-- 

-------------------------------------------------------------------------------
-- Enables or disables a specific vertex attribute in the Mesh. Vertex data from disabled attributes is not used when drawing the Mesh.
-- @function[parent=#Mesh] setAttributeEnabled
-- @param self self 
-- @param #string name The name of the vertex attribute to enable or disable.
-- @param #boolean enable Whether the vertex attribute is used when drawing this Mesh.
-- 

-------------------------------------------------------------------------------
-- Sets the mode used when drawing the Mesh.
-- @function[parent=#Mesh] setDrawMode
-- @param self self 
-- @param love.graphics#MeshDrawMode mode The mode to use when drawing the Mesh.
-- 

-------------------------------------------------------------------------------
-- Restricts the drawn vertices of the Mesh to a subset of the total.
-- 
-- If a vertex map is used with the Mesh, this method will set a subset of the values in the vertex map array to use, instead of a subset of the total vertices in the Mesh.
-- 
-- For example, if Mesh:setVertexMap(1, 2, 3, 1, 3, 4) and Mesh:setDrawRange(4, 6) are called, vertices 1, 3, and 4 will be drawn.
-- @function[parent=#Mesh] setDrawRange
-- @param self self 
-- @param #number min The index of the first vertex to use when drawing, or the index of the first value in the vertex map to use if one is set for this Mesh.
-- @param #number max The index of the last vertex to use when drawing, or the index of the last value in the vertex map to use if one is set for this Mesh.
-- 

-------------------------------------------------------------------------------
-- Restricts the drawn vertices of the Mesh to a subset of the total.
-- 
-- If a vertex map is used with the Mesh, this method will set a subset of the values in the vertex map array to use, instead of a subset of the total vertices in the Mesh.
-- 
-- For example, if Mesh:setVertexMap(1, 2, 3, 1, 3, 4) and Mesh:setDrawRange(4, 6) are called, vertices 1, 3, and 4 will be drawn.
-- @function[parent=#Mesh] setDrawRange
-- @param self self 
-- 

-------------------------------------------------------------------------------
-- Sets the texture (Image or Canvas) used when drawing the Mesh.
-- 
-- When called without an argument disables the texture. Untextured meshes have a white color by default.
-- @function[parent=#Mesh] setTexture
-- @param self self 
-- 

-------------------------------------------------------------------------------
-- Sets the texture (Image or Canvas) used when drawing the Mesh.
-- 
-- When called without an argument disables the texture. Untextured meshes have a white color by default.
-- @function[parent=#Mesh] setTexture
-- @param self self 
-- @param love.graphics#Texture texture The Image or Canvas to texture the Mesh with when drawing.
-- 

-------------------------------------------------------------------------------
-- Sets the properties of a vertex in the Mesh.
-- @function[parent=#Mesh] setVertex
-- @param self self 
-- @param #number index The index of the the vertex you want to modify.
-- @param #number attributecomponent The first component of the first vertex attribute in the specified vertex.
-- @param #number ... Additional components of all vertex attributes in the specified vertex.
-- 

-------------------------------------------------------------------------------
-- Sets the properties of a vertex in the Mesh.
-- @function[parent=#Mesh] setVertex
-- @param self self 
-- @param #number index The index of the the vertex you want to modify.
-- @param #table vertex A table with vertex information, in the form of {attributecomponent, ...}.
-- 

-------------------------------------------------------------------------------
-- Sets the properties of a vertex in the Mesh.
-- @function[parent=#Mesh] setVertex
-- @param self self 
-- @param #number index The index of the the vertex you want to modify.
-- @param #number x The position of the vertex on the x-axis.
-- @param #number y The position of the vertex on the y-axis.
-- @param #number u The horizontal component of the texture coordinate.
-- @param #number v The vertical component of the texture coordinate.
-- @param #number r The red component of the vertex's color.
-- @param #number g The green component of the vertex's color.
-- @param #number b The blue component of the vertex's color.
-- @param #number a The alpha component of the vertex's color.
-- 

-------------------------------------------------------------------------------
-- Sets the properties of a vertex in the Mesh.
-- @function[parent=#Mesh] setVertex
-- @param self self 
-- @param #number index The index of the the vertex you want to modify.
-- @param #table vertex A table with vertex information.
-- 

-------------------------------------------------------------------------------
-- Sets the properties of a specific attribute within a vertex in the Mesh.
-- 
-- Meshes without a custom vertex format specified in love.graphics.newMesh have position as their first attribute, texture coordinates as their second attribute, and color as their third attribute.
-- @function[parent=#Mesh] setVertexAttribute
-- @param self self 
-- @param #number vertexindex The index of the the vertex to be modified.
-- @param #number attributeindex The index of the attribute within the vertex to be modified.
-- @param #number value1 The value of the first component of the attribute.
-- @param #number value2 The value of the second component of the attribute.
-- @param #number ... Any additional vertex attribute components.
-- 

-------------------------------------------------------------------------------
-- Sets if the per-vertex colors are used when rendering instead of the constant color (constant color being love.graphics.setColor or SpriteBatch:setColor)
-- 
-- The per-vertex colors are automatically enabled by default when making a new Mesh or when doing Mesh:setVertex, but only if at least one vertex color is not the default (255,255,255,255).
-- @function[parent=#Mesh] setVertexColors
-- @param self self 
-- @param #boolean on True to use per-vertex coloring.
-- 

-------------------------------------------------------------------------------
-- Sets the vertex map for the Mesh. The vertex map describes the order in which the vertices are used when the Mesh is drawn. The vertices, vertex map, and mesh draw mode work together to determine what exactly is displayed on the screen.
-- 
-- The vertex map allows you to re-order or reuse vertices when drawing without changing the actual vertex parameters or duplicating vertices. It is especially useful when combined with different Mesh Draw Modes.
-- @function[parent=#Mesh] setVertexMap
-- @param self self 
-- @param #table map A table containing a list of vertex indices to use when drawing. Values must be in the range of [1, Mesh:getVertexCount()].
-- 

-------------------------------------------------------------------------------
-- Sets the vertex map for the Mesh. The vertex map describes the order in which the vertices are used when the Mesh is drawn. The vertices, vertex map, and mesh draw mode work together to determine what exactly is displayed on the screen.
-- 
-- The vertex map allows you to re-order or reuse vertices when drawing without changing the actual vertex parameters or duplicating vertices. It is especially useful when combined with different Mesh Draw Modes.
-- @function[parent=#Mesh] setVertexMap
-- @param self self 
-- @param #number vi1 The index of the first vertex to use when drawing. Must be in the range of [1, Mesh:getVertexCount()].
-- @param #number vi2 The index of the second vertex to use when drawing.
-- @param #number vi3 The index of the third vertex to use when drawing.
-- 

-------------------------------------------------------------------------------
-- Replaces a range of vertices in the Mesh with new ones. The total number of vertices in a Mesh cannot be changed after it has been created.
-- @function[parent=#Mesh] setVertices
-- @param self self 
-- @param #table vertices The table filled with vertex information tables for each vertex, in the form of {vertex, ...} where each vertex is a table in the form of {attributecomponent, ...}.
-- 

-------------------------------------------------------------------------------
-- Replaces a range of vertices in the Mesh with new ones. The total number of vertices in a Mesh cannot be changed after it has been created.
-- @function[parent=#Mesh] setVertices
-- @param self self 
-- @param #table vertices The table filled with vertex information tables for each vertex as follows:
-- 


-------------------------------------------------------------------------------
-- Drawable image type.
-- @type Image
-- @extends love#Object
-- @extends love#Drawable
-- @extends love.graphics#Texture

-------------------------------------------------------------------------------
-- Gets the original ImageData or CompressedImageData used to create the Image.
-- 
-- All Images keep a reference to the Data that was used to create the Image. The Data is used to refresh the Image when love.window.setMode or Image:refresh is called.
-- @function[parent=#Image] getData
-- @param self self 
-- @return love.image#ImageData data The original ImageData used to create the Image, if the image is not compressed.
-- 

-------------------------------------------------------------------------------
-- Gets the original ImageData or CompressedImageData used to create the Image.
-- 
-- All Images keep a reference to the Data that was used to create the Image. The Data is used to refresh the Image when love.window.setMode or Image:refresh is called.
-- @function[parent=#Image] getData
-- @param self self 
-- @return love.image#CompressedImageData data The original CompressedImageData used to create the Image, if the image is compressed.
-- 

-------------------------------------------------------------------------------
-- Gets the width and height of the Image.
-- @function[parent=#Image] getDimensions
-- @param self self 
-- @return #number width The width of the Image, in pixels.
-- @return #number height The height of the Image, in pixels.
-- 

-------------------------------------------------------------------------------
-- Gets the filter mode for an image.
-- @function[parent=#Image] getFilter
-- @param self self 
-- @return love.graphics#FilterMode min Filter mode used when minifying the image.
-- @return love.graphics#FilterMode mag Filter mode used when magnifying the image.
-- 

-------------------------------------------------------------------------------
-- Gets the flags used when the image was created.
-- @function[parent=#Image] getFlags
-- @param self self 
-- @return #table flags A table with ImageFlag keys.
-- 

-------------------------------------------------------------------------------
-- Gets the height of the Image.
-- @function[parent=#Image] getHeight
-- @param self self 
-- @return #number height The height of the Image, in pixels.
-- 

-------------------------------------------------------------------------------
-- Gets the mipmap filter mode for an Image.
-- @function[parent=#Image] getMipmapFilter
-- @param self self 
-- @return love.graphics#FilterMode mode The filter mode used in between mipmap levels. nil if mipmap filtering is not enabled.
-- @return #number sharpness Value used to determine whether the image should use more or less detailed mipmap levels than normal when drawing.
-- 

-------------------------------------------------------------------------------
-- Gets the width of the Image.
-- @function[parent=#Image] getWidth
-- @param self self 
-- @return #number width The width of the Image, in pixels.
-- 

-------------------------------------------------------------------------------
-- Gets the wrapping properties of an Image.
-- 
-- This function returns the currently set horizontal and vertical wrapping modes for the image.
-- @function[parent=#Image] getWrap
-- @param self self 
-- @return love.graphics#WrapMode horizontal Horizontal wrapping mode of the image.
-- @return love.graphics#WrapMode vertical Vertical wrapping mode of the image.
-- 

-------------------------------------------------------------------------------
-- Reloads the Image's contents from the ImageData or CompressedImageData used to create the image.
-- @function[parent=#Image] refresh
-- @param self self 
-- 

-------------------------------------------------------------------------------
-- Reloads the Image's contents from the ImageData or CompressedImageData used to create the image.
-- @function[parent=#Image] refresh
-- @param self self 
-- @param #number x The x-axis of the top-left corner of the area within the Image to reload.
-- @param #number y The y-axis of the top-left corner of the area within the Image to reload.
-- @param #number width The width of the area within the Image to reload.
-- @param #number height The height of the area within the Image to reload.
-- 

-------------------------------------------------------------------------------
-- Sets the filter mode for an image.
-- @function[parent=#Image] setFilter
-- @param self self 
-- @param love.graphics#FilterMode min How to scale an image down.
-- @param love.graphics#FilterMode mag How to scale an image up.
-- 

-------------------------------------------------------------------------------
-- Sets the mipmap filter mode for an Image.
-- 
-- Mipmapping is useful when drawing an image at a reduced scale. It can improve performance and reduce aliasing issues.
-- 
-- In 0.10.0 and newer, the Image must be created with the mipmaps flag enabled for the mipmap filter to have any effect.
-- @function[parent=#Image] setMipmapFilter
-- @param self self 
-- @param love.graphics#FilterMode filtermode The filter mode to use in between mipmap levels. "nearest" will often give better performance.
-- @param #number sharpness A positive sharpness value makes the image use a more detailed mipmap level when drawing, at the expense of performance. A negative value does the reverse.
-- 

-------------------------------------------------------------------------------
-- Sets the mipmap filter mode for an Image.
-- 
-- Mipmapping is useful when drawing an image at a reduced scale. It can improve performance and reduce aliasing issues.
-- 
-- In 0.10.0 and newer, the Image must be created with the mipmaps flag enabled for the mipmap filter to have any effect.
-- @function[parent=#Image] setMipmapFilter
-- @param self self 
-- 

-------------------------------------------------------------------------------
-- Sets the wrapping properties of an Image.
-- 
-- This function sets the way an Image is repeated when it is drawn with a Quad that is larger than the image's extent. An image may be clamped or set to repeat in both horizontal and vertical directions. Clamped images appear only once, but repeated ones repeat as many times as there is room in the Quad.
-- 
-- If you use a Quad that is larger than the image extent and do not use repeated tiling, there may be an unwanted visual effect of the image stretching all the way to fill the Quad. If this is the case, setting Image:getWrap("repeat", "repeat") for all the images to be repeated, and using Quad of appropriate size will result in the best visual appearance.
-- @function[parent=#Image] setWrap
-- @param self self 
-- @param love.graphics#WrapMode horizontal Horizontal wrapping mode of the image.
-- @param love.graphics#WrapMode vertical Vertical wrapping mode of the image.
-- 


-------------------------------------------------------------------------------
-- Used to create cool effects, like fire. The particle systems are created and drawn on the screen using functions in love.graphics. They also need to be updated in the update(dt) callback for you to see any changes in the particles emitted.
-- @type ParticleSystem
-- @extends love#Drawable
-- @extends love#Object

-------------------------------------------------------------------------------
-- Creates an identical copy of the ParticleSystem in the stopped state.
-- 
-- Cloned ParticleSystem inherit all the set-able state of the original ParticleSystem, but they are initialized stopped.
-- @function[parent=#ParticleSystem] clone
-- @param self self 
-- @return love.graphics#ParticleSystem particlesystem The new identical copy of this ParticleSystem.
-- 

-------------------------------------------------------------------------------
-- Emits a burst of particles from the particle emitter.
-- @function[parent=#ParticleSystem] emit
-- @param self self 
-- @param #number numparticles The amount of particles to emit. The number of emitted particles will be truncated if the particle system's max buffer size is reached.
-- 

-------------------------------------------------------------------------------
-- Gets the amount of particles that are currently in the system.
-- @function[parent=#ParticleSystem] getCount
-- @param self self 
-- @return #number count The current number of live particles.
-- 

-------------------------------------------------------------------------------
-- Gets the area-based spawn parameters for the particles.
-- @function[parent=#ParticleSystem] getAreaSpread
-- @param self self 
-- @return love.graphics#AreaSpreadDistribution distribution The type of distribution for new particles.
-- @return #number dx The maximum spawn distance from the emitter along the x-axis for uniform distribution, or the standard deviation along the x-axis for normal distribution.
-- @return #number dy The maximum spawn distance from the emitter along the y-axis for uniform distribution, or the standard deviation along the y-axis for normal distribution.
-- 

-------------------------------------------------------------------------------
-- Gets the size of the buffer (the max allowed amount of particles in the system).
-- @function[parent=#ParticleSystem] getBufferSize
-- @param self self 
-- @return #number buffer The buffer size.
-- 

-------------------------------------------------------------------------------
-- Gets a series of colors to apply to the particle sprite. The particle system will interpolate between each color evenly over the particle's lifetime. Color modulation needs to be activated for this function to have any effect.
-- 
-- Arguments are passed in groups of four, representing the components of the desired RGBA value. At least one color must be specified. A maximum of eight may be used.
-- @function[parent=#ParticleSystem] getColors
-- @param self self 
-- @return #number r1 First color, red component (0-255).
-- @return #number g1 First color, green component (0-255).
-- @return #number b1 First color, blue component (0-255).
-- @return #number a1 First color, alpha component (0-255).
-- @return #number r2 Second color, red component (0-255).
-- @return #number g2 Second color, green component (0-255).
-- @return #number b2 Second color, blue component (0-255).
-- @return #number a2 Second color, alpha component (0-255).
-- @return #number ... Etc.
-- 

-------------------------------------------------------------------------------
-- Gets the direction the particles will be emitted in.
-- @function[parent=#ParticleSystem] getDirection
-- @param self self 
-- @return #number direction The direction of the particles (in radians).
-- 

-------------------------------------------------------------------------------
-- Gets the amount of particles emitted per second.
-- @function[parent=#ParticleSystem] getEmissionRate
-- @param self self 
-- @return #number rate The amount of particles per second.
-- 

-------------------------------------------------------------------------------
-- Gets the mode to use when the ParticleSystem adds new particles.
-- @function[parent=#ParticleSystem] getInsertMode
-- @param self self 
-- @return love.graphics#ParticleInsertMode mode The mode to use when the ParticleSystem adds new particles.
-- 

-------------------------------------------------------------------------------
-- Gets the linear acceleration (acceleration along the x and y axes) for particles.
-- 
-- Every particle created will accelerate along the x and y axes between xmin,ymin and xmax,ymax.
-- @function[parent=#ParticleSystem] getLinearAcceleration
-- @param self self 
-- @return #number xmin The minimum acceleration along the x axis.
-- @return #number ymin The minimum acceleration along the y axis.
-- @return #number xmax The maximum acceleration along the x axis.
-- @return #number ymax The maximum acceleration along the y axis.
-- 

-------------------------------------------------------------------------------
-- Gets the amount of linear damping (constant deceleration) for particles.
-- @function[parent=#ParticleSystem] getLinearDamping
-- @param self self 
-- @return #number min The minimum amount of linear damping applied to particles.
-- @return #number max The maximum amount of linear damping applied to particles.
-- 

-------------------------------------------------------------------------------
-- Gets how long the particle system should emit particles (if -1 then it emits particles forever).
-- @function[parent=#ParticleSystem] getEmitterLifetime
-- @param self self 
-- @return #number life The lifetime of the emitter (in seconds).
-- 

-------------------------------------------------------------------------------
-- Get the offget position which the particle sprite is rotated around. If this function is not used, the particles rotate around their center.
-- @function[parent=#ParticleSystem] getOffset
-- @param self self 
-- @return #number x The x coordinate of the rotation offget.
-- @return #number y The y coordinate of the rotation offget.
-- 

-------------------------------------------------------------------------------
-- Gets the life of the particles.
-- @function[parent=#ParticleSystem] getParticleLifetime
-- @param self self 
-- @return #number min The minimum life of the particles (seconds).
-- @return #number max The maximum life of the particles (seconds).
-- 

-------------------------------------------------------------------------------
-- Gets the position of the emitter.
-- @function[parent=#ParticleSystem] getPosition
-- @param self self 
-- @return #number x Position along x-axis.
-- @return #number y Position along y-axis.
-- 

-------------------------------------------------------------------------------
-- Get the radial acceleration (away from the emitter).
-- @function[parent=#ParticleSystem] getRadialAcceleration
-- @param self self 
-- @return #number min The minimum acceleration.
-- @return #number max The maximum acceleration.
-- 

-------------------------------------------------------------------------------
-- Gets the rotation of the image upon particle creation (in radians).
-- @function[parent=#ParticleSystem] getRotation
-- @param self self 
-- @return #number min The minimum initial angle (radians).
-- @return #number max The maximum initial angle (radians).
-- 

-------------------------------------------------------------------------------
-- Gets a series of sizes by which to scale a particle sprite. 1.0 is normal size. The particle system will interpolate between each size evenly over the particle's lifetime.
-- 
-- At least one size must be specified. A maximum of eight may be used.
-- @function[parent=#ParticleSystem] getSizes
-- @param self self 
-- @return #number size1 The first size.
-- @return #number size2 The second size.
-- @return #number ... Etc.
-- 

-------------------------------------------------------------------------------
-- Gets the degree of variation (0 meaning no variation and 1 meaning full variation between start and end).
-- @function[parent=#ParticleSystem] getSizeVariation
-- @param self self 
-- @return #number variation The degree of variation (0 meaning no variation and 1 meaning full variation between start and end).
-- 

-------------------------------------------------------------------------------
-- Gets the speed of the particles.
-- @function[parent=#ParticleSystem] getSpeed
-- @param self self 
-- @return #number min The minimum linear speed of the particles.
-- @return #number max The maximum linear speed of the particles.
-- 

-------------------------------------------------------------------------------
-- Gets the spin of the sprite.
-- @function[parent=#ParticleSystem] getSpin
-- @param self self 
-- @return #number min The minimum spin (radians per second).
-- @return #number max The maximum spin (radians per second).
-- 

-------------------------------------------------------------------------------
-- Gets the degree of variation (0 meaning no variation and 1 meaning full variation between start and end).
-- @function[parent=#ParticleSystem] getSpinVariation
-- @param self self 
-- @return #number variation The degree of variation (0 meaning no variation and 1 meaning full variation between start and end).
-- 

-------------------------------------------------------------------------------
-- Gets the amount of spread for the system.
-- @function[parent=#ParticleSystem] getSpread
-- @param self self 
-- @return #number spread The amount of spread (radians).
-- 

-------------------------------------------------------------------------------
-- Gets the Image or Canvas which is to be emitted.
-- @function[parent=#ParticleSystem] getTexture
-- @param self self 
-- @return love.graphics#Texture texture An Image or Canvas to use for the particle.
-- 

-------------------------------------------------------------------------------
-- Gets the tangential acceleration (acceleration perpendicular to the particle's direction).
-- @function[parent=#ParticleSystem] getTangentialAcceleration
-- @param self self 
-- @return #number min The minimum acceleration.
-- @return #number max The maximum acceleration.
-- 

-------------------------------------------------------------------------------
-- Gets whether particle angles and rotations are relative to their velocities. If enabled, particles are aligned to the angle of their velocities and rotate relative to that angle.
-- @function[parent=#ParticleSystem] hasRelativeRotation
-- @param self self 
-- @return #boolean enabled True if relative particle rotation is enabled, false if it's disabled.
-- 

-------------------------------------------------------------------------------
-- Checks whether the particle system is actively emitting particles.
-- @function[parent=#ParticleSystem] isActive
-- @param self self 
-- @return #boolean active True if system is active, false otherwise.
-- 

-------------------------------------------------------------------------------
-- Checks whether the particle system is paused.
-- @function[parent=#ParticleSystem] isPaused
-- @param self self 
-- @return #boolean paused True if system is paused, false otherwise.
-- 

-------------------------------------------------------------------------------
-- Checks whether the particle system is stopped.
-- @function[parent=#ParticleSystem] isStopped
-- @param self self 
-- @return #boolean stopped True if system is stopped, false otherwise.
-- 

-------------------------------------------------------------------------------
-- Moves the position of the emitter. This results in smoother particle spawning behaviour than if ParticleSystem:setPosition is used every frame.
-- @function[parent=#ParticleSystem] moveTo
-- @param self self 
-- @param #number x Position along x-axis.
-- @param #number y Position along y-axis.
-- 

-------------------------------------------------------------------------------
-- Pauses the particle emitter.
-- @function[parent=#ParticleSystem] pause
-- @param self self 
-- 

-------------------------------------------------------------------------------
-- Resets the particle emitter, removing any existing particles and resetting the lifetime counter.
-- @function[parent=#ParticleSystem] reset
-- @param self self 
-- 

-------------------------------------------------------------------------------
-- Sets area-based spawn parameters for the particles. Newly created particles will spawn in an area around the emitter based on the parameters to this function.
-- @function[parent=#ParticleSystem] setAreaSpread
-- @param self self 
-- @param love.graphics#AreaSpreadDistribution distribution The type of distribution for new particles.
-- @param #number dx The maximum spawn distance from the emitter along the x-axis for uniform distribution, or the standard deviation along the x-axis for normal distribution.
-- @param #number dy The maximum spawn distance from the emitter along the y-axis for uniform distribution, or the standard deviation along the y-axis for normal distribution.
-- 

-------------------------------------------------------------------------------
-- Sets the size of the buffer (the max allowed amount of particles in the system).
-- @function[parent=#ParticleSystem] setBufferSize
-- @param self self 
-- @param #number buffer The buffer size.
-- 

-------------------------------------------------------------------------------
-- Sets a series of colors to apply to the particle sprite. The particle system will interpolate between each color evenly over the particle's lifetime. Color modulation needs to be activated for this function to have any effect.
-- 
-- Arguments are passed in groups of four, representing the components of the desired RGBA value. At least one color must be specified. A maximum of eight may be used.
-- @function[parent=#ParticleSystem] setColors
-- @param self self 
-- @param #number r1 First color, red component (0-255).
-- @param #number g1 First color, green component (0-255).
-- @param #number b1 First color, blue component (0-255).
-- @param #number a1 First color, alpha component (0-255).
-- @param #number r2 Second color, red component (0-255).
-- @param #number g2 Second color, green component (0-255).
-- @param #number b2 Second color, blue component (0-255).
-- @param #number a2 Second color, alpha component (0-255).
-- @param #number ... Etc.
-- 

-------------------------------------------------------------------------------
-- Sets the direction the particles will be emitted in.
-- @function[parent=#ParticleSystem] setDirection
-- @param self self 
-- @param #number direction The direction of the particles (in radians).
-- 

-------------------------------------------------------------------------------
-- Sets the amount of particles emitted per second.
-- @function[parent=#ParticleSystem] setEmissionRate
-- @param self self 
-- @param #number rate The amount of particles per second.
-- 

-------------------------------------------------------------------------------
-- Sets how long the particle system should emit particles (if -1 then it emits particles forever).
-- @function[parent=#ParticleSystem] setEmitterLifetime
-- @param self self 
-- @param #number life The lifetime of the emitter (in seconds).
-- 

-------------------------------------------------------------------------------
-- Sets the mode to use when the ParticleSystem adds new particles.
-- @function[parent=#ParticleSystem] setInsertMode
-- @param self self 
-- @param love.graphics#ParticleInsertMode mode The mode to use when the ParticleSystem adds new particles.
-- 

-------------------------------------------------------------------------------
-- Sets the linear acceleration (acceleration along the x and y axes) for particles.
-- 
-- Every particle created will accelerate along the x and y axes between xmin,ymin and xmax,ymax.
-- @function[parent=#ParticleSystem] setLinearAcceleration
-- @param self self 
-- @param #number xmin The minimum acceleration along the x axis.
-- @param #number ymin The minimum acceleration along the y axis.
-- @param #number xmax The maximum acceleration along the x axis.
-- @param #number ymax The maximum acceleration along the y axis.
-- 

-------------------------------------------------------------------------------
-- Sets the amount of linear damping (constant deceleration) for particles.
-- @function[parent=#ParticleSystem] setLinearDamping
-- @param self self 
-- @param #number min The minimum amount of linear damping applied to particles.
-- @param #number max The maximum amount of linear damping applied to particles.
-- 

-------------------------------------------------------------------------------
-- Set the offset position which the particle sprite is rotated around. If this function is not used, the particles rotate around their center.
-- @function[parent=#ParticleSystem] setOffset
-- @param self self 
-- @param #number x The x coordinate of the rotation offset.
-- @param #number y The y coordinate of the rotation offset.
-- 

-------------------------------------------------------------------------------
-- Sets the life of the particles.
-- @function[parent=#ParticleSystem] setParticleLifetime
-- @param self self 
-- @param #number min The minimum life of the particles (seconds).
-- @param #number max The maximum life of the particles (seconds).
-- 

-------------------------------------------------------------------------------
-- Sets the position of the emitter.
-- @function[parent=#ParticleSystem] setPosition
-- @param self self 
-- @param #number x Position along x-axis.
-- @param #number y Position along y-axis.
-- 

-------------------------------------------------------------------------------
-- Sets a series of Quads to use for the particle sprites. Particles will choose a Quad from the list based on the particle's current lifetime, allowing for the use of animated sprite sheets with ParticleSystems.
-- @function[parent=#ParticleSystem] setQuads
-- @param self self 
-- @param love.graphics#Quad quad1 The first Quad to use.
-- @param love.graphics#Quad quad2 The second Quad to use.
-- 

-------------------------------------------------------------------------------
-- Set the radial acceleration (away from the emitter).
-- @function[parent=#ParticleSystem] setRadialAcceleration
-- @param self self 
-- @param #number min The minimum acceleration.
-- @param #number max The maximum acceleration.
-- 

-------------------------------------------------------------------------------
-- Sets whether particle angles and rotations are relative to their velocities. If enabled, particles are aligned to the angle of their velocities and rotate relative to that angle.
-- @function[parent=#ParticleSystem] setRelativeRotation
-- @param self self 
-- @param #boolean enable True to enable relative particle rotation, false to disable it.
-- 

-------------------------------------------------------------------------------
-- Sets the rotation of the image upon particle creation (in radians).
-- @function[parent=#ParticleSystem] setRotation
-- @param self self 
-- @param #number min The minimum initial angle (radians).
-- @param #number max The maximum initial angle (radians).
-- 

-------------------------------------------------------------------------------
-- Sets a series of sizes by which to scale a particle sprite. 1.0 is normal size. The particle system will interpolate between each size evenly over the particle's lifetime.
-- 
-- At least one size must be specified. A maximum of eight may be used.
-- @function[parent=#ParticleSystem] setSizes
-- @param self self 
-- @param #number size1 The first size.
-- @param #number size2 The second size.
-- @param #number ... Etc.
-- 

-------------------------------------------------------------------------------
-- Sets the degree of variation (0 meaning no variation and 1 meaning full variation between start and end).
-- @function[parent=#ParticleSystem] setSizeVariation
-- @param self self 
-- @param #number variation The degree of variation (0 meaning no variation and 1 meaning full variation between start and end).
-- 

-------------------------------------------------------------------------------
-- Sets the speed of the particles.
-- @function[parent=#ParticleSystem] setSpeed
-- @param self self 
-- @param #number min The minimum linear speed of the particles.
-- @param #number max The maximum linear speed of the particles.
-- 

-------------------------------------------------------------------------------
-- Sets the spin of the sprite.
-- @function[parent=#ParticleSystem] setSpin
-- @param self self 
-- @param #number min The minimum spin (radians per second).
-- @param #number max The maximum spin (radians per second).
-- 

-------------------------------------------------------------------------------
-- Sets the degree of variation (0 meaning no variation and 1 meaning full variation between start and end).
-- @function[parent=#ParticleSystem] setSpinVariation
-- @param self self 
-- @param #number variation The degree of variation (0 meaning no variation and 1 meaning full variation between start and end).
-- 

-------------------------------------------------------------------------------
-- Sets the amount of spread for the system.
-- @function[parent=#ParticleSystem] setSpread
-- @param self self 
-- @param #number spread The amount of spread (radians).
-- 

-------------------------------------------------------------------------------
-- Sets the Image or Canvas which is to be emitted.
-- @function[parent=#ParticleSystem] setTexture
-- @param self self 
-- @param love.graphics#Texture texture An Image or Canvas to use for the particle.
-- 

-------------------------------------------------------------------------------
-- Sets the tangential acceleration (acceleration perpendicular to the particle's direction).
-- @function[parent=#ParticleSystem] setTangentialAcceleration
-- @param self self 
-- @param #number min The minimum acceleration.
-- @param #number max The maximum acceleration.
-- 

-------------------------------------------------------------------------------
-- Starts the particle emitter.
-- @function[parent=#ParticleSystem] start
-- @param self self 
-- 

-------------------------------------------------------------------------------
-- Stops the particle emitter, resetting the lifetime counter.
-- @function[parent=#ParticleSystem] stop
-- @param self self 
-- 

-------------------------------------------------------------------------------
-- Updates the particle system; moving, creating and killing particles.
-- @function[parent=#ParticleSystem] update
-- @param self self 
-- @param #number dt The time (seconds) since last frame.
-- 


-------------------------------------------------------------------------------
-- A quadrilateral (a polygon with four sides and four corners) with texture coordinate information.
-- 
-- Quads can be used to select part of a texture to draw. In this way, one large texture atlas can be loaded, and then split up into sub-images.
-- @type Quad
-- @extends love#Object

-------------------------------------------------------------------------------
-- Gets reference texture dimensions initially specified in love.graphics.newQuad.
-- @function[parent=#Quad] getTextureDimensions
-- @param self self 
-- @return #number sw The Texture width used by the Quad.
-- @return #number sh The Texture height used by the Quad.
-- 

-------------------------------------------------------------------------------
-- Gets the current viewport of this Quad.
-- @function[parent=#Quad] getViewport
-- @param self self 
-- @return #number x The top-left corner along the x-axis.
-- @return #number y The top-right corner along the y-axis.
-- @return #number w The width of the viewport.
-- @return #number h The height of the viewport.
-- 

-------------------------------------------------------------------------------
-- Sets the texture coordinates according to a viewport.
-- @function[parent=#Quad] setViewport
-- @param self self 
-- @return #number x The top-left corner along the x-axis.
-- @return #number y The top-right corner along the y-axis.
-- @return #number w The width of the viewport.
-- @return #number h The height of the viewport.
-- 


-------------------------------------------------------------------------------
-- A Shader is used for advanced hardware-accelerated pixel or vertex manipulation. These effects are written in a language based on GLSL (OpenGL Shading Language) with a few things simplified for easier coding.
-- 
-- Potential uses for shaders include HDR/bloom, motion blur, grayscale/invert/sepia/any kind of color effect, reflection/refraction, distortions, bump mapping, and much more! Here is a collection of basic shaders and good starting point to learn: https://github.com/vrld/shine
-- @type Shader
-- @extends love#Object

-------------------------------------------------------------------------------
-- Gets information about an 'extern' ('uniform') variable in the shader.
-- @function[parent=#Shader] getExternVariable
-- @param self self 
-- @param #string name The name of the extern variable.
-- @return type The base type of the variable.
-- @return #number components The number of components in the variable (e.g. 2 for a vec2 or mat2.)
-- @return #number arrayelements The number of elements in the array if the variable is an array, or 1 if not.
-- 

-------------------------------------------------------------------------------
-- Returns any warning and error messages from compiling the shader code. This can be used for debugging your shaders if there's anything the graphics hardware doesn't like.
-- @function[parent=#Shader] getWarnings
-- @param self self 
-- @return #string warnings Warning messages (if any).
-- 

-------------------------------------------------------------------------------
-- Sends one or more values to a special (uniform) variable inside the shader. Uniform variables have to be marked using the uniform or extern keyword.
-- @function[parent=#Shader] send
-- @param self self 
-- @param #string name Name of the number to send to the shader.
-- @param #number number Number to send to store in the uniform variable.
-- @param #number ... Additional numbers to send if the uniform variable is an array.
-- 

-------------------------------------------------------------------------------
-- Sends one or more values to a special (uniform) variable inside the shader. Uniform variables have to be marked using the uniform or extern keyword.
-- @function[parent=#Shader] send
-- @param self self 
-- @param #string name Name of the vector to send to the shader.
-- @param #table vector Numbers to send to the uniform variable as a vector. The number of elements in the table determines the type of the vector (e.g. two numbers -> vec2). At least two and at most four numbers can be used.
-- @param #table ... Additional vectors to send if the uniform variable is an array. All vectors need to be of the same size (e.g. only vec3's).
-- 

-------------------------------------------------------------------------------
-- Sends one or more values to a special (uniform) variable inside the shader. Uniform variables have to be marked using the uniform or extern keyword.
-- @function[parent=#Shader] send
-- @param self self 
-- @param #string name Name of the matrix to send to the shader.
-- @param #table matrix 2x2, 3x3, or 4x4 matrix to send to the uniform variable. Using table form: {{a,b,c,d}, {e,f,g,h}, ... }.
-- @param #table ... Additional matrices of the same type as matrix to store in a uniform array.
-- 

-------------------------------------------------------------------------------
-- Sends one or more values to a special (uniform) variable inside the shader. Uniform variables have to be marked using the uniform or extern keyword.
-- @function[parent=#Shader] send
-- @param self self 
-- @param #string name Name of the Texture to send to the shader.
-- @param love.graphics#Texture texture Texture (Image or Canvas) to send to the uniform variable.
-- 

-------------------------------------------------------------------------------
-- Sends one or more values to a special (uniform) variable inside the shader. Uniform variables have to be marked using the uniform or extern keyword.
-- @function[parent=#Shader] send
-- @param self self 
-- @param #string name Name of the boolean to send to the shader.
-- @param #boolean boolean Boolean to send to store in the uniform variable.
-- @param #boolean ... Additional booleans to send if the uniform variable is an array.
-- 

-------------------------------------------------------------------------------
-- Sends one or more colors to a special (extern / uniform) vec3 or vec4 variable inside the shader. The color components must be in the range of [0, 255], unlike Shader:send. The colors are gamma-corrected if global gamma-correction is enabled.
-- @function[parent=#Shader] sendColor
-- @param self self 
-- @param #string name The name of the color extern variable to send to in the shader.
-- @param #table color A table with red, green, blue, and optional alpha color components in the range of [0, 255] to send to the extern as a vector.
-- @param #table ... Additional colors to send in case the extern is an array. All colors need to be of the same size (e.g. only vec3's).
-- 


-------------------------------------------------------------------------------
-- Using a single image, draw any number of identical copies of the image using a single call to love.graphics.draw. This can be used, for example, to draw repeating copies of a single background image.
-- 
-- A SpriteBatch can be even more useful when the underlying image is a Texture Atlas (a single image file containing many independent images); by adding Quad to the batch, different sub-images from within the atlas can be drawn.
-- @type SpriteBatch
-- @extends love#Drawable
-- @extends love#Object

-------------------------------------------------------------------------------
-- Add a sprite to the batch.
-- @function[parent=#SpriteBatch] add
-- @param self self 
-- @param #number x The position to draw the object (x-axis).
-- @param #number y The position to draw the object (y-axis).
-- @param #number r Orientation (radians).
-- @param #number sx Scale factor (x-axis).
-- @param #number sy Scale factor (y-axis).
-- @param #number ox Origin offset (x-axis).
-- @param #number oy Origin offset (y-axis).
-- @param #number kx Shear factor (x-axis).
-- @param #number ky Shear factor (y-axis).
-- @return #number id An identifier for the added sprite.
-- 

-------------------------------------------------------------------------------
-- Add a sprite to the batch.
-- @function[parent=#SpriteBatch] add
-- @param self self 
-- @param love.graphics#Quad quad The Quad to add.
-- @param #number x The position to draw the object (x-axis).
-- @param #number y The position to draw the object (y-axis).
-- @param #number r Orientation (radians).
-- @param #number sx Scale factor (x-axis).
-- @param #number sy Scale factor (y-axis).
-- @param #number ox Origin offset (x-axis).
-- @param #number oy Origin offset (y-axis).
-- @param #number kx Shear factor (x-axis).
-- @param #number ky Shear factor (y-axis).
-- @return #number id An identifier for the added sprite.
-- 

-------------------------------------------------------------------------------
-- Attaches a per-vertex attribute from a Mesh onto this SpriteBatch, for use when drawing. This can be combined with a Shader to augment a SpriteBatch with per-vertex or additional per-sprite information instead of just having per-sprite colors.
-- 
-- Each sprite in a SpriteBatch has 4 vertices in the following order: top-left, bottom-left, top-right, bottom-right. The index returned by SpriteBatch:add (and used by SpriteBatch:set) can be multiplied by 4 to determine the first vertex in a specific sprite.
-- @function[parent=#SpriteBatch] attachAttribute
-- @param self self 
-- @param #string name The name of the vertex attribute to attach.
-- @param love.graphics#Mesh mesh The Mesh to get the vertex attribute from.
-- 

-------------------------------------------------------------------------------
-- Removes all sprites from the buffer.
-- @function[parent=#SpriteBatch] clear
-- @param self self 
-- 

-------------------------------------------------------------------------------
-- Immediately sends all new and modified sprite data in the batch to the graphics card.
-- @function[parent=#SpriteBatch] flush
-- @param self self 
-- 

-------------------------------------------------------------------------------
-- Gets the maximum number of sprites the SpriteBatch can hold.
-- @function[parent=#SpriteBatch] getBufferSize
-- @param self self 
-- @return #number size The maximum number of sprites the batch can hold.
-- 

-------------------------------------------------------------------------------
-- Gets the color that will be used for the next add and set operations.
-- 
-- If no color has been set with SpriteBatch:setColor or the current SpriteBatch color has been cleared, this method will return nil.
-- @function[parent=#SpriteBatch] getColor
-- @param self self 
-- @return #number r The red component (0-255).
-- @return #number g The green component (0-255).
-- @return #number b The blue component (0-255).
-- @return #number a The alpha component (0-255).
-- 

-------------------------------------------------------------------------------
-- Gets the amount of sprites currently in the SpriteBatch.
-- @function[parent=#SpriteBatch] getCount
-- @param self self 
-- @return #number count The amount of sprites currently in the batch.
-- 

-------------------------------------------------------------------------------
-- Returns the Image or Canvas used by the SpriteBatch.
-- @function[parent=#SpriteBatch] getTexture
-- @param self self 
-- @return love.graphics#Texture texture The Image or Canvas for the sprites.
-- 

-------------------------------------------------------------------------------
-- Changes a sprite in the batch. This requires the identifier returned by add and addq.
-- @function[parent=#SpriteBatch] set
-- @param self self 
-- @param #number id The identifier of the sprite that will be changed.
-- @param #number x The position to draw the object (x-axis).
-- @param #number y The position to draw the object (y-axis).
-- @param #number r Orientation (radians).
-- @param #number sx Scale factor (x-axis).
-- @param #number sy Scale factor (y-axis).
-- @param #number ox Origin offset (x-axis).
-- @param #number oy Origin offset (y-axis).
-- @param #number kx Shear factor (x-axis).
-- @param #number ky Shear factor (y-axis).
-- 

-------------------------------------------------------------------------------
-- Changes a sprite in the batch. This requires the identifier returned by add and addq.
-- @function[parent=#SpriteBatch] set
-- @param self self 
-- @param #number id The identifier of the sprite that will be changed.
-- @param love.graphics#Quad quad The quad used on the image of the batch.
-- @param #number x The position to draw the object (x-axis).
-- @param #number y The position to draw the object (y-axis).
-- @param #number r Orientation (radians).
-- @param #number sx Scale factor (x-axis).
-- @param #number sy Scale factor (y-axis).
-- @param #number ox Origin offset (x-axis).
-- @param #number oy Origin offset (y-axis).
-- @param #number kx Shear factor (x-axis).
-- @param #number ky Shear factor (y-axis).
-- 

-------------------------------------------------------------------------------
-- Sets the maximum number of sprites the SpriteBatch can hold. Existing sprites in the batch (up to the new maximum) will not be cleared when this function is called.
-- @function[parent=#SpriteBatch] setBufferSize
-- @param self self 
-- @param #number size The new maximum number of sprites the batch can hold.
-- 

-------------------------------------------------------------------------------
-- Sets the color that will be used for the next add and set operations. Calling the function without arguments will clear the color.
-- 
-- In version [[0.9.2]] and older, the global color set with love.graphics.setColor will not work on the SpriteBatch if any of the sprites has its own color.
-- @function[parent=#SpriteBatch] setColor
-- @param self self 
-- @param #number r The amount of red.
-- @param #number g The amount of green.
-- @param #number b The amount of blue.
-- @param #number a The amount of alpha.
-- 

-------------------------------------------------------------------------------
-- Sets the color that will be used for the next add and set operations. Calling the function without arguments will clear the color.
-- 
-- In version [[0.9.2]] and older, the global color set with love.graphics.setColor will not work on the SpriteBatch if any of the sprites has its own color.
-- @function[parent=#SpriteBatch] setColor
-- @param self self 
-- 

-------------------------------------------------------------------------------
-- Replaces the Image or Canvas used for the sprites.
-- @function[parent=#SpriteBatch] setTexture
-- @param self self 
-- @param love.graphics#Texture texture The new Image or Canvas to use for the sprites.
-- 


-------------------------------------------------------------------------------
-- Drawable text.
-- @type Text
-- @extends love#Drawable
-- @extends love#Object

-------------------------------------------------------------------------------
-- Adds additional colored text to the Text object at the specified position.
-- @function[parent=#Text] add
-- @param self self 
-- @param #string textstring The text to add to the object.
-- @param #number x The position of the new text on the x-axis.
-- @param #number y The position of the new text on the y-axis.
-- @param #number angle The orientation of the new text in radians.
-- @param #number sx Scale factor on the x-axis.
-- @param #number sy Scale factor on the y-axis.
-- @param #number ox Origin offset on the x-axis.
-- @param #number oy Origin offset on the y-axis.
-- @param #number kx Shearing / skew factor on the x-axis.
-- @param #number ky Shearing / skew factor on the y-axis.
-- @return #number index An index number that can be used with Text:getWidth or Text:getHeight.
-- 

-------------------------------------------------------------------------------
-- Adds additional colored text to the Text object at the specified position.
-- @function[parent=#Text] add
-- @param self self 
-- @param #table coloredtext A table containing colors and strings to use as the new text, in the form of { color1, string1, color2, string2, ... }.
-- @param #number x The position of the new text on the x-axis.
-- @param #number y The position of the new text on the y-axis.
-- @param #number angle The orientation of the new text in radians.
-- @param #number sx Scale factor on the x-axis.
-- @param #number sy Scale factor on the y-axis.
-- @param #number ox Origin offset on the x-axis.
-- @param #number oy Origin offset on the y-axis.
-- @param #number kx Shearing / skew factor on the x-axis.
-- @param #number ky Shearing / skew factor on the y-axis.
-- @return #number index An index number that can be used with Text:getWidth or Text:getHeight.
-- 

-------------------------------------------------------------------------------
-- Adds additional formatted / colored text to the Text object at the specified position.
-- @function[parent=#Text] addf
-- @param self self 
-- @param #string textstring The text to add to the object.
-- @param #number wraplimit The maximum width in pixels of the text before it gets automatically wrapped to a new line.
-- @param love.graphics#AlignMode align The alignment of the text.
-- @param #number x The position of the new text on the x-axis.
-- @param #number y The position of the new text on the y-axis.
-- @param #number angle The orientation of the object in radians.
-- @param #number sx Scale factor on the x-axis.
-- @param #number sy Scale factor on the y-axis.
-- @param #number ox Origin offset on the x-axis.
-- @param #number oy Origin offset on the y-axis.
-- @param #number kx Shearing / skew factor on the x-axis.
-- @param #number ky Shearing / skew factor on the y-axis.
-- @return #number index An index number that can be used with Text:getWidth or Text:getHeight.
-- 

-------------------------------------------------------------------------------
-- Adds additional formatted / colored text to the Text object at the specified position.
-- @function[parent=#Text] addf
-- @param self self 
-- @param #table coloredtext A table containing colors and strings to use as the new text, in the form of { color1, string1, color2, string2, ... }.
-- @param #number wraplimit The maximum width in pixels of the text before it gets automatically wrapped to a new line.
-- @param love.graphics#AlignMode align The alignment of the text.
-- @param #number x The position of the new text on the x-axis.
-- @param #number y The position of the new text on the y-axis.
-- @param #number angle The orientation of the object in radians.
-- @param #number sx Scale factor on the x-axis.
-- @param #number sy Scale factor on the y-axis.
-- @param #number ox Origin offset on the x-axis.
-- @param #number oy Origin offset on the y-axis.
-- @param #number kx Shearing / skew factor on the x-axis.
-- @param #number ky Shearing / skew factor on the y-axis.
-- @return #number index An index number that can be used with Text:getWidth or Text:getHeight.
-- 

-------------------------------------------------------------------------------
-- Clears the contents of the Text object.
-- @function[parent=#Text] clear
-- @param self self 
-- 

-------------------------------------------------------------------------------
-- Gets the width and height of the text in pixels.
-- @function[parent=#Text] getDimensions
-- @param self self 
-- @return #number width The width of the text. If multiple sub-strings have been added with Text:add, the width of the last sub-string is returned.
-- @return #number height The height of the text. If multiple sub-strings have been added with Text:add, the height of the last sub-string is returned.
-- 

-------------------------------------------------------------------------------
-- Gets the width and height of the text in pixels.
-- @function[parent=#Text] getDimensions
-- @param self self 
-- @param #number index An index number returned by Text:add or Text:addf.
-- @return #number width The width of the sub-string (before scaling and other transformations).
-- @return #number height The height of the sub-string (before scaling and other transformations).
-- 

-------------------------------------------------------------------------------
-- Gets the Font used with the Text object.
-- @function[parent=#Text] getFont
-- @param self self 
-- @return love.graphics#Font font The font used with this Text object.
-- 

-------------------------------------------------------------------------------
-- Gets the height of the text in pixels.
-- @function[parent=#Text] getHeight
-- @param self self 
-- @return #number height The height of the text. If multiple sub-strings have been added with Text:add, the height of the last sub-string is returned.
-- 

-------------------------------------------------------------------------------
-- Gets the height of the text in pixels.
-- @function[parent=#Text] getHeight
-- @param self self 
-- @param #number index An index number returned by Text:add or Text:addf.
-- @return #number height The height of the sub-string (before scaling and other transformations).
-- 

-------------------------------------------------------------------------------
-- Gets the width of the text in pixels.
-- @function[parent=#Text] getWidth
-- @param self self 
-- @return #number width The width of the text. If multiple sub-strings have been added with Text:add, the width of the last sub-string is returned.
-- 

-------------------------------------------------------------------------------
-- Gets the width of the text in pixels.
-- @function[parent=#Text] getWidth
-- @param self self 
-- @param #number index An index number returned by Text:add or Text:addf.
-- @return #number width The width of the sub-string (before scaling and other transformations).
-- 

-------------------------------------------------------------------------------
-- Replaces the contents of the Text object with a new unformatted string.
-- @function[parent=#Text] set
-- @param self self 
-- @param #string textstring The new string of text to use.
-- 

-------------------------------------------------------------------------------
-- Replaces the contents of the Text object with a new unformatted string.
-- @function[parent=#Text] set
-- @param self self 
-- @param #table coloredtext A table containing colors and strings to use as the new text, in the form of { color1, string1, color2, string2, ... }.
-- 

-------------------------------------------------------------------------------
-- Replaces the contents of the Text object with a new unformatted string.
-- @function[parent=#Text] set
-- @param self self 
-- 

-------------------------------------------------------------------------------
-- Replaces the contents of the Text object with a new formatted string.
-- @function[parent=#Text] setf
-- @param self self 
-- @param #string textstring The new string of text to use.
-- @param #number wraplimit The maximum width in pixels of the text before it gets automatically wrapped to a new line.
-- @param love.graphics#AlignMode align The alignment of the text.
-- 

-------------------------------------------------------------------------------
-- Replaces the contents of the Text object with a new formatted string.
-- @function[parent=#Text] setf
-- @param self self 
-- @param #table coloredtext A table containing colors and strings to use as the new text, in the form of { color1, string1, color2, string2, ... }.
-- @param #number wraplimit The maximum width in pixels of the text before it gets automatically wrapped to a new line.
-- @param love.graphics#AlignMode align The alignment of the text.
-- 

-------------------------------------------------------------------------------
-- Replaces the contents of the Text object with a new formatted string.
-- @function[parent=#Text] setf
-- @param self self 
-- 

-------------------------------------------------------------------------------
-- Replaces the Font used with the text.
-- @function[parent=#Text] setFont
-- @param self self 
-- @param love.graphics#Font font The new font to use with this Text object.
-- 


-------------------------------------------------------------------------------
-- Superclass for drawable objects which represent a texture. All Textures can be drawn with Quads. This is an abstract type that can't be created directly.
-- @type Texture
-- @extends love#Drawable
-- @extends love#Object


-------------------------------------------------------------------------------
-- A drawable video.
-- @type Video
-- @extends love#Drawable
-- @extends love#Object

-------------------------------------------------------------------------------
-- Gets the width and height of the Video in pixels.
-- @function[parent=#Video] getDimensions
-- @param self self 
-- @return #number width The width of the Video.
-- @return #number height The height of the video.
-- 

-------------------------------------------------------------------------------
-- Gets the scaling filters used when drawing the Video.
-- @function[parent=#Video] getFilter
-- @param self self 
-- @return love.graphics#FilterMode min The filter mode used when scaling the Video down.
-- @return love.graphics#FilterMode mag The filter mode used when scaling the Video up.
-- @return #number anisotropy Maximum amount of anisotropic filtering used.
-- 

-------------------------------------------------------------------------------
-- Gets the height of the Video in pixels.
-- @function[parent=#Video] getHeight
-- @param self self 
-- @return #number height The height of the Video.
-- 

-------------------------------------------------------------------------------
-- Gets the audio Source used for playing back the video's audio. May return nil if the video has no audio, or if Video:setSource is called with a nil argument.
-- @function[parent=#Video] getSource
-- @param self self 
-- @return love.audio#Source source The audio Source used for audio playback, or nil if the video has no audio.
-- 

-------------------------------------------------------------------------------
-- Gets the VideoStream object used for decoding and controlling the video.
-- @function[parent=#Video] getStream
-- @param self self 
-- @return love.video#VideoStream stream The VideoStream used for decoding and controlling the video.
-- 

-------------------------------------------------------------------------------
-- Gets the width of the Video in pixels.
-- @function[parent=#Video] getWidth
-- @param self self 
-- @return #number width The width of the Video.
-- 

-------------------------------------------------------------------------------
-- Gets whether the Video is currently playing.
-- @function[parent=#Video] isPlaying
-- @param self self 
-- @return #boolean playing Whether the video is playing.
-- 

-------------------------------------------------------------------------------
-- Pauses the Video.
-- @function[parent=#Video] pause
-- @param self self 
-- 

-------------------------------------------------------------------------------
-- Starts playing the Video. In order for the video to appear onscreen it must be drawn with love.graphics.draw.
-- @function[parent=#Video] play
-- @param self self 
-- 

-------------------------------------------------------------------------------
-- Rewinds the Video to the beginning.
-- @function[parent=#Video] rewind
-- @param self self 
-- 

-------------------------------------------------------------------------------
-- Sets the current playback position of the Video.
-- @function[parent=#Video] seek
-- @param self self 
-- @param #number offset The time in seconds since the beginning of the Video.
-- 

-------------------------------------------------------------------------------
-- Sets the scaling filters used when drawing the Video.
-- @function[parent=#Video] setFilter
-- @param self self 
-- @param love.graphics#FilterMode min The filter mode used when scaling the Video down.
-- @param love.graphics#FilterMode mag The filter mode used when scaling the Video up.
-- @param #number anisotropy Maximum amount of anisotropic filtering used.
-- 

-------------------------------------------------------------------------------
-- Sets the audio Source used for playing back the video's audio. The audio Source also controls playback speed and synchronization.
-- @function[parent=#Video] setSource
-- @param self self 
-- @param love.audio#Source source The audio Source used for audio playback, or nil to disable audio synchronization.
-- 

-------------------------------------------------------------------------------
-- Gets the current playback position of the Video.
-- @function[parent=#Video] tell
-- @param self self 
-- @param #number seconds The time in seconds since the beginning of the Video.
-- 


-------------------------------------------------------------------------------
-- Draws a filled or unfilled arc at position (x, y). The arc is drawn from angle1 to angle2 in radians. The segments parameter determines how many segments are used to draw the arc. The more segments, the smoother the edge.
-- @function[parent=#love.graphics] arc
-- @param love.graphics#DrawMode drawmode How to draw the arc.
-- @param #number x The position of the center along x-axis.
-- @param #number y The position of the center along y-axis.
-- @param #number radius Radius of the arc.
-- @param #number angle1 The angle at which the arc begins.
-- @param #number angle2 The angle at which the arc terminates.
-- @param #number segments The number of segments used for drawing the arc.
-- 

-------------------------------------------------------------------------------
-- Draws a filled or unfilled arc at position (x, y). The arc is drawn from angle1 to angle2 in radians. The segments parameter determines how many segments are used to draw the arc. The more segments, the smoother the edge.
-- @function[parent=#love.graphics] arc
-- @param love.graphics#DrawMode drawmode How to draw the arc.
-- @param love.graphics#ArcType arctype The type of arc to draw.
-- @param #number x The position of the center along x-axis.
-- @param #number y The position of the center along y-axis.
-- @param #number radius Radius of the arc.
-- @param #number angle1 The angle at which the arc begins.
-- @param #number angle2 The angle at which the arc terminates.
-- @param #number segments The number of segments used for drawing the arc.
-- 

-------------------------------------------------------------------------------
-- Draws a circle.
-- @function[parent=#love.graphics] circle
-- @param love.graphics#DrawMode mode How to draw the circle.
-- @param #number x The position of the center along x-axis.
-- @param #number y The position of the center along y-axis.
-- @param #number radius The radius of the circle.
-- 

-------------------------------------------------------------------------------
-- Draws a circle.
-- @function[parent=#love.graphics] circle
-- @param love.graphics#DrawMode mode How to draw the circle.
-- @param #number x The position of the center along x-axis.
-- @param #number y The position of the center along y-axis.
-- @param #number radius The radius of the circle.
-- @param #number segments The number of segments used for drawing the circle. Note: The default variable for the segments parameter varies between different versions of LÖVE.
-- 

-------------------------------------------------------------------------------
-- Clears the screen to the background color in LÖVE 0.9.2 and earlier, or to the specified color in 0.10.0 and newer.
-- 
-- This function is called automatically before love.draw in the default love.run function. See the example in love.run for a typical use of this function.
-- 
-- Note that the scissor area bounds the cleared region.
-- @function[parent=#love.graphics] clear
-- 

-------------------------------------------------------------------------------
-- Clears the screen to the background color in LÖVE 0.9.2 and earlier, or to the specified color in 0.10.0 and newer.
-- 
-- This function is called automatically before love.draw in the default love.run function. See the example in love.run for a typical use of this function.
-- 
-- Note that the scissor area bounds the cleared region.
-- @function[parent=#love.graphics] clear
-- @param #number r The red channel of the color to clear the screen to.
-- @param #number g The green channel of the color to clear the screen to.
-- @param #number b The blue channel of the color to clear the screen to.
-- @param #number a The alpha channel of the color to clear the screen to.
-- 

-------------------------------------------------------------------------------
-- Clears the screen to the background color in LÖVE 0.9.2 and earlier, or to the specified color in 0.10.0 and newer.
-- 
-- This function is called automatically before love.draw in the default love.run function. See the example in love.run for a typical use of this function.
-- 
-- Note that the scissor area bounds the cleared region.
-- @function[parent=#love.graphics] clear
-- @param #table color A table in the form of {r, g, b, a} containing the color to clear the first active Canvas to.
-- @param #table ... Additional tables for each active Canvas.
-- 

-------------------------------------------------------------------------------
-- Discards (trashes) the contents of the screen or active Canvas. This is a performance optimization function with niche use cases.
-- 
-- If the active Canvas has just been changed and the "replace" BlendMode is about to be used to draw something which covers the entire screen, calling love.graphics.discard rather than calling love.graphics.clear or doing nothing may improve performance on mobile devices.
-- 
-- On some desktop systems this function may do nothing.
-- @function[parent=#love.graphics] discard
-- @param #boolean discardcolor Whether to discard the texture(s) of the active Canvas(es) (the contents of the screen if no Canvas is active).
-- @param #boolean discardstencil Whether to discard the contents of the stencil buffer of the screen / active Canvas.
-- 

-------------------------------------------------------------------------------
-- Discards (trashes) the contents of the screen or active Canvas. This is a performance optimization function with niche use cases.
-- 
-- If the active Canvas has just been changed and the "replace" BlendMode is about to be used to draw something which covers the entire screen, calling love.graphics.discard rather than calling love.graphics.clear or doing nothing may improve performance on mobile devices.
-- 
-- On some desktop systems this function may do nothing.
-- @function[parent=#love.graphics] discard
-- @param #table discardcolors An array containing boolean values indicating whether to discard the texture of each active Canvas, when multiple simultaneous Canvases are active.
-- @param #boolean discardstencil Whether to discard the contents of the stencil buffer of the screen / active Canvas.
-- 

-------------------------------------------------------------------------------
-- Draws a Drawable object (an Image, Canvas, SpriteBatch, ParticleSystem, Mesh, or Video) on the screen with optional rotation, scaling and shearing.
-- 
-- Objects are drawn relative to their local coordinate system. The origin is by default located at the top left corner of Image and Canvas. All scaling, shearing, and rotation arguments transform the object relative to that point. Also, the position of the origin can be specified on the screen coordinate system.
-- 
-- It's possible to rotate an object about its center by offsetting the origin to the center. Angles must be given in radians for rotation. One can also use a negative scaling factor to flip about its centerline.
-- 
-- Note that the offsets are applied before rotation, scaling, or shearing; scaling and shearing are applied before rotation.
-- 
-- The right and bottom edges of the object are shifted at an angle defined by the shearing factors.
-- @function[parent=#love.graphics] draw
-- @param love#Drawable drawable A drawable object.
-- @param #number x The position to draw the object (x-axis).
-- @param #number y The position to draw the object (y-axis).
-- @param #number r Orientation (radians).
-- @param #number sx Scale factor (x-axis). Can be negative.
-- @param #number sy Scale factor (y-axis). Can be negative.
-- @param #number ox Origin offset (x-axis). (A value of 20 would effectively move your drawable object 20 pixels to the left.)
-- @param #number oy Origin offset (y-axis). (A value of 20 would effectively move your drawable object 20 pixels up.)
-- @param #number kx Shearing factor (x-axis).
-- @param #number ky Shearing factor (y-axis).
-- 

-------------------------------------------------------------------------------
-- Draws a Drawable object (an Image, Canvas, SpriteBatch, ParticleSystem, Mesh, or Video) on the screen with optional rotation, scaling and shearing.
-- 
-- Objects are drawn relative to their local coordinate system. The origin is by default located at the top left corner of Image and Canvas. All scaling, shearing, and rotation arguments transform the object relative to that point. Also, the position of the origin can be specified on the screen coordinate system.
-- 
-- It's possible to rotate an object about its center by offsetting the origin to the center. Angles must be given in radians for rotation. One can also use a negative scaling factor to flip about its centerline.
-- 
-- Note that the offsets are applied before rotation, scaling, or shearing; scaling and shearing are applied before rotation.
-- 
-- The right and bottom edges of the object are shifted at an angle defined by the shearing factors.
-- @function[parent=#love.graphics] draw
-- @param love.graphics#Texture texture A Texture (Image or Canvas) to texture the Quad with.
-- @param love.graphics#Quad quad The Quad to draw on screen.
-- @param #number x The position to draw the object (x-axis).
-- @param #number y The position to draw the object (y-axis).
-- @param #number r Orientation (radians).
-- @param #number sx Scale factor (x-axis). Can be negative.
-- @param #number sy Scale factor (y-axis). Can be negative.
-- @param #number ox Origin offset (x-axis).
-- @param #number oy Origin offset (y-axis)
-- @param #number kx Shearing factor (x-axis).
-- @param #number ky Shearing factor (y-axis).
-- 

-------------------------------------------------------------------------------
-- Draws an ellipse.
-- @function[parent=#love.graphics] ellipse
-- @param love.graphics#DrawMode mode How to draw the ellipse.
-- @param #number x The position of the center along x-axis.
-- @param #number y The position of the center along y-axis.
-- @param #number radiusx The radius of the ellipse along the x-axis (half the ellipse's width.)
-- @param #number radiusy The radius of the ellipse along the y-axis (half the ellipse's height.)
-- 

-------------------------------------------------------------------------------
-- Draws an ellipse.
-- @function[parent=#love.graphics] ellipse
-- @param love.graphics#DrawMode mode How to draw the ellipse.
-- @param #number x The position of the center along x-axis.
-- @param #number y The position of the center along y-axis.
-- @param #number radiusx The radius of the ellipse along the x-axis (half the ellipse's width.)
-- @param #number radiusy The radius of the ellipse along the y-axis (half the ellipse's height.)
-- @param #number segments The number of segments used for drawing the ellipse.
-- 

-------------------------------------------------------------------------------
-- Gets the current background color.
-- @function[parent=#love.graphics] getBackgroundColor
-- @return #number r The red component (0-255).
-- @return #number g The green component (0-255).
-- @return #number b The blue component (0-255).
-- @return #number a The alpha component (0-255).
-- 

-------------------------------------------------------------------------------
-- Gets the blending mode.
-- @function[parent=#love.graphics] getBlendMode
-- @return love.graphics#BlendMode mode The current blend mode.
-- @return love.graphics#BlendAlphaMode alphamode The current blend alpha mode – it determines how the alpha of drawn objects affects blending.
-- 

-------------------------------------------------------------------------------
-- Gets the current target Canvas.
-- @function[parent=#love.graphics] getCanvas
-- @return love.graphics#Canvas canvas The Canvas set by setCanvas. Returns nil if drawing to the real screen.
-- 

-------------------------------------------------------------------------------
-- Gets the available Canvas formats, and whether each is supported.
-- @function[parent=#love.graphics] getCanvasFormats
-- @return #table formats A table containing CanvasFormats as keys, and a boolean indicating whether the format is supported as values. Not all systems support all formats.
-- 

-------------------------------------------------------------------------------
-- Gets the current color.
-- @function[parent=#love.graphics] getColor
-- @return #number r The red component (0-255).
-- @return #number g The red component (0-255).
-- @return #number b The blue component (0-255).
-- @return #number a The alpha component (0-255).
-- 

-------------------------------------------------------------------------------
-- Gets the active color components used when drawing. Normally all 4 components are active unless love.graphics.setColorMask has been used.
-- 
-- The color mask determines whether individual components of the colors of drawn objects will affect the color of the screen. They affect love.graphics.clear and Canvas:clear as well.
-- @function[parent=#love.graphics] getColorMask
-- @return #boolean r Whether the red color component is active when rendering.
-- @return #boolean g Whether the green color component is active when rendering.
-- @return #boolean b Whether the blue color component is active when rendering.
-- @return #boolean a Whether the alpha color component is active when rendering.
-- 

-------------------------------------------------------------------------------
-- Gets the available compressed image formats, and whether each is supported.
-- @function[parent=#love.graphics] getCompressedImageFormats
-- @return #table formats A table containing CompressedFormats as keys, and a boolean indicating whether the format is supported as values. Not all systems support all formats.
-- 

-------------------------------------------------------------------------------
-- Returns the default scaling filters used with Images, Canvases, and Fonts.
-- @function[parent=#love.graphics] getDefaultFilter
-- @return love.graphics#FilterMode min Filter mode used when scaling the image down.
-- @return love.graphics#FilterMode mag Filter mode used when scaling the image up.
-- @return #number anisotropy Maximum amount of Anisotropic Filtering used.
-- 

-------------------------------------------------------------------------------
-- Gets the width and height of the window.
-- @function[parent=#love.graphics] getDimensions
-- @return #number width The width of the window.
-- @return #number height The height of the window.
-- 

-------------------------------------------------------------------------------
-- Gets the current Font object.
-- @function[parent=#love.graphics] getFont
-- @return love.graphics#Font font The current Font, or nil if none is set.
-- 

-------------------------------------------------------------------------------
-- Gets the height of the window.
-- @function[parent=#love.graphics] getHeight
-- @return #number height The height of the window.
-- 

-------------------------------------------------------------------------------
-- Gets the line join style.
-- @function[parent=#love.graphics] getLineJoin
-- @return love.graphics#LineJoin join The LineJoin style.
-- 

-------------------------------------------------------------------------------
-- Gets the line style.
-- @function[parent=#love.graphics] getLineStyle
-- @return love.graphics#LineStyle style The current line style.
-- 

-------------------------------------------------------------------------------
-- Gets the current line width.
-- @function[parent=#love.graphics] getLineWidth
-- @return #number width The current line width.
-- 

-------------------------------------------------------------------------------
-- Returns the current Shader. Returns nil if none is set.
-- @function[parent=#love.graphics] getShader
-- @return love.graphics#Shader shader The current Shader.
-- 

-------------------------------------------------------------------------------
-- Gets performance-related rendering statistics.
-- @function[parent=#love.graphics] getStats
-- @return #number drawcalls The number of draw calls made so far during the current frame.
-- @return #number canvasswitches The number of times the active Canvas has been switched so far during the current frame.
-- @return #number texturememory The estimated total size in bytes of video memory used by all loaded Images, Canvases, and Fonts.
-- @return #number images The number of Image objects currently loaded.
-- @return #number canvases The number of Canvas objects currently loaded.
-- @return #number fonts The number of Font objects currently loaded.
-- @return #number shaderswitches The number of times the active Shader has been changed so far during the current frame.
-- 

-------------------------------------------------------------------------------
-- Gets whether stencil testing is enabled.
-- 
-- When stencil testing is enabled, the geometry of everything that is drawn will be clipped / stencilled out based on whether it intersects with what has been previously drawn to the stencil buffer.
-- 
-- Each Canvas has its own stencil buffer.
-- @function[parent=#love.graphics] getStencilTest
-- @return #boolean enabled Whether stencil testing is enabled.
-- @return #boolean inverted Whether the stencil test is inverted or not.
-- 

-------------------------------------------------------------------------------
-- Gets the optional graphics features and whether they're supported on the system.
-- 
-- Some older or low-end systems don't always support all graphics features.
-- @function[parent=#love.graphics] getSupported
-- @return #table features A table containing GraphicsFeature keys, and boolean values indicating whether each feature is supported.
-- 

-------------------------------------------------------------------------------
-- Gets the system-dependent maximum values for love.graphics features.
-- @function[parent=#love.graphics] getSystemLimits
-- @return #table limits A table containing GraphicsLimit keys, and number values.
-- 

-------------------------------------------------------------------------------
-- Gets the point size.
-- @function[parent=#love.graphics] getPointSize
-- @return #number size The current point size.
-- 

-------------------------------------------------------------------------------
-- Gets information about the system's video card and drivers.
-- @function[parent=#love.graphics] getRendererInfo
-- @return #string name The name of the renderer, e.g. "OpenGL" or "OpenGL ES".
-- @return #string version The version of the renderer with some extra driver-dependent version info, e.g. "2.1 INTEL-8.10.44".
-- @return #string vendor The name of the graphics card vendor, e.g. "Intel Inc".
-- @return #string device The name of the graphics card, e.g. "Intel HD Graphics 3000 OpenGL Engine".
-- 

-------------------------------------------------------------------------------
-- Gets the current scissor box.
-- @function[parent=#love.graphics] getScissor
-- @return #number x The x component of the top-left point of the box.
-- @return #number y The y component of the top-left point of the box.
-- @return #number width The width of the box.
-- @return #number height The height of the box.
-- 

-------------------------------------------------------------------------------
-- Gets the width of the window.
-- @function[parent=#love.graphics] getWidth
-- @return #number width The width of the window.
-- 

-------------------------------------------------------------------------------
-- Sets the scissor to the rectangle created by the intersection of the specified rectangle with the existing scissor. If no scissor is active yet, it behaves like love.graphics.setScissor.
-- 
-- The scissor limits the drawing area to a specified rectangle. This affects all graphics calls, including love.graphics.clear.
-- 
-- The dimensions of the scissor is unaffected by graphical transformations (translate, scale, ...).
-- @function[parent=#love.graphics] intersectScissor
-- @param #number x The x-coordinate of the upper left corner of the rectangle to intersect with the existing scissor rectangle.
-- @param #number y The y-coordinate of the upper left corner of the rectangle to intersect with the existing scissor rectangle.
-- @param #number width The width of the rectangle to intersect with the existing scissor rectangle.
-- @param #number height The height of the rectangle to intersect with the existing scissor rectangle.
-- 

-------------------------------------------------------------------------------
-- Sets the scissor to the rectangle created by the intersection of the specified rectangle with the existing scissor. If no scissor is active yet, it behaves like love.graphics.setScissor.
-- 
-- The scissor limits the drawing area to a specified rectangle. This affects all graphics calls, including love.graphics.clear.
-- 
-- The dimensions of the scissor is unaffected by graphical transformations (translate, scale, ...).
-- @function[parent=#love.graphics] intersectScissor
-- 

-------------------------------------------------------------------------------
-- Gets whether gamma-correct rendering is supported and enabled. It can be enabled by setting t.gammacorrect = true in love.conf.
-- 
-- Not all devices support gamma-correct rendering, in which case it will be automatically disabled and this function will return false. It is supported on desktop systems which have graphics cards that are capable of using OpenGL 3 / DirectX 10, and iOS devices that can use OpenGL ES 3.
-- @function[parent=#love.graphics] isGammaCorrect
-- @return #boolean gammacorrect True if gamma-correct rendering is supported and was enabled in love.conf, false otherwise.
-- 

-------------------------------------------------------------------------------
-- Gets whether wireframe mode is used when drawing.
-- @function[parent=#love.graphics] isWireframe
-- @return #boolean wireframe True if wireframe lines are used when drawing, false if it's not.
-- 

-------------------------------------------------------------------------------
-- Draws lines between points.
-- @function[parent=#love.graphics] line
-- @param #number x1 The position of first point on the x-axis.
-- @param #number y1 The position of first point on the y-axis.
-- @param #number x2 The position of second point on the x-axis.
-- @param #number y2 The position of second point on the y-axis.
-- @param #number ... You can continue passing point positions to draw a polyline.
-- 

-------------------------------------------------------------------------------
-- Draws lines between points.
-- @function[parent=#love.graphics] line
-- @param #table points A table of point positions.
-- 

-------------------------------------------------------------------------------
-- Creates a new Canvas object for offscreen rendering.
-- 
-- Antialiased Canvases have slightly higher system requirements than normal Canvases. Additionally, the supported maximum number of MSAA samples varies depending on the system. Use love.graphics.getSystemLimit to check.
-- 
-- If the number of MSAA samples specified is greater than the maximum supported by the system, the Canvas will still be created but only using the maximum supported amount (this includes 0.)
-- @function[parent=#love.graphics] newCanvas
-- @param #number width The width of the Canvas.
-- @param #number height The height of the Canvas.
-- @param love.graphics#CanvasFormat format The desired texture mode of the Canvas.
-- @param #number msaa The desired number of antialiasing samples used when drawing to the Canvas.
-- @return love.graphics#Canvas canvas A new Canvas object.
-- 

-------------------------------------------------------------------------------
-- Creates a new Font.
-- @function[parent=#love.graphics] newFont
-- @param #string filename The filepath to the font file.
-- @param #number size The size of the font in pixels.
-- @return love.graphics#Font font A Font object which can be used to draw text on screen.
-- 

-------------------------------------------------------------------------------
-- Creates a new Font.
-- @function[parent=#love.graphics] newFont
-- @param love.filesystem#File file A File pointing to a font.
-- @param #number size The size of the font in pixels.
-- @return love.graphics#Font font A Font object which can be used to draw text on screen.
-- 

-------------------------------------------------------------------------------
-- Creates a new Font.
-- @function[parent=#love.graphics] newFont
-- @param love.filesystem#FileData filedata The encoded data to decode into a font.
-- @param #number size The size of the font in pixels.
-- @return love.graphics#Font font A Font object which can be used to draw text on screen.
-- 

-------------------------------------------------------------------------------
-- Creates a new Font.
-- @function[parent=#love.graphics] newFont
-- @param #number size The size of the font in pixels.
-- @return love.graphics#Font font A Font object which can be used to draw text on screen.
-- 

-------------------------------------------------------------------------------
-- Creates a new Mesh.
-- 
-- Use Mesh:setTexture if the Mesh should be textured with an Image or Canvas when it's drawn.
-- @function[parent=#love.graphics] newMesh
-- @param #table vertices The table filled with vertex information tables for each vertex as follows:
-- @param love.graphics#MeshDrawMode mode How the vertices are used when drawing. The default mode "fan" is sufficient for simple convex polygons.
-- @param love.graphics#SpriteBatchUsage usage The expected usage of the Mesh. The specified usage mode affects the Mesh's memory usage and performance.
-- @return love.graphics#Mesh mesh The new Mesh.
-- 

-------------------------------------------------------------------------------
-- Creates a new Mesh.
-- 
-- Use Mesh:setTexture if the Mesh should be textured with an Image or Canvas when it's drawn.
-- @function[parent=#love.graphics] newMesh
-- @param #number vertexcount The total number of vertices the Mesh will use. Each vertex is initialized to {0,0, 0,0, 255,255,255,255}.
-- @param love.graphics#MeshDrawMode mode How the vertices are used when drawing. The default mode "fan" is sufficient for simple convex polygons.
-- @param love.graphics#SpriteBatchUsage usage The expected usage of the Mesh. The specified usage mode affects the Mesh's memory usage and performance.
-- @return love.graphics#Mesh mesh The new Mesh.
-- 

-------------------------------------------------------------------------------
-- Creates a new Mesh.
-- 
-- Use Mesh:setTexture if the Mesh should be textured with an Image or Canvas when it's drawn.
-- @function[parent=#love.graphics] newMesh
-- @param #table vertexformat A table in the form of {attribute, ...}. Each attribute is a table which specifies a custom vertex attribute used for each vertex.
-- @param #table vertices The table filled with vertex information tables for each vertex, in the form of {vertex, ...} where each vertex is a table in the form of {attributecomponent, ...}.
-- @param love.graphics#MeshDrawMode mode How the vertices are used when drawing. The default mode "fan" is sufficient for simple convex polygons.
-- @param love.graphics#SpriteBatchUsage usage The expected usage of the Mesh. The specified usage mode affects the Mesh's memory usage and performance.
-- @return love.graphics#Mesh mesh The new Mesh.
-- 

-------------------------------------------------------------------------------
-- Creates a new Mesh.
-- 
-- Use Mesh:setTexture if the Mesh should be textured with an Image or Canvas when it's drawn.
-- @function[parent=#love.graphics] newMesh
-- @param #table vertexformat A table in the form of {attribute, ...}. Each attribute is a table which specifies a custom vertex attribute used for each vertex.
-- @param #number vertexcount The total number of vertices the Mesh will use.
-- @param love.graphics#MeshDrawMode mode How the vertices are used when drawing. The default mode "fan" is sufficient for simple convex polygons.
-- @param love.graphics#SpriteBatchUsage usage The expected usage of the Mesh. The specified usage mode affects the Mesh's memory usage and performance.
-- @return love.graphics#Mesh mesh The new Mesh.
-- 

-------------------------------------------------------------------------------
-- Creates a new Image from a filepath, FileData, an ImageData, or a CompressedImageData, and optionally generates or specifies mipmaps for the image.
-- @function[parent=#love.graphics] newImage
-- @param #string filename The filepath to the image file.
-- @return love.graphics#Image image An Image object which can be drawn on screen.
-- 

-------------------------------------------------------------------------------
-- Creates a new Image from a filepath, FileData, an ImageData, or a CompressedImageData, and optionally generates or specifies mipmaps for the image.
-- @function[parent=#love.graphics] newImage
-- @param love.image#ImageData imageData An ImageData object. The Image will use this ImageData to reload itself when love.window.setMode is called.
-- @return love.graphics#Image image An Image object which can be drawn on screen.
-- 

-------------------------------------------------------------------------------
-- Creates a new Image from a filepath, FileData, an ImageData, or a CompressedImageData, and optionally generates or specifies mipmaps for the image.
-- @function[parent=#love.graphics] newImage
-- @param love.image#CompressedImageData compressedImageData A CompressedImageData object. The Image will use this CompressedImageData to reload itself when love.window.setMode is called.
-- @return love.graphics#Image image An Image object which can be drawn on screen.
-- 

-------------------------------------------------------------------------------
-- Creates a new Image from a filepath, FileData, an ImageData, or a CompressedImageData, and optionally generates or specifies mipmaps for the image.
-- @function[parent=#love.graphics] newImage
-- @param #string filename The filepath to the image file (or a FileData or ImageData or CompressedImageData object).
-- @param #table flags A table containing the following fields:
-- @return love.graphics#Image image An Image object which can be drawn on screen.
-- 

-------------------------------------------------------------------------------
-- Creates a new Font by loading a specifically formatted image.
-- 
-- In versions prior to 0.9.0, LÖVE expects ISO 8859-1 encoding for the glyphs string.
-- @function[parent=#love.graphics] newImageFont
-- @param #string filename The filepath to the image file.
-- @param #string glyphs A string of the characters in the image in order from left to right.
-- @return love.graphics#Font font A Font object which can be used to draw text on screen.
-- 

-------------------------------------------------------------------------------
-- Creates a new Font by loading a specifically formatted image.
-- 
-- In versions prior to 0.9.0, LÖVE expects ISO 8859-1 encoding for the glyphs string.
-- @function[parent=#love.graphics] newImageFont
-- @param love.image#ImageData imageData The ImageData object to create the font from.
-- @param #string glyphs A string of the characters in the image in order from left to right.
-- @return love.graphics#Font font A Font object which can be used to draw text on screen.
-- 

-------------------------------------------------------------------------------
-- Creates a new Font by loading a specifically formatted image.
-- 
-- In versions prior to 0.9.0, LÖVE expects ISO 8859-1 encoding for the glyphs string.
-- @function[parent=#love.graphics] newImageFont
-- @param #string filename The filepath to the image file.
-- @param #string glyphs A string of the characters in the image in order from left to right.
-- @param #number extraspacing Additional spacing (positive or negative) to apply to each glyph in the Font.
-- @return love.graphics#Font font A Font object which can be used to draw text on screen.
-- 

-------------------------------------------------------------------------------
-- Creates a new ParticleSystem.
-- @function[parent=#love.graphics] newParticleSystem
-- @param love.graphics#Texture texture The Image or Canvas to use.
-- @param #number buffer The max number of particles at the same time.
-- @return love.graphics#ParticleSystem system A new ParticleSystem.
-- 

-------------------------------------------------------------------------------
-- Creates a new Shader object for hardware-accelerated vertex and pixel effects. A Shader contains either vertex shader code, pixel shader code, or both.
-- 
-- Vertex shader code must contain at least one function, named position, which is the function that will produce transformed vertex positions of drawn objects in screen-space.
-- 
-- Pixel shader code must contain at least one function, named effect, which is the function that will produce the color which is blended onto the screen for each pixel a drawn object touches.
-- @function[parent=#love.graphics] newShader
-- @param #string code The pixel shader or vertex shader code, or a filename pointing to a file with the code.
-- @return love.graphics#Shader shader A Shader object for use in drawing operations.
-- 

-------------------------------------------------------------------------------
-- Creates a new Shader object for hardware-accelerated vertex and pixel effects. A Shader contains either vertex shader code, pixel shader code, or both.
-- 
-- Vertex shader code must contain at least one function, named position, which is the function that will produce transformed vertex positions of drawn objects in screen-space.
-- 
-- Pixel shader code must contain at least one function, named effect, which is the function that will produce the color which is blended onto the screen for each pixel a drawn object touches.
-- @function[parent=#love.graphics] newShader
-- @param #string pixelcode The pixel shader code, or a filename pointing to a file with the code.
-- @param #string vertexcode The vertex shader code, or a filename pointing to a file with the code.
-- @return love.graphics#Shader shader A Shader object for use in drawing operations.
-- 

-------------------------------------------------------------------------------
-- Creates a new Font.
-- @function[parent=#love.graphics] newText
-- @param love.graphics#Font font The font to use for the text.
-- @param #string textstring The initial string of text that the new Text object will contain. May be nil.
-- @return love.graphics#Text text The new drawable Text object.
-- 

-------------------------------------------------------------------------------
-- Creates a new Quad.
-- 
-- The purpose of a Quad is to describe the result of the following transformation on any drawable object. The object is first scaled to dimensions sw * sh. The Quad then describes the rectangular area of dimensions width * height whose upper left corner is at position (x, y) inside the scaled object.
-- @function[parent=#love.graphics] newQuad
-- @param #number x The top-left position along the x-axis.
-- @param #number y The top-left position along the y-axis.
-- @param #number width The width of the Quad.
-- @param #number height The height of the Quad.
-- @param #number sw The reference width, the width of the Image.
-- @param #number sh The reference height, the height of the Image.
-- @return love.graphics#Quad quad The new Quad.
-- 

-------------------------------------------------------------------------------
-- Creates a screenshot and returns the image data.
-- @function[parent=#love.graphics] newScreenshot
-- @param #boolean copyAlpha Whether to include the screen's alpha channel in the ImageData. If false, the screenshot will be fully opaque.
-- @return love.image#ImageData screenshot The image data of the screenshot.
-- 

-------------------------------------------------------------------------------
-- Creates a new SpriteBatch object.
-- @function[parent=#love.graphics] newSpriteBatch
-- @param love.graphics#Texture texture The Image or Canvas to use for the sprites.
-- @param #number maxsprites The max number of sprites.
-- @param love.graphics#SpriteBatchUsage usage The expected usage of the SpriteBatch. The specified usage mode affects the SpriteBatch's memory usage and performance.
-- @return love.graphics#SpriteBatch spriteBatch The new SpriteBatch.
-- 

-------------------------------------------------------------------------------
-- Creates a new drawable Video. Currently only Ogg Theora video files are supported.
-- @function[parent=#love.graphics] newVideo
-- @param #string filename The file path to the Ogg Theora video file.
-- @param #boolean loadaudio Whether to try to load the video's audio into an audio Source. If not explicitly set to true or false, it will try without causing an error if the video has no audio.
-- @return love.graphics#Video video A new Video.
-- 

-------------------------------------------------------------------------------
-- Creates a new drawable Video. Currently only Ogg Theora video files are supported.
-- @function[parent=#love.graphics] newVideo
-- @param love.video#VideoStream videostream A video stream object.
-- @param #boolean loadaudio Whether to try to load the video's audio into an audio Source. If not explicitly set to true or false, it will try without causing an error if the video has no audio.
-- @return love.graphics#Video video A new Video.
-- 

-------------------------------------------------------------------------------
-- Resets the current coordinate transformation.
-- 
-- This function is always used to reverse any previous calls to love.graphics.rotate, love.graphics.scale, love.graphics.shear or love.graphics.translate. It returns the current transformation state to its defaults.
-- @function[parent=#love.graphics] origin
-- 

-------------------------------------------------------------------------------
-- Draws one or more points.
-- @function[parent=#love.graphics] points
-- @param #number x The position of the first point on the x-axis.
-- @param #number y The position of the first point on the y-axis.
-- @param #number ... The x and y coordinates of additional points.
-- 

-------------------------------------------------------------------------------
-- Draws one or more points.
-- @function[parent=#love.graphics] points
-- @param #table points A table containing multiple point positions, in the form of {x, y, ...}.
-- 

-------------------------------------------------------------------------------
-- Draws one or more points.
-- @function[parent=#love.graphics] points
-- @param #table points A table containing multiple individually colored points, in the form of {point, ...}. Each table contains the position and color of a point in the form of {x, y, r, g, b, a}. The color components are optional.
-- 

-------------------------------------------------------------------------------
-- Draw a polygon.
-- 
-- Following the mode argument, this function can accept multiple numeric arguments or a single table of numeric arguments. In either case the arguments are interpreted as alternating x and y coordinates of the polygon's vertices.
-- 
-- When in fill mode, the polygon must be convex and simple or rendering artifacts may occur.
-- @function[parent=#love.graphics] polygon
-- @param love.graphics#DrawMode mode How to draw the polygon.
-- @param #number ... The vertices of the polygon.
-- 

-------------------------------------------------------------------------------
-- Draw a polygon.
-- 
-- Following the mode argument, this function can accept multiple numeric arguments or a single table of numeric arguments. In either case the arguments are interpreted as alternating x and y coordinates of the polygon's vertices.
-- 
-- When in fill mode, the polygon must be convex and simple or rendering artifacts may occur.
-- @function[parent=#love.graphics] polygon
-- @param love.graphics#DrawMode mode How to draw the polygon.
-- @param #table vertices The vertices of the polygon as a table.
-- 

-------------------------------------------------------------------------------
-- Pops the current coordinate transformation from the transformation stack.
-- 
-- This function is always used to reverse a previous push operation. It returns the current transformation state to what it was before the last preceding push. For an example, see the description of love.graphics.push.
-- @function[parent=#love.graphics] pop
-- 

-------------------------------------------------------------------------------
-- Displays the results of drawing operations on the screen.
-- 
-- This function is used when writing your own love.run function. It presents all the results of your drawing operations on the screen. See the example in love.run for a typical use of this function.
-- @function[parent=#love.graphics] present
-- 

-------------------------------------------------------------------------------
-- Draws text on screen. If no Font is set, one will be created and set (once) if needed.
-- 
-- As of LOVE 0.7.1, when using translation and scaling functions while drawing text, this function assumes the scale occurs first. If you don't script with this in mind, the text won't be in the right position, or possibly even on screen.
-- 
-- love.graphics.print and love.graphics.printf both suppport UTF-8 encoding. You'll also need a proper Font for special characters.
-- @function[parent=#love.graphics] print
-- @param #string text The text to draw.
-- @param #number x The position to draw the object (x-axis).
-- @param #number y The position to draw the object (y-axis).
-- @param #number r Orientation (radians).
-- @param #number sx Scale factor (x-axis).
-- @param #number sy Scale factor (y-axis).
-- @param #number ox Origin offset (x-axis).
-- @param #number oy Origin offset (y-axis).
-- @param #number kx Shear factor (x-axis).
-- @param #number ky Shear factor (y-axis).
-- 

-------------------------------------------------------------------------------
-- Draws text on screen. If no Font is set, one will be created and set (once) if needed.
-- 
-- As of LOVE 0.7.1, when using translation and scaling functions while drawing text, this function assumes the scale occurs first. If you don't script with this in mind, the text won't be in the right position, or possibly even on screen.
-- 
-- love.graphics.print and love.graphics.printf both suppport UTF-8 encoding. You'll also need a proper Font for special characters.
-- @function[parent=#love.graphics] print
-- @param #table coloredtext A table containing colors and strings to add to the object, in the form of {color1, string1, color2, string2, ...}.
-- @param #number x The position of the new text on the x-axis.
-- @param #number y The position of the new text on the y-axis.
-- @param #number angle The orientation of the object in radians.
-- @param #number sx Scale factor on the x-axis.
-- @param #number sy Scale factor on the y-axis.
-- @param #number ox Origin offset on the x-axis.
-- @param #number oy Origin offset on the y-axis.
-- @param #number kx Shearing / skew factor on the x-axis.
-- @param #number ky Shearing / skew factor on the y-axis.
-- 

-------------------------------------------------------------------------------
-- Draws formatted text, with word wrap and alignment.
-- 
-- See additional notes in love.graphics.print.
-- 
-- In version 0.9.2 and earlier, wrapping was implemented by breaking up words by spaces and putting them back together to make sure things fit nicely within the limit provided. However, due to the way this is done, extra spaces between words would end up missing when printed on the screen, and some lines could overflow past the provided wrap limit. In version 0.10.0 and newer this is no longer the case.
-- @function[parent=#love.graphics] printf
-- @param #string text A text string.
-- @param #number x The position on the x-axis.
-- @param #number y The position on the y-axis.
-- @param #number limit Wrap the line after this many horizontal pixels.
-- @param love.graphics#AlignMode align The alignment.
-- @param #number r Orientation (radians).
-- @param #number sx Scale factor (x-axis).
-- @param #number sy Scale factor (y-axis).
-- @param #number ox Origin offset (x-axis).
-- @param #number oy Origin offset (y-axis).
-- @param #number kx Shear factor (x-axis).
-- @param #number ky Shear factor (y-axis).
-- 

-------------------------------------------------------------------------------
-- Draws formatted text, with word wrap and alignment.
-- 
-- See additional notes in love.graphics.print.
-- 
-- In version 0.9.2 and earlier, wrapping was implemented by breaking up words by spaces and putting them back together to make sure things fit nicely within the limit provided. However, due to the way this is done, extra spaces between words would end up missing when printed on the screen, and some lines could overflow past the provided wrap limit. In version 0.10.0 and newer this is no longer the case.
-- @function[parent=#love.graphics] printf
-- @param #table coloredtext A table containing colors and strings to add to the object, in the form of {color1, string1, color2, string2, ...}.
-- @param #number x The position of the new text on the x-axis.
-- @param #number y The position of the new text on the y-axis.
-- @param #number wraplimit The maximum width in pixels of the text before it gets automatically wrapped to a new line.
-- @param love.graphics#AlignMode align The alignment of the text.
-- @param #number angle The orientation of the object in radians.
-- @param #number sx Scale factor on the x-axis.
-- @param #number sy Scale factor on the y-axis.
-- @param #number ox Origin offset on the x-axis.
-- @param #number oy Origin offset on the y-axis.
-- @param #number kx Shearing / skew factor on the x-axis.
-- @param #number ky Shearing / skew factor on the y-axis.
-- 

-------------------------------------------------------------------------------
-- Copies and pushes the current coordinate transformation to the transformation stack.
-- 
-- This function is always used to prepare for a corresponding pop operation later. It stores the current coordinate transformation state into the transformation stack and keeps it active. Later changes to the transformation can be undone by using the pop operation, which returns the coordinate transform to the state it was in before calling push.
-- @function[parent=#love.graphics] push
-- @param love.graphics#StackType stack The type of stack to push (e.g. just transformation state, or all love.graphics state).
-- 

-------------------------------------------------------------------------------
-- Draws a rectangle.
-- @function[parent=#love.graphics] rectangle
-- @param love.graphics#DrawMode mode How to draw the rectangle.
-- @param #number x The position of top-left corner along the x-axis.
-- @param #number y The position of top-left corner along the y-axis.
-- @param #number width Width of the rectangle.
-- @param #number height Height of the rectangle.
-- 

-------------------------------------------------------------------------------
-- Draws a rectangle.
-- @function[parent=#love.graphics] rectangle
-- @param love.graphics#DrawMode mode How to draw the rectangle.
-- @param #number x The position of top-left corner along the x-axis.
-- @param #number y The position of top-left corner along the y-axis.
-- @param #number width Width of the rectangle.
-- @param #number height Height of the rectangle.
-- @param #number rx The x-axis radius of each round corner. Cannot be greater than half the rectangle's width.
-- @param #number ry The y-axis radius of each round corner. Cannot be greater than half the rectangle's height.
-- @param #number segments The number of segments used for drawing the round corners. A default amount will be chosen if no number is given.
-- 

-------------------------------------------------------------------------------
-- Resets the current graphics settings.
-- 
-- Calling reset makes the current drawing color white, the current background color black, resets any active Canvas or Shader, and removes any scissor settings. It sets the BlendMode to alpha. It also sets both the point and line drawing modes to smooth and their sizes to 1.0.
-- @function[parent=#love.graphics] reset
-- 

-------------------------------------------------------------------------------
-- Rotates the coordinate system in two dimensions.
-- 
-- Calling this function affects all future drawing operations by rotating the coordinate system around the origin by the given amount of radians. This change lasts until love.draw exits.
-- @function[parent=#love.graphics] rotate
-- @param #number angle The amount to rotate the coordinate system in radians.
-- 

-------------------------------------------------------------------------------
-- Scales the coordinate system in two dimensions.
-- 
-- By default the coordinate system in LÖVE corresponds to the display pixels in horizontal and vertical directions one-to-one, and the x-axis increases towards the right while the y-axis increases downwards. Scaling the coordinate system changes this relation.
-- 
-- After scaling by sx and sy, all coordinates are treated as if they were multiplied by sx and sy. Every result of a drawing operation is also correspondingly scaled, so scaling by (2, 2) for example would mean making everything twice as large in both x- and y-directions. Scaling by a negative value flips the coordinate system in the corresponding direction, which also means everything will be drawn flipped or upside down, or both. Scaling by zero is not a useful operation.
-- 
-- Scale and translate are not commutative operations, therefore, calling them in different orders will change the outcome.
-- 
-- Scaling lasts until love.draw exits.
-- @function[parent=#love.graphics] scale
-- @param #number sx The scaling in the direction of the x-axis.
-- @param #number sy The scaling in the direction of the y-axis. If omitted, it defaults to same as parameter sx.
-- 

-------------------------------------------------------------------------------
-- Sets the background color.
-- @function[parent=#love.graphics] setBackgroundColor
-- @param #number r The red component (0-255).
-- @param #number g The green component (0-255).
-- @param #number b The blue component (0-255).
-- @param #number a The alpha component (0-255).
-- 

-------------------------------------------------------------------------------
-- Sets the background color.
-- @function[parent=#love.graphics] setBackgroundColor
-- @param #table rgba A numerical indexed table with the red, green and blue values as numbers. Alpha is 255 if it is not in the table
-- 

-------------------------------------------------------------------------------
-- Sets the blending mode.
-- @function[parent=#love.graphics] setBlendMode
-- @param love.graphics#BlendMode mode The blend mode to use.
-- 

-------------------------------------------------------------------------------
-- Sets the blending mode.
-- @function[parent=#love.graphics] setBlendMode
-- @param love.graphics#BlendMode mode The blend mode to use.
-- @param love.graphics#BlendAlphaMode alphamode What to do with the alpha of drawn objects when blending.
-- 

-------------------------------------------------------------------------------
-- Captures drawing operations to a Canvas.
-- @function[parent=#love.graphics] setCanvas
-- @param love.graphics#Canvas canvas A render target.
-- @param love.graphics#Canvas ... Additional render targets.
-- 

-------------------------------------------------------------------------------
-- Captures drawing operations to a Canvas.
-- @function[parent=#love.graphics] setCanvas
-- 

-------------------------------------------------------------------------------
-- Captures drawing operations to a Canvas.
-- @function[parent=#love.graphics] setCanvas
-- @param love.graphics#Canvas canvas1 The first render target.
-- @param love.graphics#Canvas canvas2 The second render target.
-- @param love.graphics#Canvas ... More canvases.
-- 

-------------------------------------------------------------------------------
-- Sets the color used for drawing.
-- @function[parent=#love.graphics] setColor
-- @param #number red The amount of red.
-- @param #number green The amount of green.
-- @param #number blue The amount of blue.
-- @param #number alpha The amount of alpha. The alpha value will be applied to all subsequent draw operations, even the drawing of an image.
-- 

-------------------------------------------------------------------------------
-- Sets the color used for drawing.
-- @function[parent=#love.graphics] setColor
-- @param #table rgba A numerical indexed table with the red, green, blue and alpha values as numbers. The alpha is optional and defaults to 255 if it is left out.
-- 

-------------------------------------------------------------------------------
-- Sets the color mask. Enables or disables specific color components when rendering and clearing the screen. For example, if red is set to false, no further changes will be made to the red component of any pixels.
-- 
-- Enables all color components when called without arguments.
-- @function[parent=#love.graphics] setColorMask
-- @param #boolean red Render red component.
-- @param #boolean green Render green component.
-- @param #boolean blue Render blue component.
-- @param #boolean alpha Render alpha component.
-- 

-------------------------------------------------------------------------------
-- Sets the color mask. Enables or disables specific color components when rendering and clearing the screen. For example, if red is set to false, no further changes will be made to the red component of any pixels.
-- 
-- Enables all color components when called without arguments.
-- @function[parent=#love.graphics] setColorMask
-- 

-------------------------------------------------------------------------------
-- Sets the default scaling filters used with Images, Canvases, and Fonts.
-- 
-- This function does not apply retroactively to loaded images.
-- @function[parent=#love.graphics] setDefaultFilter
-- @param love.graphics#FilterMode min Filter mode used when scaling the image down.
-- @param love.graphics#FilterMode mag Filter mode used when scaling the image up.
-- @param #number anisotropy Maximum amount of Anisotropic Filtering used.
-- 

-------------------------------------------------------------------------------
-- Set an already-loaded Font as the current font or create and load a new one from the file and size.
-- 
-- It's recommended that Font objects are created with love.graphics.newFont in the loading stage and then passed to this function in the drawing stage.
-- @function[parent=#love.graphics] setFont
-- @param love.graphics#Font font The Font object to use.
-- 

-------------------------------------------------------------------------------
-- Sets the line join style.
-- @function[parent=#love.graphics] setLineJoin
-- @param love.graphics#LineJoin join The LineJoin to use.
-- 

-------------------------------------------------------------------------------
-- Sets the line style.
-- @function[parent=#love.graphics] setLineStyle
-- @param love.graphics#LineStyle style The LineStyle to use.
-- 

-------------------------------------------------------------------------------
-- Sets the line width.
-- @function[parent=#love.graphics] setLineWidth
-- @param #number width The width of the line.
-- 

-------------------------------------------------------------------------------
-- Creates and sets a new font.
-- @function[parent=#love.graphics] setNewFont
-- @param #string filename The path and name of the file with the font.
-- @param #number size The size of the font.
-- @return love.graphics#Font font The new font.
-- 

-------------------------------------------------------------------------------
-- Creates and sets a new font.
-- @function[parent=#love.graphics] setNewFont
-- @param love.filesystem#File file A File with the font.
-- @param #number size The size of the font.
-- @return love.graphics#Font font The new font.
-- 

-------------------------------------------------------------------------------
-- Creates and sets a new font.
-- @function[parent=#love.graphics] setNewFont
-- @param love#Data data A Data with the font.
-- @param #number size The size of the font.
-- @return love.graphics#Font font The new font.
-- 

-------------------------------------------------------------------------------
-- Sets or resets a Shader as the current pixel effect or vertex shaders. All drawing operations until the next love.graphics.setShader will be drawn using the Shader object specified.
-- 
-- Disables the shaders when called without arguments.
-- @function[parent=#love.graphics] setShader
-- 

-------------------------------------------------------------------------------
-- Sets or resets a Shader as the current pixel effect or vertex shaders. All drawing operations until the next love.graphics.setShader will be drawn using the Shader object specified.
-- 
-- Disables the shaders when called without arguments.
-- @function[parent=#love.graphics] setShader
-- @param love.graphics#Shader shader The new shader.
-- 

-------------------------------------------------------------------------------
-- Sets the point size.
-- @function[parent=#love.graphics] setPointSize
-- @param #number size The new point size.
-- 

-------------------------------------------------------------------------------
-- Sets or disables scissor.
-- 
-- The scissor limits the drawing area to a specified rectangle. This affects all graphics calls, including love.graphics.clear.
-- @function[parent=#love.graphics] setScissor
-- @param #number x The X coordinate of upper left corner.
-- @param #number y The Y coordinate of upper left corner.
-- @param #number width The width of clipping rectangle.
-- @param #number height The height of clipping rectangle.
-- 

-------------------------------------------------------------------------------
-- Sets or disables scissor.
-- 
-- The scissor limits the drawing area to a specified rectangle. This affects all graphics calls, including love.graphics.clear.
-- @function[parent=#love.graphics] setScissor
-- 

-------------------------------------------------------------------------------
-- Configures or disables stencil testing.
-- 
-- When stencil testing is enabled, the geometry of everything that is drawn afterward will be clipped / stencilled out based on a comparison between the arguments of this function and the stencil value of each pixel that the geometry touches. The stencil values of pixels are affected via love.graphics.stencil.
-- 
-- Each Canvas has its own per-pixel stencil values.
-- @function[parent=#love.graphics] setStencilTest
-- @param love.graphics#CompareMode comparemode The type of comparison to make for each pixel.
-- @param #number comparevalue The value to use when comparing with the stencil value of each pixel. Must be between 0 and 255.
-- 

-------------------------------------------------------------------------------
-- Configures or disables stencil testing.
-- 
-- When stencil testing is enabled, the geometry of everything that is drawn afterward will be clipped / stencilled out based on a comparison between the arguments of this function and the stencil value of each pixel that the geometry touches. The stencil values of pixels are affected via love.graphics.stencil.
-- 
-- Each Canvas has its own per-pixel stencil values.
-- @function[parent=#love.graphics] setStencilTest
-- 

-------------------------------------------------------------------------------
-- Sets whether wireframe lines will be used when drawing.
-- 
-- Wireframe mode should only be used for debugging. The lines drawn with it enabled do not behave like regular love.graphics lines: their widths don't scale with the coordinate transformations or with love.graphics.setLineWidth, and they don't use the smooth LineStyle.
-- @function[parent=#love.graphics] setWireframe
-- @param #boolean enable True to enable wireframe mode when drawing, false to disable it.
-- 

-------------------------------------------------------------------------------
-- Shears the coordinate system.
-- @function[parent=#love.graphics] shear
-- @param #number kx The shear factor on the x-axis.
-- @param #number ky The shear factor on the y-axis.
-- 

-------------------------------------------------------------------------------
-- Draws geometry as a stencil.
-- 
-- The geometry drawn by the supplied function sets invisible stencil values of pixels, instead of setting pixel colors. The stencil values of pixels can act like a mask / stencil - love.graphics.setStencilTest can be used afterward to determine how further rendering is affected by the stencil values in each pixel.
-- 
-- Each Canvas has its own per-pixel stencil values. Stencil values are within the range of [0, 255].
-- @function[parent=#love.graphics] stencil
-- @param stencilfunction Function which draws geometry. The stencil values of pixels, rather than the color of each pixel, will be affected by the geometry.
-- @param love.graphics#StencilAction action How to modify any stencil values of pixels that are touched by what's drawn in the stencil function.
-- @param #number value The new stencil value to use for pixels if the "replace" stencil action is used. Has no effect with other stencil actions. Must be between 0 and 255.
-- @param #boolean keepvalues True to preserve old stencil values of pixels, false to re-set every pixel's stencil value to 0 before executing the stencil function. love.graphics.clear will also re-set all stencil values.
-- 

-------------------------------------------------------------------------------
-- Translates the coordinate system in two dimensions.
-- 
-- When this function is called with two numbers, dx, and dy, all the following drawing operations take effect as if their x and y coordinates were x+dx and y+dy.
-- 
-- Scale and translate are not commutative operations, therefore, calling them in different orders will change the outcome.
-- 
-- This change lasts until love.graphics.clear is called (which is called automatically before love.draw in the default love.run function), or a love.graphics.pop reverts to a previous coordinate system state.
-- 
-- Translating using whole numbers will prevent tearing/blurring of images and fonts draw after translating.
-- @function[parent=#love.graphics] translate
-- @param #number dx The translation relative to the x-axis.
-- @param #number dy The translation relative to the y-axis.
-- 


return nil
