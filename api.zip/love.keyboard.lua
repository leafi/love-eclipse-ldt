--------------------------------------------------------------------------------
-- Provides an interface to the user's keyboard.
-- 
-- @module love.keyboard
-- 

-------------------------------------------------------------------------------
-- Gets the key corresponding to the given hardware scancode.
-- 
-- Unlike key constants, Scancodes are keyboard layout-independent. For example the scancode "w" will be generated if the key in the same place as the "w" key on an American keyboard is pressed, no matter what the key is labelled or what the user's operating system settings are.
-- 
-- Scancodes are useful for creating default controls that have the same physical locations on on all systems.
-- @function[parent=#love.keyboard] getKeyFromScancode
-- @param love.keyboard#Scancode scancode The scancode to get the key from.
-- @return love.keyboard#KeyConstant key The key corresponding to the given scancode, or "unknown" if the scancode doesn't map to a KeyConstant on the current system.
-- 

-------------------------------------------------------------------------------
-- Gets the hardware scancode corresponding to the given key.
-- 
-- Unlike key constants, Scancodes are keyboard layout-independent. For example the scancode "w" will be generated if the key in the same place as the "w" key on an American keyboard is pressed, no matter what the key is labelled or what the user's operating system settings are.
-- 
-- Scancodes are useful for creating default controls that have the same physical locations on on all systems.
-- @function[parent=#love.keyboard] getScancodeFromKey
-- @param love.keyboard#KeyConstant key The key to get the scancode from.
-- @return love.keyboard#Scancode scancode The scancode corresponding to the given key, or "unknown" if the given key has no known physical representation on the current system.
-- 

-------------------------------------------------------------------------------
-- Gets whether key repeat is enabled.
-- @function[parent=#love.keyboard] hasKeyRepeat
-- @return #boolean enabled Whether key repeat is enabled.
-- 

-------------------------------------------------------------------------------
-- Gets whether text input events are enabled.
-- @function[parent=#love.keyboard] hasTextInput
-- @return #boolean enabled Whether text input events are enabled.
-- 

-------------------------------------------------------------------------------
-- Checks whether a certain key is down. Not to be confused with love.keypressed or love.keyreleased.
-- @function[parent=#love.keyboard] isDown
-- @param love.keyboard#KeyConstant key The key to check.
-- @return #boolean down True if the key is down, false if not.
-- 

-------------------------------------------------------------------------------
-- Checks whether a certain key is down. Not to be confused with love.keypressed or love.keyreleased.
-- @function[parent=#love.keyboard] isDown
-- @param love.keyboard#KeyConstant key A key to check.
-- @param love.keyboard#KeyConstant ... Additional keys to check.
-- @return #boolean anyDown True if any supplied key is down, false if not.
-- 

-------------------------------------------------------------------------------
-- Checks whether the specified Scancodes are pressed. Not to be confused with love.keypressed or love.keyreleased.
-- 
-- Unlike regular KeyConstants, Scancodes are keyboard layout-independent. The scancode "w" is used if the key in the same place as the "w" key on an American keyboard is pressed, no matter what the key is labelled or what the user's operating system settings are.
-- @function[parent=#love.keyboard] isScancodeDown
-- @param love.keyboard#Scancode scancode A Scancode to check.
-- @param love.keyboard#Scancode ... Additional Scancodes to check.
-- @return #boolean down True if any supplied Scancode is down, false if not.
-- 

-------------------------------------------------------------------------------
-- Enables or disables key repeat. It is disabled by default.
-- 
-- The interval between repeats depends on the user's system settings.
-- @function[parent=#love.keyboard] setKeyRepeat
-- @param #boolean enable Whether repeat keypress events should be enabled when a key is held down.
-- 

-------------------------------------------------------------------------------
-- Enables or disables text input events. It is enabled by default on Windows, Mac, and Linux, and disabled by default on iOS and Android.
-- @function[parent=#love.keyboard] setTextInput
-- @param #boolean enable Whether text input events should be enabled.
-- 

-------------------------------------------------------------------------------
-- Enables or disables text input events. It is enabled by default on Windows, Mac, and Linux, and disabled by default on iOS and Android.
-- @function[parent=#love.keyboard] setTextInput
-- @param #boolean enable Whether text input events should be enabled.
-- @param #number x On-screen keyboard x position.
-- @param #number y On-screen keyboard y position.
-- @param #number w On-screen keyboard width.
-- @param #number h On-screen keyboard height.
-- 


return nil
