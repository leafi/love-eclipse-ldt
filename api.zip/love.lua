---
-- The root module which contains all the other modules.
-- Clearly the loveliest module of all.
--
-- When beginning to write games using L�VE, the most important parts of the API 
-- are the callbacks: love.load to do one-time setup of your game, love.update 
-- which is used to manage your game's state frame-to-frame, and love.draw which 
-- is used to render the game state onto the screen.
--
-- More interactive games will override additional callbacks in order to handle 
-- input from the user, and other aspects of a full-featured game.
--
-- @module love
--



---
-- Provides an interface to create noise with the user's speakers.
-- @field [parent = #love] audio#audio audio
-- 

---
-- Manages events, like keypresses.
-- @field [parent = #love] event#event event
-- 

---
-- Provides an interface to the user's filesystem.
-- @field [parent = #love] filesystem#filesystem filesystem
-- 

---
-- The primary responsibility for the love.graphics module is the drawing of lines, shapes, text, Images and other Drawable objects onto the screen. Its secondary responsibilities include loading external files (including Images and Fonts) into memory, creating specialized objects (such as ParticleSystems or Framebuffers) and managing screen geometry.
-- @field [parent = #love] graphics#graphics graphics
-- 

---
-- Provides an interface to decode encoded image data.
-- @field [parent = #love] image#image image
-- 

---
-- Provides an interface to the user's joystick.
-- @field [parent = #love] joystick#joystick joystick
-- 

---
-- Provides an interface to the user's keyboard.
-- @field [parent = #love] keyboard#keyboard keyboard
-- 

---
-- Provides system-independent mathematical functions.
-- @field [parent = #love] LOVEmath#LOVEmath math
-- 

---
-- Provides an interface to the user's mouse.
-- @field [parent = #love] mouse#mouse mouse
-- 

---
-- Can simulate 2D rigid body physics in a realistic manner. This module is based on Box2D, and this API corresponds to the Box2D API as closely as possible.
-- @field [parent = #love] physics#physics physics
-- 

---
-- This module is responsible for decoding sound files. It can't play the sounds, see love.audio for that.
-- @field [parent = #love] sound#sound sound
-- 

---
-- Provides access to information about the user's system.
-- @field [parent = #love] system#system system
-- 

---
-- Allows you to work with threads.
-- @field [parent = #love] thread#thread thread
-- 

---
-- Provides an interface to the user's clock.
-- @field [parent = #love] timer#timer timer
-- 

---
-- The primary responsibility for the love.graphics module is the drawing of lines, shapes, text, Images and other Drawable objects onto the screen. Its secondary responsibilities include loading external files (including Images and Fonts) into memory, creating specialized objects (such as ParticleSystems or Framebuffers) and managing screen geometry.
-- @field [parent = #love] window#window window
-- 

---
-- Gets the current running version of LÖVE.
-- @function [parent = #love] getVersion
-- @return #number major The major version of LÖVE, e.g. 0 for version 0.9.1.
-- @return #number minor The minor version of LÖVE, e.g. 9 for version 0.9.1.
-- @return #number revision The revision version of LÖVE, e.g. 1 for version 0.9.1.
-- @return #string codename The codename of the current version.
-- 

---
-- Callback function used to draw on the screen every frame.
-- @function [parent = #love] draw
-- 

---
-- The error handler, used to display error messages.
-- @function [parent = #love] errhand
-- @param #string msg The error message.
-- 

---
-- Callback function triggered when window receives or loses focus.
-- @function [parent = #love] focus
-- @param #boolean f Window focus.
-- 

---
-- Called when a Joystick's virtual gamepad axis is moved.
-- @function [parent = #love] gamepadaxis
-- @param joystick#Joystick joystick The joystick object.
-- @param joystick#GamepadAxis axis The virtual gamepad axis.
-- 

---
-- Called when a Joystick's virtual gamepad button is pressed.
-- @function [parent = #love] gamepadpressed
-- @param joystick#Joystick joystick The joystick object.
-- @param joystick#GamepadButton button The virtual gamepad button.
-- 

---
-- Called when a Joystick's virtual gamepad button is released.
-- @function [parent = #love] gamepadreleased
-- @param joystick#Joystick joystick The joystick object.
-- @param joystick#GamepadButton button The virtual gamepad button.
-- 

---
-- Called when a Joystick is connected.
-- 
-- This callback is also triggered after love.load for every Joystick which was already connected when the game started up.
-- @function [parent = #love] joystickadded
-- @param joystick#Joystick joystick The newly connected Joystick object.
-- 

---
-- Called when a joystick axis moves.
-- @function [parent = #love] joystickaxis
-- @param joystick#Joystick joystick The joystick object.
-- @param #number axis The axis number.
-- @param #number value The new axis value.
-- 

---
-- Called when a joystick hat direction changes.
-- @function [parent = #love] joystickhat
-- @param joystick#Joystick joystick The joystick object.
-- @param #number hat The hat number.
-- @param joystick#JoystickHat direction The new hat direction.
-- 

---
-- Called when a joystick button is pressed.
-- @function [parent = #love] joystickpressed
-- @param #number joystick The joystick number.
-- @param #number button The button number.
-- 

---
-- Called when a joystick button is released.
-- @function [parent = #love] joystickreleased
-- @param #number joystick The joystick number.
-- @param #number button The button number.
-- 

---
-- Called when a Joystick is disconnected.
-- @function [parent = #love] joystickremoved
-- @param joystick#Joystick joystick The now-disconnected Joystick object.
-- 

---
-- Callback function triggered when a key is pressed.
-- 
-- Key repeat needs to be enabled with love.keyboard.setKeyRepeat for repeat keypress events to be received.
-- @function [parent = #love] keypressed
-- @param keyboard#KeyConstant key Character of the key pressed.
-- @param #boolean isrepeat Whether this keypress event is a repeat. The delay between key repeats depends on the user's system settings.
-- 

---
-- Callback function triggered when a key is released.
-- @function [parent = #love] keyreleased
-- @param keyboard#KeyConstant key Character of the key released.
-- 

---
-- This function is called exactly once at the beginning of the game.
-- @function [parent = #love] load
-- @param #table arg Command line arguments given to the game.
-- 

---
-- Callback function triggered when window receives or loses mouse focus.
-- @function [parent = #love] mousefocus
-- @param #boolean f Window mouse focus.
-- 

---
-- Callback function triggered when the mouse is moved.
-- @function [parent = #love] mousemoved
-- @param #number x The mouse position on the x-axis.
-- @param #number y The mouse position on the y-axis.
-- @param #number dx The amount moved along the x-axis since the last time love.mousemoved was called.
-- @param #number dy The amount moved along the y-axis since the last time love.mousemoved was called.
-- 

---
-- Callback function triggered when a mouse button is pressed.
-- @function [parent = #love] mousepressed
-- @param #number x Mouse x position.
-- @param #number y Mouse y position.
-- @param mouse#MouseConstant button Mouse button pressed.
-- 

---
-- Callback function triggered when a mouse button is released.
-- @function [parent = #love] mousereleased
-- @param #number x Mouse x position.
-- @param #number y Mouse y position.
-- @param mouse#MouseConstant button Mouse button released.
-- 

---
-- Callback function triggered when the game is closed.
-- @function [parent = #love] quit
-- @return #boolean r Abort quitting. If true, do not close the game.
-- 

---
-- Called when the window is resized, for example if the user resizes the window, or if love.window.setMode is called with an unsupported width or height in fullscreen and the window chooses the closest appropriate size.
-- 
-- Calls to love.window.setMode will only trigger this event if the width or height of the window after the call doesn't match the requested width and height. This can happen if a fullscreen mode is requested which doesn't match any supported mode, or if the fullscreen type is 'desktop' and the requested width or height don't match the desktop resolution.
-- @function [parent = #love] resize
-- @param #number w The new width.
-- @param #number h The new height.
-- 

---
-- The main function, containing the main loop. A sensible default is used when left out.
-- @function [parent = #love] run
-- 

---
-- Called when text has been entered by the user. For example if shift-2 is pressed on an American keyboard layout, the text "@" will be generated.
-- @function [parent = #love] textinput
-- @param #string text The UTF-8 encoded unicode text.
-- 

---
-- Callback function triggered when a Thread encounters an error.
-- @function [parent = #love] threaderror
-- @param thread#Thread thread The thread which produced the error.
-- @param #string errorstr The error message.
-- 

---
-- Callback function triggered when a key is pressed.
-- @function [parent = #love] update
-- @param #number dt Time since the last update in seconds.
-- 

---
-- Callback function triggered when window is minimized/hidden or unminimized by the user.
-- @function [parent = #love] visible
-- @param #boolean v Window visibility.
-- 


return nil
