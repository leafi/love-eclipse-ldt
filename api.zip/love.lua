---
-- The root module which contains all the other modules.
-- Clearly the loveliest module of all.
--
-- When beginning to write games using L�VE, the most important parts of the API 
-- are the callbacks: love.load to do one-time setup of your game, love.update 
-- which is used to manage your game's state frame-to-frame, and love.draw which 
-- is used to render the game state onto the screen.
--
-- More interactive games will override additional callbacks in order to handle 
-- input from the user, and other aspects of a full-featured game.
--
-- @module love



---
-- Provides an interface to create noise with the user's speakers.
-- @field [parent = #love] love.audio#love.audio audio
-- 

---
-- Manages events, like keypresses.
-- @field [parent = #love] love.event#love.event event
-- 

---
-- Provides an interface to the user's filesystem.
-- @field [parent = #love] love.filesystem#love.filesystem filesystem
-- 

---
-- The primary responsibility for the love.graphics module is the drawing of lines, shapes, text, Images and other Drawable objects onto the screen. Its secondary responsibilities include loading external files (including Images and Fonts) into memory, creating specialized objects (such as ParticleSystems or Framebuffers) and managing screen geometry.
-- @field [parent = #love] love.graphics#love.graphics graphics
-- 

---
-- Provides an interface to decode encoded image data.
-- @field [parent = #love] love.image#love.image image
-- 

---
-- Provides an interface to the user's joystick.
-- @field [parent = #love] love.joystick#love.joystick joystick
-- 

---
-- Provides an interface to the user's keyboard.
-- @field [parent = #love] love.keyboard#love.keyboard keyboard
-- 

---
-- Provides system-independent mathematical functions.
-- @field [parent = #love] love.math#love.math math
-- 

---
-- Provides an interface to the user's mouse.
-- @field [parent = #love] love.mouse#love.mouse mouse
-- 

---
-- Can simulate 2D rigid body physics in a realistic manner. This module is based on Box2D, and this API corresponds to the Box2D API as closely as possible.
-- @field [parent = #love] love.physics#love.physics physics
-- 

---
-- This module is responsible for decoding sound files. It can't play the sounds, see love.audio for that.
-- @field [parent = #love] love.sound#love.sound sound
-- 

---
-- Provides access to information about the user's system.
-- @field [parent = #love] love.system#love.system system
-- 

---
-- Allows you to work with threads.
-- @field [parent = #love] love.thread#love.thread thread
-- 

---
-- Provides an interface to the user's clock.
-- @field [parent = #love] love.timer#love.timer timer
-- 

---
-- Provides an interface to touch-screen presses.
-- @field [parent = #love] love.touch#love.touch touch
-- 

---
-- This module is responsible for decoding, controlling, and streaming video files.
-- @field [parent = #love] love.video#love.video video
-- 

---
-- Provides an interface for modifying and retrieving information about the program's window.
-- @field [parent = #love] love.window#love.window window
-- 

-------------------------------------------------------------------------------
-- The superclass of all data.
-- @type Data
-- @extends love#Object

-------------------------------------------------------------------------------
-- Gets a pointer to the Data.
-- @function[parent=#Data] getPointer
-- @param self self 
-- @return #table pointer A raw pointer to the Data.
-- 

-------------------------------------------------------------------------------
-- Gets the size of the Data.
-- @function[parent=#Data] getSize
-- @param self self 
-- @return #number size The size of the Data in bytes.
-- 

-------------------------------------------------------------------------------
-- Gets the full Data as a string.
-- @function[parent=#Data] getString
-- @param self self 
-- @return #string data The raw data.
-- 


-------------------------------------------------------------------------------
-- Superclass for all things that can be drawn on screen. This is an abstract type that can't be created directly.
-- @type Drawable
-- @extends love#Object


-------------------------------------------------------------------------------
-- The superclass of all LÖVE types.
-- @type Object

-------------------------------------------------------------------------------
-- Gets the type of the object as a string.
-- @function[parent=#Object] type
-- @param self self 
-- @return #string type The type as a string.
-- 

-------------------------------------------------------------------------------
-- Checks whether an object is of a certain type. If the object has the type with the specified name in its hierarchy, this function will return true.
-- @function[parent=#Object] typeOf
-- @param self self 
-- @param #string name The name of the type to check for.
-- @return #boolean b True if the object is of the specified type, false otherwise.
-- 


-------------------------------------------------------------------------------
-- Gets the current running version of LÖVE.
-- @function[parent=#love] getVersion
-- @return #number major The major version of LÖVE, i.e. 0 for version 0.9.1.
-- @return #number minor The minor version of LÖVE, i.e. 9 for version 0.9.1.
-- @return #number revision The revision version of LÖVE, i.e. 1 for version 0.9.1.
-- @return #string codename The codename of the current version, i.e. "Baby Inspector" for version 0.9.1.
-- 

-------------------------------------------------------------------------------
-- If a file called conf.lua is present in your game folder (or .love file), it is run before the LÖVE modules are loaded. You can use this file to overwrite the love.conf function, which is later called by the LÖVE 'boot' script. Using the love.conf function, you can set some configuration options, and change things like the default size of the window, which modules are loaded, and other stuff.
-- @function[parent=#love] conf
-- @param #table t The love.conf function takes one argument: a table filled with all the default values which you can overwrite to your liking. If you want to change the default window size, for instance, do:
-- 

-------------------------------------------------------------------------------
-- Callback function triggered when a directory is dragged and dropped onto the window.
-- @function[parent=#love] directorydropped
-- @param #string path The full platform-dependent path to the directory. It can be used as an argument to love.filesystem.mount, in order to gain read access to the directory with love.filesystem.
-- 

-------------------------------------------------------------------------------
-- Callback function used to draw on the screen every frame.
-- @function[parent=#love] draw
-- 

-------------------------------------------------------------------------------
-- The error handler, used to display error messages.
-- @function[parent=#love] errhand
-- @param #string msg The error message.
-- 

-------------------------------------------------------------------------------
-- Callback function triggered when a file is dragged and dropped onto the window.
-- @function[parent=#love] filedropped
-- @param love.filesystem#File file The unopened File object representing the file that was dropped.
-- 

-------------------------------------------------------------------------------
-- Callback function triggered when window receives or loses focus.
-- @function[parent=#love] focus
-- @param #boolean focus True if the window gains focus, false if it loses focus.
-- 

-------------------------------------------------------------------------------
-- Called when a Joystick's virtual gamepad axis is moved.
-- @function[parent=#love] gamepadaxis
-- @param love.joystick#Joystick joystick The joystick object.
-- @param love.joystick#GamepadAxis axis The virtual gamepad axis.
-- 

-------------------------------------------------------------------------------
-- Called when a Joystick's virtual gamepad button is pressed.
-- @function[parent=#love] gamepadpressed
-- @param love.joystick#Joystick joystick The joystick object.
-- @param love.joystick#GamepadButton button The virtual gamepad button.
-- 

-------------------------------------------------------------------------------
-- Called when a Joystick's virtual gamepad button is released.
-- @function[parent=#love] gamepadreleased
-- @param love.joystick#Joystick joystick The joystick object.
-- @param love.joystick#GamepadButton button The virtual gamepad button.
-- 

-------------------------------------------------------------------------------
-- Called when a Joystick is connected.
-- 
-- This callback is also triggered after love.load for every Joystick which was already connected when the game started up.
-- @function[parent=#love] joystickadded
-- @param love.joystick#Joystick joystick The newly connected Joystick object.
-- 

-------------------------------------------------------------------------------
-- Called when a joystick axis moves.
-- @function[parent=#love] joystickaxis
-- @param love.joystick#Joystick joystick The joystick object.
-- @param #number axis The axis number.
-- @param #number value The new axis value.
-- 

-------------------------------------------------------------------------------
-- Called when a joystick hat direction changes.
-- @function[parent=#love] joystickhat
-- @param love.joystick#Joystick joystick The joystick object.
-- @param #number hat The hat number.
-- @param love.joystick#JoystickHat direction The new hat direction.
-- 

-------------------------------------------------------------------------------
-- Called when a joystick button is pressed.
-- @function[parent=#love] joystickpressed
-- @param #number joystick The joystick number.
-- @param #number button The button number.
-- 

-------------------------------------------------------------------------------
-- Called when a joystick button is released.
-- @function[parent=#love] joystickreleased
-- @param #number joystick The joystick number.
-- @param #number button The button number.
-- 

-------------------------------------------------------------------------------
-- Called when a Joystick is disconnected.
-- @function[parent=#love] joystickremoved
-- @param love.joystick#Joystick joystick The now-disconnected Joystick object.
-- 

-------------------------------------------------------------------------------
-- Callback function triggered when a key is pressed.
-- @function[parent=#love] keypressed
-- @param love.keyboard#KeyConstant key Character of the pressed key.
-- @param love.keyboard#Scancode scancode The scancode representing the pressed key.
-- @param #boolean isrepeat Whether this keypress event is a repeat. The delay between key repeats depends on the user's system settings.
-- 

-------------------------------------------------------------------------------
-- Callback function triggered when a keyboard key is released.
-- @function[parent=#love] keyreleased
-- @param love.keyboard#KeyConstant key Character of the released key.
-- 

-------------------------------------------------------------------------------
-- Callback function triggered when a keyboard key is released.
-- @function[parent=#love] keyreleased
-- @param love.keyboard#KeyConstant key Character of the released key.
-- @param love.keyboard#Scancode scancode The scancode representing the released key.
-- 

-------------------------------------------------------------------------------
-- This function is called exactly once at the beginning of the game.
-- @function[parent=#love] load
-- @param #table arg Command line arguments given to the game.
-- 

-------------------------------------------------------------------------------
-- Callback function triggered when the system is running out of memory on mobile devices.
-- 
--  Mobile operating systems may forcefully kill the game if it uses too much memory, so any non-critical resource should be removed if possible (by setting all variables referencing the resources to nil, and calling collectgarbage()), when this event is triggered. Sounds and images in particular tend to use the most memory.
-- @function[parent=#love] lowmemory
-- 

-------------------------------------------------------------------------------
-- Callback function triggered when window receives or loses mouse focus.
-- @function[parent=#love] mousefocus
-- @param #boolean focus Wether the window has mouse focus or not.
-- 

-------------------------------------------------------------------------------
-- Callback function triggered when the mouse is moved.
-- @function[parent=#love] mousemoved
-- @param #number x The mouse position on the x-axis.
-- @param #number y The mouse position on the y-axis.
-- @param #number dx The amount moved along the x-axis since the last time love.mousemoved was called.
-- @param #number dy The amount moved along the y-axis since the last time love.mousemoved was called.
-- @param #boolean istouch True if the mouse button press originated from a touchscreen touch-press.
-- 

-------------------------------------------------------------------------------
-- Callback function triggered when a mouse button is pressed.
-- @function[parent=#love] mousepressed
-- @param #number x Mouse x position, in pixels.
-- @param #number y Mouse y position, in pixels.
-- @param #number button The button index that was pressed. 1 is the primary mouse button, 2 is the secondary mouse button and 3 is the middle button. Further buttons are mouse dependent
-- @param #boolean isTouch True if the mouse button press originated from a touchscreen touch-press.
-- 

-------------------------------------------------------------------------------
-- Callback function triggered when a mouse button is released.
-- @function[parent=#love] mousereleased
-- @param #number x Mouse x position, in pixels.
-- @param #number y Mouse y position, in pixels.
-- @param #number button The button index that was released. 1 is the primary mouse button, 2 is the secondary mouse button and 3 is the middle button. Further buttons are mouse dependent.
-- @param #boolean isTouch True if the mouse button press originated from a touchscreen touch-release.
-- 

-------------------------------------------------------------------------------
-- Callback function triggered when the game is closed.
-- @function[parent=#love] quit
-- @return #boolean r Abort quitting. If true, do not close the game.
-- 

-------------------------------------------------------------------------------
-- Called when the window is resized, for example if the user resizes the window, or if love.window.setMode is called with an unsupported width or height in fullscreen and the window chooses the closest appropriate size.
-- 
-- Calls to love.window.setMode will only trigger this event if the width or height of the window after the call doesn't match the requested width and height. This can happen if a fullscreen mode is requested which doesn't match any supported mode, or if the fullscreen type is 'desktop' and the requested width or height don't match the desktop resolution.
-- @function[parent=#love] resize
-- @param #number w The new width.
-- @param #number h The new height.
-- 

-------------------------------------------------------------------------------
-- The main function, containing the main loop. A sensible default is used when left out.
-- @function[parent=#love] run
-- 

-------------------------------------------------------------------------------
-- Called when the candidate text for an IME (Input Method Editor) has changed.
-- 
-- The candidate text is not the final text that the user will eventually choose. Use love.textinput for that.
-- @function[parent=#love] textedited
-- @param #string text The UTF-8 encoded unicode candidate text.
-- @param #number start The start cursor of the selected candidate text.
-- @param #number length The length of the selected candidate text. May be 0.
-- 

-------------------------------------------------------------------------------
-- Called when text has been entered by the user. For example if shift-2 is pressed on an American keyboard layout, the text "@" will be generated.
-- @function[parent=#love] textinput
-- @param #string text The UTF-8 encoded unicode text.
-- 

-------------------------------------------------------------------------------
-- Callback function triggered when a Thread encounters an error.
-- @function[parent=#love] threaderror
-- @param love.thread#Thread thread The thread which produced the error.
-- @param #string errorstr The error message.
-- 

-------------------------------------------------------------------------------
-- Callback function triggered when a touch press moves inside the touch screen.
-- @function[parent=#love] touchmoved
-- @param #table id The identifier for the touch press.
-- @param #number x The x-axis position of the touch inside the window, in pixels.
-- @param #number y The y-axis position of the touch inside the window, in pixels.
-- @param #number dx The x-axis movement of the touch inside the window, in pixels.
-- @param #number dy The y-axis movement of the touch inside the window, in pixels.
-- @param #number pressure The amount of pressure being applied. Most touch screens aren't pressure sensitive, in which case the pressure will be 1.
-- 

-------------------------------------------------------------------------------
-- Callback function triggered when the touch screen is touched.
-- @function[parent=#love] touchpressed
-- @param #table id The identifier for the touch press.
-- @param #number x The x-axis position of the touch press inside the window, in pixels.
-- @param #number y The y-axis position of the touch press inside the window, in pixels.
-- @param #number dx The x-axis movement of the touch press inside the window, in pixels. This should always be zero.
-- @param #number dy The y-axis movement of the touch press inside the window, in pixels. This should always be zero.
-- @param #number pressure The amount of pressure being applied. Most touch screens aren't pressure sensitive, in which case the pressure will be 1.
-- 

-------------------------------------------------------------------------------
-- Callback function triggered when the touch screen stops being touched.
-- @function[parent=#love] touchreleased
-- @param #table id The identifier for the touch press.
-- @param #number x The x-axis position of the touch inside the window, in pixels.
-- @param #number y The y-axis position of the touch inside the window, in pixels.
-- @param #number dx The x-axis movement of the touch inside the window, in pixels.
-- @param #number dy The y-axis movement of the touch inside the window, in pixels.
-- @param #number pressure The amount of pressure being applied. Most touch screens aren't pressure sensitive, in which case the pressure will be 1.
-- 

-------------------------------------------------------------------------------
-- Callback function used to update the state of the game every frame.
-- @function[parent=#love] update
-- @param #number dt Time since the last update in seconds.
-- 

-------------------------------------------------------------------------------
-- Callback function triggered when window is minimized/hidden or unminimized by the user.
-- @function[parent=#love] visible
-- @param #boolean visible True if the window is visible, false if it isn't.
-- 

-------------------------------------------------------------------------------
-- Callback function triggered when the mouse wheel is moved.
-- @function[parent=#love] wheelmoved
-- @param #number x Amount of horizontal mouse wheel movement. Positive values indicate movement to the right.
-- @param #number y Amount of vertical mouse wheel movement. Positive values indicate upward movement.
-- 


return nil
