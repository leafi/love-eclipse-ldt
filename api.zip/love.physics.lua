--------------------------------------------------------------------------------
-- Can simulate 2D rigid body physics in a realistic manner. This module is based on Box2D, and this API corresponds to the Box2D API as closely as possible.
-- 
-- @module love.physics
-- 

-------------------------------------------------------------------------------
-- Bodies are objects with velocity and position.
-- @type Body
-- @extends love#Object

-------------------------------------------------------------------------------
-- Applies an angular impulse to a body. This makes a single, instantaneous addition to the body momentum.
-- 
-- A body with with a larger mass will react less. The reaction does not depend on the timestep, and is equivalent to applying a force continuously for 1 second. Impulses are best used to give a single push to a body. For a continuous push to a body it is better to use Body:applyForce.
-- @function[parent=#Body] applyAngularImpulse
-- @param self self 
-- @param #number impulse The impulse in kilogram-square meter per second.
-- 

-------------------------------------------------------------------------------
-- Apply force to a Body.
-- 
-- A force pushes a body in a direction. A body with with a larger mass will react less. The reaction also depends on how long a force is applied: since the force acts continuously over the entire timestep, a short timestep will only push the body for a short time. Thus forces are best used for many timesteps to give a continuous push to a body (like gravity). For a single push that is independent of timestep, it is better to use Body:applyLinearImpulse.
-- 
-- If the position to apply the force is not given, it will act on the center of mass of the body. The part of the force not directed towards the center of mass will cause the body to spin (and depends on the rotational inertia).
-- 
-- Note that the force components and position must be given in world coordinates.
-- @function[parent=#Body] applyForce
-- @param self self 
-- @param #number fx The x component of force to apply to the center of mass.
-- @param #number fy The y component of force to apply to the center of mass.
-- 

-------------------------------------------------------------------------------
-- Apply force to a Body.
-- 
-- A force pushes a body in a direction. A body with with a larger mass will react less. The reaction also depends on how long a force is applied: since the force acts continuously over the entire timestep, a short timestep will only push the body for a short time. Thus forces are best used for many timesteps to give a continuous push to a body (like gravity). For a single push that is independent of timestep, it is better to use Body:applyLinearImpulse.
-- 
-- If the position to apply the force is not given, it will act on the center of mass of the body. The part of the force not directed towards the center of mass will cause the body to spin (and depends on the rotational inertia).
-- 
-- Note that the force components and position must be given in world coordinates.
-- @function[parent=#Body] applyForce
-- @param self self 
-- @param #number fx The x component of force to apply.
-- @param #number fy The y component of force to apply.
-- @param #number x The x position to apply the force.
-- @param #number y The y position to apply the force.
-- 

-------------------------------------------------------------------------------
-- Applies an impulse to a body. This makes a single, instantaneous addition to the body momentum.
-- 
-- An impulse pushes a body in a direction. A body with with a larger mass will react less. The reaction does not depend on the timestep, and is equivalent to applying a force continuously for 1 second. Impulses are best used to give a single push to a body. For a continuous push to a body it is better to use Body:applyForce.
-- 
-- If the position to apply the impulse is not given, it will act on the center of mass of the body. The part of the impulse not directed towards the center of mass will cause the body to spin (and depends on the rotational inertia).
-- 
-- Note that the impulse components and position must be given in world coordinates.
-- @function[parent=#Body] applyLinearImpulse
-- @param self self 
-- @param #number ix The x component of the impulse applied to the center of mass.
-- @param #number iy The y component of the impulse applied to the center of mass.
-- 

-------------------------------------------------------------------------------
-- Applies an impulse to a body. This makes a single, instantaneous addition to the body momentum.
-- 
-- An impulse pushes a body in a direction. A body with with a larger mass will react less. The reaction does not depend on the timestep, and is equivalent to applying a force continuously for 1 second. Impulses are best used to give a single push to a body. For a continuous push to a body it is better to use Body:applyForce.
-- 
-- If the position to apply the impulse is not given, it will act on the center of mass of the body. The part of the impulse not directed towards the center of mass will cause the body to spin (and depends on the rotational inertia).
-- 
-- Note that the impulse components and position must be given in world coordinates.
-- @function[parent=#Body] applyLinearImpulse
-- @param self self 
-- @param #number ix The x component of the impulse.
-- @param #number iy The y component of the impulse.
-- @param #number x The x position to apply the impulse.
-- @param #number y The y position to apply the impulse.
-- 

-------------------------------------------------------------------------------
-- Apply torque to a body.
-- 
-- Torque is like a force that will change the angular velocity (spin) of a body. The effect will depend on the rotational inertia a body has.
-- @function[parent=#Body] applyTorque
-- @param self self 
-- @param #number torque The torque to apply.
-- 

-------------------------------------------------------------------------------
-- Explicitly destroys the Body. When you don't have time to wait for garbage collection, this function may be used to free the object immediately, but note that an error will occur if you attempt to use the object after calling this function.
-- @function[parent=#Body] destroy
-- @param self self 
-- 

-------------------------------------------------------------------------------
-- Get the angle of the body.
-- 
-- The angle is measured in radians. If you need to transform it to degrees, use math.deg.
-- 
-- A value of 0 radians will mean "looking to the right". Although radians increase counter-clockwise, the y-axis points down so it becomes clockwise from our point of view.
-- @function[parent=#Body] getAngle
-- @param self self 
-- @return #number angle The angle in radians.
-- 

-------------------------------------------------------------------------------
-- Gets the Angular damping of the Body
-- 
-- The angular damping is the rate of decrease of the angular velocity over time: A spinning body with no damping and no external forces will continue spinning indefinitely. A spinning body with damping will gradually stop spinning.
-- 
-- Damping is not the same as friction - they can be modelled together. However, only damping is provided by Box2D (and LÖVE).
-- 
-- Damping parameters should be between 0 and infinity, with 0 meaning no damping, and infinity meaning full damping. Normally you will use a damping value between 0 and 0.1.
-- @function[parent=#Body] getAngularDamping
-- @param self self 
-- @return #number damping The value of the angular damping.
-- 

-------------------------------------------------------------------------------
-- Get the angular velocity of the Body.
-- 
-- The angular velocity is the rate of change of angle over time.
-- 
-- It is changed in World:update by applying torques, off centre forces/impulses, and angular damping. It can be set directly with Body:setAngularVelocity.
-- 
-- If you need the rate of change of position over time, use Body:getLinearVelocity.
-- @function[parent=#Body] getAngularVelocity
-- @param self self 
-- @return #number w The angular velocity in radians/second.
-- 

-------------------------------------------------------------------------------
-- Gets a list of all Contacts attached to the Body.
-- @function[parent=#Body] getContactList
-- @param self self 
-- @return #table contacts A list with all contacts associated with the Body.
-- 

-------------------------------------------------------------------------------
-- Returns a table with all fixtures.
-- @function[parent=#Body] getFixtureList
-- @param self self 
-- @return #table fixtures A sequence with all fixtures.
-- 

-------------------------------------------------------------------------------
-- Returns the gravity scale factor.
-- @function[parent=#Body] getGravityScale
-- @param self self 
-- @return #number scale The gravity scale factor.
-- 

-------------------------------------------------------------------------------
-- Gets the rotational inertia of the body.
-- 
-- The rotational inertia is how hard is it to make the body spin. It is set with the 4th argument to Body:setMass, or automatically with Body:setMassFromShapes.
-- @function[parent=#Body] getInertia
-- @param self self 
-- @return #number inertia The rotational inertial of the body.
-- 

-------------------------------------------------------------------------------
-- Returns a table containing the Joints attached to this Body.
-- @function[parent=#Body] getJointList
-- @param self self 
-- @return #table joints A sequence with the Joints attached to the Body.
-- 

-------------------------------------------------------------------------------
-- Gets the linear damping of the Body.
-- 
-- The linear damping is the rate of decrease of the linear velocity over time. A moving body with no damping and no external forces will continue moving indefinitely, as is the case in space. A moving body with damping will gradually stop moving.
-- 
-- Damping is not the same as friction - they can be modelled together. However, only damping is provided by Box2D (and LÖVE).
-- @function[parent=#Body] getLinearDamping
-- @param self self 
-- @return #number damping The value of the linear damping.
-- 

-------------------------------------------------------------------------------
-- Gets the linear velocity of the Body from its center of mass.
-- 
-- The linear velocity is the rate of change of position over time.
-- 
-- If you need the rate of change of angle over time, use Body:getAngularVelocity. If you need to get the linear velocity of a point different from the center of mass:
-- 
-- Body:getLinearVelocityFromLocalPoint allows you to specify the point in local coordinates.
-- 
-- Body:getLinearVelocityFromWorldPoint allows you to specify the point in world coordinates.
-- @function[parent=#Body] getLinearVelocity
-- @param self self 
-- @return #number x The x component of the velocity vector.
-- @return #number y The y component of the velocity vector.
-- 

-------------------------------------------------------------------------------
-- Get the linear velocity of a point on the body.
-- 
-- The linear velocity for a point on the body is the velocity of the body center of mass plus the velocity at that point from the body spinning.
-- 
-- The point on the body must given in local coordinates. Use Body:getLinearVelocityFromWorldPoint to specify this with world coordinates.
-- @function[parent=#Body] getLinearVelocityFromLocalPoint
-- @param self self 
-- @param #number x The x position to measure velocity.
-- @param #number y The y position to measure velocity.
-- @return #number vx The x component of velocity at point (x,y).
-- @return #number vy The y component of velocity at point (x,y).
-- 

-------------------------------------------------------------------------------
-- Get the linear velocity of a point on the body.
-- 
-- The linear velocity for a point on the body is the velocity of the body center of mass plus the velocity at that point from the body spinning.
-- 
-- The point on the body must given in world coordinates. Use Body:getLinearVelocityFromLocalPoint to specify this with local coordinates.
-- @function[parent=#Body] getLinearVelocityFromWorldPoint
-- @param self self 
-- @param #number x The x position to measure velocity.
-- @param #number y The y position to measure velocity.
-- @return #number vx The x component of velocity at point (x,y).
-- @return #number vy The y component of velocity at point (x,y).
-- 

-------------------------------------------------------------------------------
-- Get the center of mass position in local coordinates.
-- 
-- Use Body:getWorldCenter to get the center of mass in world coordinates.
-- @function[parent=#Body] getLocalCenter
-- @param self self 
-- @return #number x The x coordinate of the center of mass.
-- @return #number y The y coordinate of the center of mass.
-- 

-------------------------------------------------------------------------------
-- Transform a point from world coordinates to local coordinates.
-- @function[parent=#Body] getLocalPoint
-- @param self self 
-- @param #number worldX The x position in world coordinates.
-- @param #number worldY The y position in world coordinates.
-- @return #number localX The x position in local coordinates.
-- @return #number localY The y position in local coordinates.
-- 

-------------------------------------------------------------------------------
-- Transform a vector from world coordinates to local coordinates.
-- @function[parent=#Body] getLocalVector
-- @param self self 
-- @param #number worldX The vector x component in world coordinates.
-- @param #number worldY The vector y component in world coordinates.
-- @return #number localX The vector x component in local coordinates.
-- @return #number localY The vector y component in local coordinates.
-- 

-------------------------------------------------------------------------------
-- Get the mass of the body.
-- @function[parent=#Body] getMass
-- @param self self 
-- @return #number mass The mass of the body (in kilograms).
-- 

-------------------------------------------------------------------------------
-- Returns the mass, its center, and the rotational inertia.
-- @function[parent=#Body] getMassData
-- @param self self 
-- @return #number x The x position of the center of mass.
-- @return #number y The y position of the center of mass.
-- @return #number mass The mass of the body.
-- @return #number inertia The rotational inertia.
-- 

-------------------------------------------------------------------------------
-- Get the position of the body.
-- 
-- Note that this may not be the center of mass of the body.
-- @function[parent=#Body] getPosition
-- @param self self 
-- @return #number x The x position.
-- @return #number y The y position.
-- 

-------------------------------------------------------------------------------
-- Returns the type of the body.
-- @function[parent=#Body] getType
-- @param self self 
-- @return love.physics#BodyType type The body type.
-- 

-------------------------------------------------------------------------------
-- Returns the Lua value associated with this Body.
-- 
-- Use this function in one thread only.
-- @function[parent=#Body] getUserData
-- @param self self 
-- @return value The Lua value associated with the Body.
-- 

-------------------------------------------------------------------------------
-- Gets the World the body lives in.
-- @function[parent=#Body] getWorld
-- @param self self 
-- @return love.physics#World world The world the body lives in.
-- 

-------------------------------------------------------------------------------
-- Get the center of mass position in world coordinates.
-- 
-- Use Body:getLocalCenter to get the center of mass in local coordinates.
-- @function[parent=#Body] getWorldCenter
-- @param self self 
-- @return #number x The x coordinate of the center of mass.
-- @return #number y The y coordinate of the center of mass.
-- 

-------------------------------------------------------------------------------
-- Transform a point from local coordinates to world coordinates.
-- @function[parent=#Body] getWorldPoint
-- @param self self 
-- @param #number localX The x position in local coordinates.
-- @param #number localY The y position in local coordinates.
-- @return #number worldX The x position in world coordinates.
-- @return #number worldY The y position in world coordinates.
-- 

-------------------------------------------------------------------------------
-- Transforms multiple points from local coordinates to world coordinates.
-- @function[parent=#Body] getWorldPoints
-- @param self self 
-- @param #number x1 The x position of the first point.
-- @param #number y1 The y position of the first point.
-- @param #number x2 The x position of the second point.
-- @param #number y2 The y position of the second point.
-- @param #number ... More x and y points.
-- @return #number x1 The transformed x position of the first point.
-- @return #number y1 The transformed y position of the first point.
-- @return #number x2 The transformed x position of the second point.
-- @return #number y2 The transformed y position of the second point.
-- @return #number ... The transformed x and y positions of additional points.
-- 

-------------------------------------------------------------------------------
-- Transform a vector from local coordinates to world coordinates.
-- @function[parent=#Body] getWorldVector
-- @param self self 
-- @param #number localX The vector x component in local coordinates.
-- @param #number localY The vector y component in local coordinates.
-- @return #number worldX The vector x component in world coordinates.
-- @return #number worldY The vector y component in world coordinates.
-- 

-------------------------------------------------------------------------------
-- Get the x position of the body in world coordinates.
-- @function[parent=#Body] getX
-- @param self self 
-- @return #number x The x position in world coordinates.
-- 

-------------------------------------------------------------------------------
-- Get the y position of the body in world coordinates.
-- @function[parent=#Body] getY
-- @param self self 
-- @return #number y The y position in world coordinates.
-- 

-------------------------------------------------------------------------------
-- Returns whether the body is actively used in the simulation.
-- @function[parent=#Body] isActive
-- @param self self 
-- @return #boolean status True if the body is active or false if not.
-- 

-------------------------------------------------------------------------------
-- Returns the sleep status of the body.
-- @function[parent=#Body] isAwake
-- @param self self 
-- @return #boolean status True if the body is awake or false if not.
-- 

-------------------------------------------------------------------------------
-- Get the bullet status of a body.
-- 
-- There are two methods to check for body collisions:
-- 
-- at their location when the world is updated (default)
-- 
-- using continuous collision detection (CCD)
-- 
-- The default method is efficient, but a body moving very quickly may sometimes jump over another body without producing a collision. A body that is set as a bullet will use CCD. This is less efficient, but is guaranteed not to jump when moving quickly.
-- 
-- Note that static bodies (with zero mass) always use CCD, so your walls will not let a fast moving body pass through even if it is not a bullet.
-- @function[parent=#Body] isBullet
-- @param self self 
-- @return #boolean status The bullet status of the body.
-- 

-------------------------------------------------------------------------------
-- Gets whether the Body is destroyed. Destroyed bodies cannot be used.
-- @function[parent=#Body] isDestroyed
-- @param self self 
-- @return #boolean destroyed Whether the Body is destroyed.
-- 

-------------------------------------------------------------------------------
-- Returns whether the body rotation is locked.
-- @function[parent=#Body] isFixedRotation
-- @param self self 
-- @return #boolean fixed True if the body's rotation is locked or false if not.
-- 

-------------------------------------------------------------------------------
-- Returns the sleeping behaviour of the body.
-- @function[parent=#Body] isSleepingAllowed
-- @param self self 
-- @return #boolean status True if the body is allowed to sleep or false if not.
-- 

-------------------------------------------------------------------------------
-- Resets the mass of the body by recalculating it from the mass properties of the fixtures.
-- @function[parent=#Body] resetMassData
-- @param self self 
-- 

-------------------------------------------------------------------------------
-- Sets whether the body is active in the world.
-- 
-- An inactive body does not take part in the simulation. It will not move or cause any collisions.
-- @function[parent=#Body] setActive
-- @param self self 
-- @param #boolean active If the body is active or not.
-- 

-------------------------------------------------------------------------------
-- Set the angle of the body.
-- 
-- The angle is measured in radians. If you need to transform it from degrees, use math.rad.
-- 
-- A value of 0 radians will mean "looking to the right". .Although radians increase counter-clockwise, the y-axis points down so it becomes clockwise from our point of view.
-- 
-- It is possible to cause a collision with another body by changing its angle.
-- @function[parent=#Body] setAngle
-- @param self self 
-- @param #number angle The angle in radians.
-- 

-------------------------------------------------------------------------------
-- Sets the angular damping of a Body.
-- 
-- See Body:getAngularDamping for a definition of angular damping.
-- 
-- Angular damping can take any value from 0 to infinity. It is recommended to stay between 0 and 0.1, though. Other values will look unrealistic.
-- @function[parent=#Body] setAngularDamping
-- @param self self 
-- @param #number damping The new angular damping.
-- 

-------------------------------------------------------------------------------
-- Sets the angular velocity of a Body.
-- 
-- The angular velocity is the rate of change of angle over time.
-- 
-- This function will not accumulate anything; any impulses previously applied since the last call to World:update will be lost.
-- @function[parent=#Body] setAngularVelocity
-- @param self self 
-- @param #number w The new angular velocity, in radians per second
-- 

-------------------------------------------------------------------------------
-- Wakes the body up or puts it to sleep.
-- @function[parent=#Body] setAwake
-- @param self self 
-- @param #boolean awake The body sleep status.
-- 

-------------------------------------------------------------------------------
-- Set the bullet status of a body.
-- 
-- There are two methods to check for body collisions:
-- 
-- at their location when the world is updated (default)
-- 
-- using continuous collision detection (CCD)
-- 
-- The default method is efficient, but a body moving very quickly may sometimes jump over another body without producing a collision. A body that is set as a bullet will use CCD. This is less efficient, but is guaranteed not to jump when moving quickly.
-- 
-- Note that static bodies (with zero mass) always use CCD, so your walls will not let a fast moving body pass through even if it is not a bullet.
-- @function[parent=#Body] setBullet
-- @param self self 
-- @param #boolean status The bullet status of the body.
-- 

-------------------------------------------------------------------------------
-- Set whether a body has fixed rotation.
-- 
-- Bodies with fixed rotation don't vary the speed at which they rotate.
-- @function[parent=#Body] setFixedRotation
-- @param self self 
-- @param #boolean fixed Whether the body should have fixed rotation.
-- 

-------------------------------------------------------------------------------
-- Sets a new gravity scale factor for the body.
-- @function[parent=#Body] setGravityScale
-- @param self self 
-- @param #number scale The new gravity scale factor.
-- 

-------------------------------------------------------------------------------
-- Set the inertia of a body.
-- 
-- This value can also be set by the fourth argument of Body:setMass.
-- @function[parent=#Body] setInertia
-- @param self self 
-- @param #number inertia The new moment of inertia, in kilograms per meter squared.
-- 

-------------------------------------------------------------------------------
-- Sets the linear damping of a Body
-- 
-- See Body:getLinearDamping for a definition of linear damping.
-- 
-- Linear damping can take any value from 0 to infinity. It is recommended to stay between 0 and 0.1, though. Other values will make the objects look "floaty".
-- @function[parent=#Body] setLinearDamping
-- @param self self 
-- @param #number ld The new linear damping.
-- 

-------------------------------------------------------------------------------
-- Sets a new linear velocity for the Body.
-- 
-- This function will not accumulate anything; any impulses previously applied since the last call to World:update will be lost.
-- @function[parent=#Body] setLinearVelocity
-- @param self self 
-- @param #number x The x component of the velocity vector.
-- @param #number y The y component of the velocity vector.
-- 

-------------------------------------------------------------------------------
-- Sets the mass in kilograms.
-- @function[parent=#Body] setMass
-- @param self self 
-- @param #number mass The mass, in kilograms.
-- 

-------------------------------------------------------------------------------
-- Overrides the calculated mass data.
-- @function[parent=#Body] setMassData
-- @param self self 
-- @param #number x The x component of the center of mass in local coordinates.
-- @param #number y The y component of the center of mass in local coordinates.
-- @param #number mass The mass, in kilograms.
-- @param #number inertia The rotational inertia, in kilograms per squared meter.
-- 

-------------------------------------------------------------------------------
-- Set the position of the body.
-- 
-- Note that this may not be the center of mass of the body.
-- @function[parent=#Body] setPosition
-- @param self self 
-- @param #number x The x position.
-- @param #number y The y position.
-- 

-------------------------------------------------------------------------------
-- Sets the sleeping behaviour of the body.
-- @function[parent=#Body] setSleepingAllowed
-- @param self self 
-- @param #boolean allowed True if the body is allowed to sleep or false if not.
-- 

-------------------------------------------------------------------------------
-- Sets a new body type.
-- @function[parent=#Body] setType
-- @param self self 
-- @param love.physics#BodyType type The new type.
-- 

-------------------------------------------------------------------------------
-- Associates a Lua value with the Body.
-- 
-- To delete the reference, explicitly pass nil.
-- 
-- Use this function in one thread only.
-- @function[parent=#Body] setUserData
-- @param self self 
-- @param value The Lua value to associate with the Body.
-- 

-------------------------------------------------------------------------------
-- Set the x position of the body.
-- @function[parent=#Body] setX
-- @param self self 
-- @param #number x The x position.
-- 

-------------------------------------------------------------------------------
-- Set the y position of the body.
-- @function[parent=#Body] setY
-- @param self self 
-- @param #number y The y position.
-- 


-------------------------------------------------------------------------------
-- A ChainShape consists of multiple line segments. It can be used to create the boundaries of your terrain. The shape does not have volume and can only collide with PolygonShape and CircleShape.
-- 
-- Unlike the PolygonShape, the ChainShape does not have a vertices limit or has to form a convex shape, but self intersections are not supported.
-- @type ChainShape
-- @extends love.physics#Shape
-- @extends love#Object

-------------------------------------------------------------------------------
-- Returns a child of the shape as an EdgeShape.
-- @function[parent=#ChainShape] getChildEdge
-- @param self self 
-- @param #number index The index of the child.
-- @return #number EdgeShape The child as an EdgeShape.
-- 

-------------------------------------------------------------------------------
-- Returns a point of the shape.
-- @function[parent=#ChainShape] getPoint
-- @param self self 
-- @param #number index The index of the point to return.
-- @return #number x The x-coordinate of the point.
-- @return #number y The y-coordinate of the point.
-- 

-------------------------------------------------------------------------------
-- Returns all points of the shape.
-- @function[parent=#ChainShape] getPoints
-- @param self self 
-- @return #number x1 The x-coordinate of the first point.
-- @return #number y1 The y-coordinate of the first point.
-- @return #number x2 The x-coordinate of the second point.
-- @return #number y2 The y-coordinate of the second point.
-- @return #number ... Additional x and y values.
-- 

-------------------------------------------------------------------------------
-- Returns the number of vertices the shape has.
-- @function[parent=#ChainShape] getVertexCount
-- @param self self 
-- @return #number count The number of vertices.
-- 

-------------------------------------------------------------------------------
-- Sets a vertex that establishes a connection to the next shape.
-- 
-- This can help prevent unwanted collisions when a flat shape slides along the edge and moves over to the new shape.
-- @function[parent=#ChainShape] setNextVertex
-- @param self self 
-- @param #number x The x component of the vertex.
-- @param #number y The y component of the vertex.
-- 

-------------------------------------------------------------------------------
-- Sets a vertex that establishes a connection to the previous shape.
-- 
-- This can help prevent unwanted collisions when a flat shape slides along the edge and moves over to the new shape.
-- @function[parent=#ChainShape] setPreviousVertex
-- @param self self 
-- @param #number x The x component of the vertex.
-- @param #number y The y component of the vertex.
-- 


-------------------------------------------------------------------------------
-- Circle extends Shape and adds a radius and a local position.
-- @type CircleShape
-- @extends love.physics#Shape
-- @extends love#Object

-------------------------------------------------------------------------------
-- Gets the center point of the circle shape.
-- @function[parent=#CircleShape] getPoint
-- @param self self 
-- @return #number x The x-component of the center point of the circle.
-- @return #number y The y-component of the center point of the circle.
-- 

-------------------------------------------------------------------------------
-- Gets the radius of the circle shape.
-- @function[parent=#CircleShape] getRadius
-- @param self self 
-- @return #number radius The radius of the circle.
-- 

-------------------------------------------------------------------------------
-- Sets the location of the center of the circle shape.
-- @function[parent=#CircleShape] setPoint
-- @param self self 
-- @param #number x The x-component of the new center point of the circle.
-- @param #number y The y-component of the new center point of the circle.
-- 

-------------------------------------------------------------------------------
-- Sets the radius of the circle.
-- @function[parent=#CircleShape] setRadius
-- @param self self 
-- @param #number radius The radius of the circle.
-- 


-------------------------------------------------------------------------------
-- Contacts are objects created to manage collisions in worlds.
-- @type Contact
-- @extends love#Object

-------------------------------------------------------------------------------
-- Gets the two Fixtures that hold the shapes that are in contact.
-- @function[parent=#Contact] getFixtures
-- @param self self 
-- @return love.physics#Fixture fixtureA The first Fixture.
-- @return love.physics#Fixture fixtureB The second Fixture.
-- 

-------------------------------------------------------------------------------
-- Get the friction between two shapes that are in contact.
-- @function[parent=#Contact] getFriction
-- @param self self 
-- @return #number friction The friction of the contact.
-- 

-------------------------------------------------------------------------------
-- Get the normal vector between two shapes that are in contact.
-- 
-- This function returns the coordinates of a unit vector that points from the first shape to the second.
-- @function[parent=#Contact] getNormal
-- @param self self 
-- @return #number nx The x component of the normal vector.
-- @return #number ny The y component of the normal vector.
-- 

-------------------------------------------------------------------------------
-- Returns the contact points of the two colliding fixtures. There can be one or two points.
-- @function[parent=#Contact] getPositions
-- @param self self 
-- @return #number x1 The x coordinate of the first contact point. 
-- @return #number y1 The y coordinate of the first contact point.
-- @return #number x2 The x coordinate of the second contact point.
-- @return #number y2 The y coordinate of the second contact point.
-- 

-------------------------------------------------------------------------------
-- Get the restitution between two shapes that are in contact.
-- @function[parent=#Contact] getRestitution
-- @param self self 
-- @return #number restitution The restitution between the two shapes.
-- 

-------------------------------------------------------------------------------
-- Returns whether the contact is enabled. The collision will be ignored if a contact gets disabled in the post solve callback.
-- @function[parent=#Contact] isEnabled
-- @param self self 
-- @return #boolean enabled True if enabled, false otherwise.
-- 

-------------------------------------------------------------------------------
-- Returns whether the two colliding fixtures are touching each other.
-- @function[parent=#Contact] isTouching
-- @param self self 
-- @return #boolean touching True if they touch or false if not.
-- 

-------------------------------------------------------------------------------
-- Resets the contact friction to the mixture value of both fixtures.
-- @function[parent=#Contact] resetFriction
-- @param self self 
-- 

-------------------------------------------------------------------------------
-- Resets the contact restitution to the mixture value of both fixtures.
-- @function[parent=#Contact] resetRestitution
-- @param self self 
-- 

-------------------------------------------------------------------------------
-- Enables or disables the contact.
-- @function[parent=#Contact] setEnabled
-- @param self self 
-- @param #boolean enabled True to enable or false to disable.
-- 

-------------------------------------------------------------------------------
-- Sets the contact friction.
-- @function[parent=#Contact] setFriction
-- @param self self 
-- @param #number friction The contact friction.
-- 

-------------------------------------------------------------------------------
-- Sets the contact restitution.
-- @function[parent=#Contact] setRestitution
-- @param self self 
-- @param #number restitution The contact restitution.
-- 


-------------------------------------------------------------------------------
-- A EdgeShape is a line segment. They can be used to create the boundaries of your terrain. The shape does not have volume and can only collide with PolygonShape and CircleShape.
-- @type EdgeShape
-- @extends love.physics#Shape
-- @extends love#Object

-------------------------------------------------------------------------------
-- Returns the local coordinates of the edge points.
-- @function[parent=#EdgeShape] getPoints
-- @param self self 
-- @return #number x1 The x component of the first vertex.
-- @return #number y1 The y component of the first vertex.
-- @return #number x2 The x component of the second vertex.
-- @return #number y2 The y component of the second vertex.
-- 


-------------------------------------------------------------------------------
-- Keeps two bodies at the same distance.
-- @type DistanceJoint
-- @extends love#Object
-- @extends love.physics#Joint

-------------------------------------------------------------------------------
-- Gets the damping ratio.
-- @function[parent=#DistanceJoint] getDampingRatio
-- @param self self 
-- @return #number ratio The damping ratio.
-- 

-------------------------------------------------------------------------------
-- Gets the response speed.
-- @function[parent=#DistanceJoint] getFrequency
-- @param self self 
-- @return #number Hz The response speed.
-- 

-------------------------------------------------------------------------------
-- Gets the equilibrium distance between the two Bodies.
-- @function[parent=#DistanceJoint] getLength
-- @param self self 
-- @return #number l The length between the two Bodies.
-- 

-------------------------------------------------------------------------------
-- Sets the damping ratio.
-- @function[parent=#DistanceJoint] setDampingRatio
-- @param self self 
-- @param #number ratio The damping ratio.
-- 

-------------------------------------------------------------------------------
-- Sets the response speed.
-- @function[parent=#DistanceJoint] setFrequency
-- @param self self 
-- @param #number Hz The response speed.
-- 

-------------------------------------------------------------------------------
-- Sets the equilibrium distance between the two Bodies.
-- @function[parent=#DistanceJoint] setLength
-- @param self self 
-- @param #number l The length between the two Bodies.
-- 


-------------------------------------------------------------------------------
-- Fixtures attach shapes to bodies.
-- @type Fixture
-- @extends love#Object

-------------------------------------------------------------------------------
-- Destroys the fixture
-- @function[parent=#Fixture] destroy
-- @param self self 
-- 

-------------------------------------------------------------------------------
-- Returns the body to which the fixture is attached.
-- @function[parent=#Fixture] getBody
-- @param self self 
-- @return love.physics#Body body The parent body.
-- 

-------------------------------------------------------------------------------
-- Returns the points of the fixture bounding box. In case the fixture has multiple children a 1-based index can be specified. For example, a fixture will have multiple children with a chain shape.
-- @function[parent=#Fixture] getBoundingBox
-- @param self self 
-- @param #number index A bounding box of the fixture.
-- @return #number topLeftX The x position of the top-left point.
-- @return #number topLeftY The y position of the top-left point.
-- @return #number bottomRightX The x position of the bottom-right point.
-- @return #number bottomRightY The y position of the bottom-right point.
-- 

-------------------------------------------------------------------------------
-- Returns the categories the fixture belongs to.
-- @function[parent=#Fixture] getCategory
-- @param self self 
-- @return #number category1 The first category.
-- @return #number category2 The second category.
-- @return #number ... Additional categories.
-- 

-------------------------------------------------------------------------------
-- Returns the density of the fixture.
-- @function[parent=#Fixture] getDensity
-- @param self self 
-- @return #number density The fixture density in kilograms per square meter.
-- 

-------------------------------------------------------------------------------
-- Returns the filter data of the fixture. Categories and masks are encoded as the bits of a 16-bit integer.
-- @function[parent=#Fixture] getFilterData
-- @param self self 
-- @return #number categories The categories as an integer from 0 to 65535.
-- @return #number mask The mask as an integer from 0 to 65535.
-- @return #number group The group as an integer from -32768 to 32767.
-- 

-------------------------------------------------------------------------------
-- Returns the friction of the fixture.
-- @function[parent=#Fixture] getFriction
-- @param self self 
-- @return #number friction The fixture friction.
-- 

-------------------------------------------------------------------------------
-- Returns the group the fixture belongs to. Fixtures with the same group will always collide if the group is positive or never collide if it's negative. The group zero means no group.
-- 
-- The groups range from -32768 to 32767.
-- @function[parent=#Fixture] getGroupIndex
-- @param self self 
-- @return #number group The group of the fixture.
-- 

-------------------------------------------------------------------------------
-- Returns the category mask of the fixture.
-- @function[parent=#Fixture] getMask
-- @param self self 
-- @return #number mask1 The first category selected by the mask.
-- @return #number mask2 The second category selected by the mask.
-- @return #number ... Additional categories selected by the mask.
-- 

-------------------------------------------------------------------------------
-- Returns the mass, its center and the rotational inertia.
-- @function[parent=#Fixture] getMassData
-- @param self self 
-- @return #number x The x position of the center of mass.
-- @return #number y The y position of the center of mass.
-- @return #number mass The mass of the fixture.
-- @return #number inertia The rotational inertia.
-- 

-------------------------------------------------------------------------------
-- Returns the restitution of the fixture.
-- @function[parent=#Fixture] getRestitution
-- @param self self 
-- @return #number restitution The fixture restitution.
-- 

-------------------------------------------------------------------------------
-- Returns the shape of the fixture. This shape is a reference to the actual data used in the simulation. It's possible to change its values between timesteps.
-- 
-- Do not call any functions on this shape after the parent fixture has been destroyed. This shape will point to an invalid memory address and likely cause crashes if you interact further with it.
-- @function[parent=#Fixture] getShape
-- @param self self 
-- @return love.physics#Shape shape The fixture's shape.
-- 

-------------------------------------------------------------------------------
-- Returns the Lua value associated with this fixture.
-- 
-- Use this function in one thread only.
-- @function[parent=#Fixture] getUserData
-- @param self self 
-- @return value The Lua value associated with the fixture.
-- 

-------------------------------------------------------------------------------
-- Gets whether the Fixture is destroyed. Destroyed fixtures cannot be used.
-- @function[parent=#Fixture] isDestroyed
-- @param self self 
-- @return #boolean destroyed Whether the Fixture is destroyed.
-- 

-------------------------------------------------------------------------------
-- Returns whether the fixture is a sensor.
-- @function[parent=#Fixture] isSensor
-- @param self self 
-- @return #boolean sensor If the fixture is a sensor.
-- 

-------------------------------------------------------------------------------
-- Casts a ray against the shape of the fixture and returns the surface normal vector and the line position where the ray hit. If the ray missed the shape, nil will be returned.
-- 
-- The ray starts on the first point of the input line and goes towards the second point of the line. The fourth argument is the maximum distance the ray is going to travel as a scale factor of the input line length.
-- 
-- The childIndex parameter is used to specify which child of a parent shape, such as a ChainShape, will be ray casted. For ChainShapes, the index of 1 is the first edge on the chain. Ray casting a parent shape will only test the child specified so if you want to test every shape of the parent, you must loop through all of its children.
-- 
-- The world position of the impact can be calculated by multiplying the line vector with the third return value and adding it to the line starting point.
-- 
-- hitx, hity = x1 + (x2 - x1) * fraction, y1 + (y2 - y1) * fraction
-- @function[parent=#Fixture] rayCast
-- @param self self 
-- @param #number x1 The x position of the ray starting point.
-- @param #number y1 The y position of the ray starting point.
-- @param #number x2 The x position of the ray end point.
-- @param #number y1 The y position of the ray end point.
-- @param #number maxFraction The maximum distance the ray is going to travel as a number from 0 to 1.
-- @param #number childIndex The index of the child the ray gets cast against.
-- @return #number x The x position where the ray intersects with the shape.
-- @return #number y The y position where the ray intersects with the shape.
-- @return #number fraction The position on the input vector where the intersection happened as a number from 0 to 1.
-- 

-------------------------------------------------------------------------------
-- Sets the categories the fixture belongs to. There can be up to 16 categories represented as a number from 1 to 16.
-- @function[parent=#Fixture] setCategory
-- @param self self 
-- @param #number category1 The first category.
-- @param #number category2 The second category.
-- @param #number ... Additional categories.
-- 

-------------------------------------------------------------------------------
-- Sets the density of the fixture. Call Body:resetMassData if this needs to take effect immediately.
-- @function[parent=#Fixture] setDensity
-- @param self self 
-- @param #number density The fixture density in kilograms per square meter.
-- 

-------------------------------------------------------------------------------
-- Sets the filter data of the fixture.
-- 
-- Groups, categories, and mask can be used to define the collision behaviour of the fixture.
-- 
-- If two fixtures are in the same group they either always collide if the group is positive, or never collide if it's negative. Is the group zero or they do not match, then the contact filter checks if the fixtures select a category of the other fixture with their masks. The fixtures do not collide if that's not the case. If they do have each others categories selected, the return value of the custom contact filter will be used. They always collide if none was set.
-- 
-- There can be up to 16 categories. Categories and masks are encoded as the bits of a 16-bit integer.
-- @function[parent=#Fixture] setFilterData
-- @param self self 
-- @param #number categories The categories as an integer from 0 to 65535.
-- @param #number mask The mask as an integer from 0 to 65535.
-- @param #number group The group as an integer from -32768 to 32767.
-- 

-------------------------------------------------------------------------------
-- Sets the friction of the fixture.
-- @function[parent=#Fixture] setFriction
-- @param self self 
-- @param #number friction The fixture friction.
-- 

-------------------------------------------------------------------------------
-- Sets the group the fixture belongs to. Fixtures with the same group will always collide if the group is positive or never collide if it's negative. The group zero means no group.
-- 
-- The groups range from -32768 to 32767.
-- @function[parent=#Fixture] setGroupIndex
-- @param self self 
-- @param #number group The group as an integer from -32768 to 32767.
-- 

-------------------------------------------------------------------------------
-- Sets the category mask of the fixture. There can be up to 16 categories represented as a number from 1 to 16.
-- 
-- This fixture will collide with the fixtures that are in the selected categories if the other fixture also has a category of this fixture selected.
-- @function[parent=#Fixture] setMask
-- @param self self 
-- @param #number mask1 The first category.
-- @param #number mask2 The second category.
-- @param #number ... Additional categories.
-- 

-------------------------------------------------------------------------------
-- Sets the restitution of the fixture.
-- @function[parent=#Fixture] setRestitution
-- @param self self 
-- @param #number restitution The fixture restitution.
-- 

-------------------------------------------------------------------------------
-- Sets whether the fixture should act as a sensor.
-- 
-- Sensor do not produce collisions responses, but the begin and end callbacks will still be called for this fixture.
-- @function[parent=#Fixture] setSensor
-- @param self self 
-- @param #boolean sensor The sensor status.
-- 

-------------------------------------------------------------------------------
-- Associates a Lua value with the fixture.
-- 
-- Use this function in one thread only.
-- @function[parent=#Fixture] setUserData
-- @param self self 
-- @param value The Lua value associated with the fixture.
-- 

-------------------------------------------------------------------------------
-- Checks if a point is inside the shape of the fixture.
-- @function[parent=#Fixture] testPoint
-- @param self self 
-- @param #number x The x position of the point.
-- @param #number y The y position of the point.
-- @return #boolean isInside True if the point is inside or false if it is outside.
-- 


-------------------------------------------------------------------------------
-- A FrictionJoint applies friction to a body.
-- @type FrictionJoint
-- @extends love#Object
-- @extends love.physics#Joint

-------------------------------------------------------------------------------
-- Gets the maximum friction force in Newtons.
-- @function[parent=#FrictionJoint] getMaxForce
-- @param self self 
-- @return #number force Maximum force in Newtons.
-- 

-------------------------------------------------------------------------------
-- Gets the maximum friction torque in Newton-meters.
-- @function[parent=#FrictionJoint] getMaxTorque
-- @param self self 
-- @return #number torque Maximum torque in Newton-meters.
-- 

-------------------------------------------------------------------------------
-- Sets the maximum friction force in Newtons.
-- @function[parent=#FrictionJoint] setMaxForce
-- @param self self 
-- @param #number maxForce Max force in Newtons.
-- 

-------------------------------------------------------------------------------
-- Sets the maximum friction torque in Newton-meters.
-- @function[parent=#FrictionJoint] setMaxTorque
-- @param self self 
-- @param #number torque Maximum torque in Newton-meters.
-- 


-------------------------------------------------------------------------------
-- Keeps bodies together in such a way that they act like gears.
-- @type GearJoint
-- @extends love#Object
-- @extends love.physics#Joint

-------------------------------------------------------------------------------
-- Get the Joints connected by this GearJoint.
-- @function[parent=#GearJoint] getJoints
-- @param self self 
-- @return love.physics#Joint joint1 The first connected Joint.
-- @return love.physics#Joint joint2 The second connected Joint.
-- 

-------------------------------------------------------------------------------
-- Get the ratio of a gear joint.
-- @function[parent=#GearJoint] getRatio
-- @param self self 
-- @return #number ratio The ratio of the joint.
-- 

-------------------------------------------------------------------------------
-- Set the ratio of a gear joint.
-- @function[parent=#GearJoint] setRatio
-- @param self self 
-- @param #number ratio The new ratio of the joint.
-- 


-------------------------------------------------------------------------------
-- Attach multiple bodies together to interact in unique ways.
-- @type Joint
-- @extends love#Object

-------------------------------------------------------------------------------
-- Explicitly destroys the Joint. When you don't have time to wait for garbage collection, this function may be used to free the object immediately, but note that an error will occur if you attempt to use the object after calling this function.
-- @function[parent=#Joint] destroy
-- @param self self 
-- 

-------------------------------------------------------------------------------
-- Get the anchor points of the joint.
-- @function[parent=#Joint] getAnchors
-- @param self self 
-- @return #number x1 The x component of the anchor on Body 1.
-- @return #number y1 The y component of the anchor on Body 1.
-- @return #number x2 The x component of the anchor on Body 2.
-- @return #number y2 The y component of the anchor on Body 2.
-- 

-------------------------------------------------------------------------------
-- Gets the bodies that the Joint is attached to.
-- @function[parent=#Joint] getBodies
-- @param self self 
-- @return love.physics#Body bodyA The first Body.
-- @return love.physics#Body bodyB The second Body.
-- 

-------------------------------------------------------------------------------
-- Gets whether the connected Bodies collide.
-- @function[parent=#Joint] getCollideConnected
-- @param self self 
-- @return #boolean c True if they collide, false otherwise.
-- 

-------------------------------------------------------------------------------
-- Gets the reaction force on Body 2 at the joint anchor.
-- @function[parent=#Joint] getReactionForce
-- @param self self 
-- @return #number x The x component of the force.
-- @return #number y The y component of the force.
-- 

-------------------------------------------------------------------------------
-- Returns the reaction torque on the second body.
-- @function[parent=#Joint] getReactionTorque
-- @param self self 
-- @param #number invdt How long the force applies. Usually the inverse time step or 1/dt.
-- @return #number torque The reaction torque on the second body.
-- 

-------------------------------------------------------------------------------
-- Gets an string representing the type.
-- @function[parent=#Joint] getType
-- @param self self 
-- @return love.physics#JointType type A string with the name of the Joint type.
-- 

-------------------------------------------------------------------------------
-- Returns the Lua value associated with this Joint.
-- @function[parent=#Joint] getUserData
-- @param self self 
-- @return value The Lua value associated with the Joint.
-- 

-------------------------------------------------------------------------------
-- Gets whether the Joint is destroyed. Destroyed joints cannot be used.
-- @function[parent=#Joint] isDestroyed
-- @param self self 
-- @return #boolean destroyed Whether the Joint is destroyed.
-- 

-------------------------------------------------------------------------------
-- Associates a Lua value with the Joint.
-- 
-- To delete the reference, explicitly pass nil.
-- @function[parent=#Joint] setUserData
-- @param self self 
-- @param value The Lua value to associate with the Joint.
-- 


-------------------------------------------------------------------------------
-- Controls the relative motion between two Bodies. Position and rotation offsets can be specified, as well as the maximum motor force and torque that will be be applied to reach the target offsets.
-- @type MotorJoint
-- @extends love#Object
-- @extends love.physics#Joint

-------------------------------------------------------------------------------
-- Gets the target angluar offset between the two Bodies the Joint is attached to.
-- @function[parent=#MotorJoint] getAngularOffset
-- @param self self 
-- @return #number angularoffset The target angular offset in radians: the second body's angle minus the first body's angle.
-- 

-------------------------------------------------------------------------------
-- Gets the target linear offset between the two Bodies the Joint is attached to.
-- @function[parent=#MotorJoint] getLinearOffset
-- @param self self 
-- @return #number x The x component of the target linear offset, relative to the first Body.
-- @return #number y The y component of the target linear offset, relative to the first Body.
-- 

-------------------------------------------------------------------------------
-- Sets the target angluar offset between the two Bodies the Joint is attached to.
-- @function[parent=#MotorJoint] setAngularOffset
-- @param self self 
-- @param #number angularoffset The target angular offset in radians: the second body's angle minus the first body's angle.
-- 

-------------------------------------------------------------------------------
-- Sets the target linear offset between the two Bodies the Joint is attached to.
-- @function[parent=#MotorJoint] setLinearOffset
-- @param self self 
-- @param #number x The x component of the target linear offset, relative to the first Body.
-- @param #number y The y component of the target linear offset, relative to the first Body.
-- 


-------------------------------------------------------------------------------
-- For controlling objects with the mouse.
-- @type MouseJoint
-- @extends love#Object
-- @extends love.physics#Joint

-------------------------------------------------------------------------------
-- Returns the damping ratio.
-- @function[parent=#MouseJoint] getDampingRatio
-- @param self self 
-- @return #number ratio The new damping ratio.
-- 

-------------------------------------------------------------------------------
-- Returns the frequency.
-- @function[parent=#MouseJoint] getFrequency
-- @param self self 
-- @return #number freq The frequency in hertz.
-- 

-------------------------------------------------------------------------------
-- Gets the highest allowed force.
-- @function[parent=#MouseJoint] getMaxForce
-- @param self self 
-- @return #number f The max allowed force.
-- 

-------------------------------------------------------------------------------
-- Gets the target point.
-- @function[parent=#MouseJoint] getTarget
-- @param self self 
-- @return #number x The x component of the target.
-- @return #number y The x component of the target.
-- 

-------------------------------------------------------------------------------
-- Sets a new damping ratio.
-- @function[parent=#MouseJoint] setDampingRatio
-- @param self self 
-- @param #number ratio The new damping ratio.
-- 

-------------------------------------------------------------------------------
-- Sets a new frequency.
-- @function[parent=#MouseJoint] setFrequency
-- @param self self 
-- @param #number freq The new frequency in hertz.
-- 

-------------------------------------------------------------------------------
-- Sets the highest allowed force.
-- @function[parent=#MouseJoint] setMaxForce
-- @param self self 
-- @param #number f The max allowed force.
-- 

-------------------------------------------------------------------------------
-- Sets the target point.
-- @function[parent=#MouseJoint] setTarget
-- @param self self 
-- @param #number x The x component of the target.
-- @param #number y The y component of the target.
-- 


-------------------------------------------------------------------------------
-- Polygon is a convex polygon with up to 8 sides.
-- @type PolygonShape
-- @extends love.physics#Shape
-- @extends love#Object

-------------------------------------------------------------------------------
-- Get the local coordinates of the polygon's vertices.
-- 
-- This function has a variable number of return values. It can be used in a nested fashion with love.graphics.polygon.
-- 
-- This function may have up to 16 return values, since it returns two values for each vertex in the polygon. In other words, it can return the coordinates of up to 8 points.
-- @function[parent=#PolygonShape] getPoints
-- @param self self 
-- @return #number x1 The x component of the first vertex.
-- @return #number y1 The y component of the first vertex.
-- @return #number x2 The x component of the second vertex.
-- @return #number y2 The y component of the second vertex.
-- @return #number ... Additional x and y values.
-- 


-------------------------------------------------------------------------------
-- Restricts relative motion between Bodies to one shared axis.
-- @type PrismaticJoint
-- @extends love#Object
-- @extends love.physics#Joint

-------------------------------------------------------------------------------
-- Enables or disables the limits of the joint.
-- @function[parent=#PrismaticJoint] setLimitsEnabled
-- @param self self 
-- @param #boolean enable True to enable, false to disable.
-- 

-------------------------------------------------------------------------------
-- Starts or stops the joint motor.
-- @function[parent=#PrismaticJoint] setMotorEnabled
-- @param self self 
-- @param #boolean enable True to enable, false to disable.
-- 

-------------------------------------------------------------------------------
-- Get the current joint angle speed.
-- @function[parent=#PrismaticJoint] getJointSpeed
-- @param self self 
-- @return #number s Joint angle speed in meters/second.
-- 

-------------------------------------------------------------------------------
-- Get the current joint translation.
-- @function[parent=#PrismaticJoint] getJointTranslation
-- @param self self 
-- @return #number t Joint translation, usually in meters.
-- 

-------------------------------------------------------------------------------
-- Gets the joint limits.
-- @function[parent=#PrismaticJoint] getLimits
-- @param self self 
-- @return #number lower The lower limit, usually in meters.
-- @return #number upper The upper limit, usually in meters.
-- 

-------------------------------------------------------------------------------
-- Gets the lower limit.
-- @function[parent=#PrismaticJoint] getLowerLimit
-- @param self self 
-- @return #number lower The lower limit, usually in meters.
-- 

-------------------------------------------------------------------------------
-- Gets the maximum motor force.
-- @function[parent=#PrismaticJoint] getMaxMotorForce
-- @param self self 
-- @return #number f The maximum motor force, usually in N.
-- 

-------------------------------------------------------------------------------
-- Get the current motor force.
-- @function[parent=#PrismaticJoint] getMotorForce
-- @param self self 
-- @return #number f The current motor force, usually in N.
-- 

-------------------------------------------------------------------------------
-- Gets the motor speed.
-- @function[parent=#PrismaticJoint] getMotorSpeed
-- @param self self 
-- @return #number s The motor speed, usually in meters per second.
-- 

-------------------------------------------------------------------------------
-- Gets the upper limit.
-- @function[parent=#PrismaticJoint] getUpperLimit
-- @param self self 
-- @return #number upper The upper limit, usually in meters.
-- 

-------------------------------------------------------------------------------
-- Checks whether the limits are enabled.
-- @function[parent=#PrismaticJoint] hasLimitsEnabled
-- @param self self 
-- @return #boolean enabled True if enabled, false otherwise.
-- 

-------------------------------------------------------------------------------
-- Checks whether the motor is enabled.
-- @function[parent=#PrismaticJoint] isMotorEnabled
-- @param self self 
-- @return #boolean enabled True if enabled, false if disabled.
-- 

-------------------------------------------------------------------------------
-- Sets the limits.
-- @function[parent=#PrismaticJoint] setLimits
-- @param self self 
-- @param #number lower The lower limit, usually in meters.
-- @param #number upper The upper limit, usually in meters.
-- 

-------------------------------------------------------------------------------
-- Sets the lower limit.
-- @function[parent=#PrismaticJoint] setLowerLimit
-- @param self self 
-- @param #number lower The lower limit, usually in meters.
-- 

-------------------------------------------------------------------------------
-- Set the maximum motor force.
-- @function[parent=#PrismaticJoint] setMaxMotorForce
-- @param self self 
-- @param #number f The maximum motor force, usually in N.
-- 

-------------------------------------------------------------------------------
-- Sets the motor speed.
-- @function[parent=#PrismaticJoint] setMotorSpeed
-- @param self self 
-- @param #number s The motor speed, usually in meters per second.
-- 

-------------------------------------------------------------------------------
-- Sets the upper limit.
-- @function[parent=#PrismaticJoint] setUpperLimit
-- @param self self 
-- @param #number upper The upper limit, usually in meters.
-- 


-------------------------------------------------------------------------------
-- Allows you to simulate bodies connected through pulleys.
-- @type PulleyJoint
-- @extends love#Object
-- @extends love.physics#Joint

-------------------------------------------------------------------------------
-- Get the total length of the rope.
-- @function[parent=#PulleyJoint] getConstant
-- @param self self 
-- @return #number length The length of the rope in the joint.
-- 

-------------------------------------------------------------------------------
-- Get the ground anchor positions in world coordinates.
-- @function[parent=#PulleyJoint] getGroundAnchors
-- @param self self 
-- @return #number a1x The x coordinate of the first anchor.
-- @return #number a1y The y coordinate of the first anchor.
-- @return #number a2x The x coordinate of the second anchor.
-- @return #number a2y The y coordinate of the second anchor.
-- 

-------------------------------------------------------------------------------
-- Get the current length of the rope segment attached to the first body.
-- @function[parent=#PulleyJoint] getLengthA
-- @param self self 
-- @return #number length The length of the rope segment.
-- 

-------------------------------------------------------------------------------
-- Get the current length of the rope segment attached to the second body.
-- @function[parent=#PulleyJoint] getLengthB
-- @param self self 
-- @return #number length The length of the rope segment.
-- 

-------------------------------------------------------------------------------
-- Get the maximum lengths of the rope segments.
-- @function[parent=#PulleyJoint] getMaxLengths
-- @param self self 
-- @return #number len1 The maximum length of the first rope segment.
-- @return #number len2 The maximum length of the second rope segment.
-- 

-------------------------------------------------------------------------------
-- Get the pulley ratio.
-- @function[parent=#PulleyJoint] getRatio
-- @param self self 
-- @return #number ratio The pulley ratio of the joint.
-- 

-------------------------------------------------------------------------------
-- Set the total length of the rope.
-- 
-- Setting a new length for the rope updates the maximum length values of the joint.
-- @function[parent=#PulleyJoint] setConstant
-- @param self self 
-- @param #number length The new length of the rope in the joint.
-- 

-------------------------------------------------------------------------------
-- Set the maximum lengths of the rope segments.
-- 
-- The physics module also imposes maximum values for the rope segments. If the parameters exceed these values, the maximum values are set instead of the requested values.
-- @function[parent=#PulleyJoint] setMaxLengths
-- @param self self 
-- @param #number max1 The new maximum length of the first segment.
-- @param #number max2 The new maximum length of the second segment.
-- 

-------------------------------------------------------------------------------
-- Set the pulley ratio.
-- @function[parent=#PulleyJoint] setRatio
-- @param self self 
-- @param #number ratio The new pulley ratio of the joint.
-- 


-------------------------------------------------------------------------------
-- Allow two Bodies to revolve around a shared point.
-- @type RevoluteJoint
-- @extends love#Object
-- @extends love.physics#Joint

-------------------------------------------------------------------------------
-- Enables or disables the joint limits.
-- @function[parent=#RevoluteJoint] setLimitsEnabled
-- @param self self 
-- @param #boolean enable True to enable, false to disable.
-- 

-------------------------------------------------------------------------------
-- Starts or stops the joint motor.
-- @function[parent=#RevoluteJoint] setMotorEnabled
-- @param self self 
-- @param #boolean enable True to enable, false to disable.
-- 

-------------------------------------------------------------------------------
-- Get the current joint angle.
-- @function[parent=#RevoluteJoint] getJointAngle
-- @param self self 
-- @return #number angle The joint angle in radians.
-- 

-------------------------------------------------------------------------------
-- Get the current joint angle speed.
-- @function[parent=#RevoluteJoint] getJointSpeed
-- @param self self 
-- @return #number s Joint angle speed in radians/second.
-- 

-------------------------------------------------------------------------------
-- Gets the joint limits.
-- @function[parent=#RevoluteJoint] getLimits
-- @param self self 
-- @return #number lower The lower limit, in radians.
-- @return #number upper The upper limit, in radians.
-- 

-------------------------------------------------------------------------------
-- Gets the lower limit.
-- @function[parent=#RevoluteJoint] getLowerLimit
-- @param self self 
-- @return #number lower The lower limit, in radians.
-- 

-------------------------------------------------------------------------------
-- Gets the maximum motor force.
-- @function[parent=#RevoluteJoint] getMaxMotorTorque
-- @param self self 
-- @return #number f The maximum motor force, in Nm.
-- 

-------------------------------------------------------------------------------
-- Gets the motor speed.
-- @function[parent=#RevoluteJoint] getMotorSpeed
-- @param self self 
-- @return #number s The motor speed, radians per second.
-- 

-------------------------------------------------------------------------------
-- Get the current motor force.
-- @function[parent=#RevoluteJoint] getMotorTorque
-- @param self self 
-- @return #number f The current motor force, in Nm.
-- 

-------------------------------------------------------------------------------
-- Gets the upper limit.
-- @function[parent=#RevoluteJoint] getUpperLimit
-- @param self self 
-- @return #number upper The upper limit, in radians.
-- 

-------------------------------------------------------------------------------
-- Checks whether limits are enabled.
-- @function[parent=#RevoluteJoint] hasLimitsEnabled
-- @param self self 
-- @return #boolean enabled True if enabled, false otherwise.
-- 

-------------------------------------------------------------------------------
-- Checks whether the motor is enabled.
-- @function[parent=#RevoluteJoint] isMotorEnabled
-- @param self self 
-- @return #boolean enabled True if enabled, false if disabled.
-- 

-------------------------------------------------------------------------------
-- Sets the limits.
-- @function[parent=#RevoluteJoint] setLimits
-- @param self self 
-- @param #number lower The lower limit, in radians.
-- @param #number upper The upper limit, in radians.
-- 

-------------------------------------------------------------------------------
-- Sets the lower limit.
-- @function[parent=#RevoluteJoint] setLowerLimit
-- @param self self 
-- @param #number lower The lower limit, in radians.
-- 

-------------------------------------------------------------------------------
-- Set the maximum motor force.
-- @function[parent=#RevoluteJoint] setMaxMotorTorque
-- @param self self 
-- @param #number f The maximum motor force, in Nm.
-- 

-------------------------------------------------------------------------------
-- Sets the motor speed.
-- @function[parent=#RevoluteJoint] setMotorSpeed
-- @param self self 
-- @param #number s The motor speed, radians per second.
-- 

-------------------------------------------------------------------------------
-- Sets the upper limit.
-- @function[parent=#RevoluteJoint] setUpperLimit
-- @param self self 
-- @param #number upper The upper limit, in radians.
-- 


-------------------------------------------------------------------------------
-- The RopeJoint enforces a maximum distance between two points on two bodies. It has no other effect.
-- @type RopeJoint
-- @extends love#Object
-- @extends love.physics#Joint

-------------------------------------------------------------------------------
-- Gets the maximum length of a RopeJoint.
-- @function[parent=#RopeJoint] getMaxLength
-- @param self self 
-- @return #number maxLength The maximum length of the RopeJoint.
-- 


-------------------------------------------------------------------------------
-- Shapes are solid 2d geometrical objects used in love.physics.
-- 
-- Shapes are attached to a Body via a Fixture. The Shape object is copied when this happens. Shape position is relative to Body position.
-- @type Shape
-- @extends love#Object

-------------------------------------------------------------------------------
-- Returns the points of the bounding box for the transformed shape.
-- @function[parent=#Shape] computeAABB
-- @param self self 
-- @param #number tx The translation of the shape on the x-axis.
-- @param #number ty The translation of the shape on the y-axis.
-- @param #number tr The shape rotation.
-- @param #number childIndex The index of the child to compute the bounding box of.
-- @return #number topLeftX The x position of the top-left point.
-- @return #number topLeftY The y position of the top-left point.
-- @return #number bottomRightX The x position of the bottom-right point.
-- @return #number bottomRightY The y position of the bottom-right point.
-- 

-------------------------------------------------------------------------------
-- Computes the mass properties for the shape with the specified density.
-- @function[parent=#Shape] computeMass
-- @param self self 
-- @param #number density The shape density.
-- @return #number x The x postition of the center of mass.
-- @return #number y The y postition of the center of mass.
-- @return #number mass The mass of the shape.
-- @return #number inertia The rotational inertia.
-- 

-------------------------------------------------------------------------------
-- Returns the number of children the shape has.
-- @function[parent=#Shape] getChildCount
-- @param self self 
-- @return #number count The number of children.
-- 

-------------------------------------------------------------------------------
-- Gets the radius of the shape.
-- @function[parent=#Shape] getRadius
-- @param self self 
-- @return #number radius The radius of the shape.
-- 

-------------------------------------------------------------------------------
-- Gets a string representing the Shape. This function can be useful for conditional debug drawing.
-- @function[parent=#Shape] getType
-- @param self self 
-- @return love.physics#ShapeType type The type of the Shape.
-- 

-------------------------------------------------------------------------------
-- Casts a ray against the shape and returns the surface normal vector and the line position where the ray hit. If the ray missed the shape, nil will be returned. The Shape can be transformed to get it into the desired position.
-- 
-- The ray starts on the first point of the input line and goes towards the second point of the line. The fourth argument is the maximum distance the ray is going to travel as a scale factor of the input line length.
-- 
-- The childIndex parameter is used to specify which child of a parent shape, such as a ChainShape, will be ray casted. For ChainShapes, the index of 1 is the first edge on the chain. Ray casting a parent shape will only test the child specified so if you want to test every shape of the parent, you must loop through all of its children.
-- 
-- The world position of the impact can be calculated by multiplying the line vector with the third return value and adding it to the line starting point.
-- 
-- hitx, hity = x1 + (x2 - x1) * fraction, y1 + (y2 - y1) * fraction
-- @function[parent=#Shape] rayCast
-- @param self self 
-- @param #number x1 The x position of the input line starting point.
-- @param #number y1 The y position of the input line starting point.
-- @param #number x2 The x position of the input line end point.
-- @param #number y2 The y position of the input line end point.
-- @param #number maxFraction Ray length parameter.
-- @param #number tx The translation of the shape on the x-axis.
-- @param #number ty The translation of the shape on the y-axis.
-- @param #number tr The shape rotation.
-- @param #number childIndex The index of the child the ray gets cast against.
-- @return #number xn The x component of the normal vector of the edge where the ray hit the shape.
-- @return #number yn The y component of the normal vector of the edge where the ray hit the shape.
-- @return #number fraction The position on the input line where the intersection happened as a factor of the line length.
-- 

-------------------------------------------------------------------------------
-- Checks whether a point lies inside the shape. This is particularly useful for mouse interaction with the shapes. By looping through all shapes and testing the mouse position with this function, we can find which shapes the mouse touches.
-- @function[parent=#Shape] testPoint
-- @param self self 
-- @param #number x The x component of the point.
-- @param #number y The y component of the point.
-- @return #boolean hit True if inside, false if outside
-- 


-------------------------------------------------------------------------------
-- A WeldJoint essentially glues two bodies together.
-- @type WeldJoint
-- @extends love#Object
-- @extends love.physics#Joint

-------------------------------------------------------------------------------
-- Returns the damping ratio of the joint.
-- @function[parent=#WeldJoint] getDampingRatio
-- @param self self 
-- @return #number ratio The damping ratio.
-- 

-------------------------------------------------------------------------------
-- Returns the frequency.
-- @function[parent=#WeldJoint] getFrequency
-- @param self self 
-- @return #number freq The frequency in hertz.
-- 

-------------------------------------------------------------------------------
-- The new damping ratio.
-- @function[parent=#WeldJoint] setDampingRatio
-- @param self self 
-- @param #number ratio The new damping ratio.
-- 

-------------------------------------------------------------------------------
-- Sets a new frequency.
-- @function[parent=#WeldJoint] setFrequency
-- @param self self 
-- @param #number freq The new frequency in hertz.
-- 


-------------------------------------------------------------------------------
-- Restricts a point on the second body to a line on the first body.
-- @type WheelJoint
-- @extends love#Object
-- @extends love.physics#Joint

-------------------------------------------------------------------------------
-- Returns the current joint translation speed.
-- @function[parent=#WheelJoint] getJointSpeed
-- @param self self 
-- @return #number speed The translation speed of the joint in meters per second.
-- 

-------------------------------------------------------------------------------
-- Returns the current joint translation.
-- @function[parent=#WheelJoint] getJointTranslation
-- @param self self 
-- @return #number position The translation of the joint in meters.
-- 

-------------------------------------------------------------------------------
-- Gets the joint limits.
-- @function[parent=#WheelJoint] getLimits
-- @param self self 
-- @return #number lower The lower limit, usually in meters.
-- @return #number upper The upper limit, usually in meters.
-- 

-------------------------------------------------------------------------------
-- Returns the maximum motor torque.
-- @function[parent=#WheelJoint] getMaxMotorTorque
-- @param self self 
-- @return #number maxTorque The maximum torque of the joint motor in newton meters.
-- 

-------------------------------------------------------------------------------
-- Returns the speed of the motor.
-- @function[parent=#WheelJoint] getMotorSpeed
-- @param self self 
-- @return #number speed The speed of the joint motor in radians per second.
-- 

-------------------------------------------------------------------------------
-- Returns the current torque on the motor.
-- @function[parent=#WheelJoint] getMotorTorque
-- @param self self 
-- @param #number invdt How long the force applies. Usually the inverse time step or 1/dt.
-- @return #number torque The torque on the motor in newton meters.
-- 

-------------------------------------------------------------------------------
-- Returns the damping ratio.
-- @function[parent=#WheelJoint] getSpringDampingRatio
-- @param self self 
-- @return #number ratio The damping ratio.
-- 

-------------------------------------------------------------------------------
-- Returns the spring frequency.
-- @function[parent=#WheelJoint] getSpringFrequency
-- @param self self 
-- @return #number freq The frequency in hertz.
-- 

-------------------------------------------------------------------------------
-- Sets a new maximum motor torque.
-- @function[parent=#WheelJoint] setMaxMotorTorque
-- @param self self 
-- @param #number maxTorque The new maximum torque for the joint motor in newton meters.
-- 

-------------------------------------------------------------------------------
-- Starts and stops the joint motor.
-- @function[parent=#WheelJoint] setMotorEnabled
-- @param self self 
-- @param #boolean enable True turns the motor on and false turns it off.
-- 

-------------------------------------------------------------------------------
-- Sets a new speed for the motor.
-- @function[parent=#WheelJoint] setMotorSpeed
-- @param self self 
-- @param #number speed The new speed for the joint motor in radians per second.
-- 

-------------------------------------------------------------------------------
-- Sets a new damping ratio.
-- @function[parent=#WheelJoint] setSpringDampingRatio
-- @param self self 
-- @param #number ratio The new damping ratio.
-- 

-------------------------------------------------------------------------------
-- Sets a new spring frequency.
-- @function[parent=#WheelJoint] setSpringFrequency
-- @param self self 
-- @param #number freq The new frequency in hertz.
-- 


-------------------------------------------------------------------------------
-- A world is an object that contains all bodies and joints.
-- @type World
-- @extends love#Object

-------------------------------------------------------------------------------
-- Destroys the world, taking all bodies, joints, fixtures and their shapes with it.
-- 
-- An error will occur if you attempt to use any of the destroyed objects after calling this function.
-- @function[parent=#World] destroy
-- @param self self 
-- 

-------------------------------------------------------------------------------
-- Get the number of bodies in the world.
-- @function[parent=#World] getBodyCount
-- @param self self 
-- @return #number n The number of bodies in the world.
-- 

-------------------------------------------------------------------------------
-- Returns a table with all bodies.
-- @function[parent=#World] getBodyList
-- @param self self 
-- @return #table bodies A sequence with all bodies.
-- 

-------------------------------------------------------------------------------
-- Returns functions for the callbacks during the world update.
-- @function[parent=#World] getCallbacks
-- @param self self 
-- @return beginContact Gets called when two fixtures begin to overlap.
-- @return endContact Gets called when two fixtures cease to overlap.
-- @return preSolve Gets called before a collision gets resolved.
-- @return postSolve Gets called after the collision has been resolved.
-- 

-------------------------------------------------------------------------------
-- Returns the number of contacts in the world.
-- @function[parent=#World] getContactCount
-- @param self self 
-- @return #number n The number of contacts in the world.
-- 

-------------------------------------------------------------------------------
-- Returns the function for collision filtering.
-- @function[parent=#World] getContactFilter
-- @param self self 
-- @return contactFilter The function that handles the contact filtering.
-- 

-------------------------------------------------------------------------------
-- Returns a table with all contacts.
-- @function[parent=#World] getContactList
-- @param self self 
-- @return #table contacts A sequence with all contacts.
-- 

-------------------------------------------------------------------------------
-- Get the gravity of the world.
-- @function[parent=#World] getGravity
-- @param self self 
-- @return #number x The x component of gravity.
-- @return #number y The y component of gravity.
-- 

-------------------------------------------------------------------------------
-- Get the number of joints in the world.
-- @function[parent=#World] getJointCount
-- @param self self 
-- @return #number n The number of joints in the world.
-- 

-------------------------------------------------------------------------------
-- Returns a table with all joints.
-- @function[parent=#World] getJointList
-- @param self self 
-- @return #table joints A sequence with all joints.
-- 

-------------------------------------------------------------------------------
-- Gets whether the World is destroyed. Destroyed worlds cannot be used.
-- @function[parent=#World] isDestroyed
-- @param self self 
-- @return #boolean destroyed Whether the World is destroyed.
-- 

-------------------------------------------------------------------------------
-- Returns if the world is updating its state.
-- 
-- This will return true inside the callbacks from World:setCallbacks.
-- @function[parent=#World] isLocked
-- @param self self 
-- @return #boolean locked Will be true if the world is in the process of updating its state.
-- 

-------------------------------------------------------------------------------
-- Returns the sleep behaviour of the world.
-- @function[parent=#World] isSleepingAllowed
-- @param self self 
-- @return #boolean allowSleep True if the bodies are allowed to sleep or false if not.
-- 

-------------------------------------------------------------------------------
-- Calls a function for each fixture inside the specified area.
-- @function[parent=#World] queryBoundingBox
-- @param self self 
-- @param #number topLeftX The x position of the top-left point.
-- @param #number topLeftY The y position of the top-left point.
-- @param #number bottomRightX The x position of the bottom-right point.
-- @param #number bottomRightY The y position of the bottom-right point.
-- @param callback This function gets passed one argument, the fixture, and should return a boolean. The search will continue if it is true or stop if it is false.
-- 

-------------------------------------------------------------------------------
-- Casts a ray and calls a function with the fixtures that intersect it. You cannot make any assumptions about the order of the callbacks.
-- 
-- Each time the function gets called, 6 arguments get passed to it. The first is the fixture intersecting the ray. The second and third are the coordinates of the intersection point. The fourth and fifth is the surface normal vector of the shape edge. The sixth argument is the position of the intersection on the ray as a number from 0 to 1 (or even higher if the ray length was changed with the return value).
-- 
-- The ray can be controlled with the return value. A positive value sets a new ray length where 1 is the default value. A value of 0 terminates the ray. If the callback function returns -1, the intersection gets ignored as if it didn't happen.
-- 
-- There is a bug in 0.8.0 where the normal vector passed to the callback function gets scaled by love.physics.getMeter.
-- @function[parent=#World] rayCast
-- @param self self 
-- @param #number x1 The x position of the starting point of the ray.
-- @param #number y1 The y position of the starting point of the ray.
-- @param #number x2 The x position of the end point of the ray.
-- @param #number y2 The y position of the end point of the ray.
-- @param callback This function gets six arguments and should return a number.
-- 

-------------------------------------------------------------------------------
-- Sets functions for the collision callbacks during the world update.
-- 
-- Four Lua functions can be given as arguments. The value nil removes a function.
-- 
-- When called, each function will be passed three arguments. The first two arguments are the colliding fixtures and the third argument is the Contact between them. The PostSolve callback additionally gets the normal and tangent impulse for each contact point.
-- @function[parent=#World] setCallbacks
-- @param self self 
-- @param beginContact Gets called when two fixtures begin to overlap. 
-- @param endContact Gets called when two fixtures cease to overlap.
-- @param preSolve Gets called before a collision gets resolved.
-- @param postSolve Gets called after the collision has been resolved.
-- 

-------------------------------------------------------------------------------
-- Sets a function for collision filtering.
-- 
-- If the group and category filtering doesn't generate a collision decision, this function gets called with the two fixtures as arguments. The function should return a boolean value where true means the fixtures will collide and false means they will pass through each other.
-- @function[parent=#World] setContactFilter
-- @param self self 
-- @param filter The function handling the contact filtering.
-- 

-------------------------------------------------------------------------------
-- Set the gravity of the world.
-- @function[parent=#World] setGravity
-- @param self self 
-- @param #number x The x component of gravity.
-- @param #number y The y component of gravity.
-- 

-------------------------------------------------------------------------------
-- Set the sleep behaviour of the world.
-- 
-- A sleeping body is much more efficient to simulate than when awake.
-- 
-- If sleeping is allowed, any body that has come to rest will sleep.
-- @function[parent=#World] setSleepingAllowed
-- @param self self 
-- @param #boolean allowSleep True if the bodies are allowed to sleep or false if not.
-- 

-------------------------------------------------------------------------------
-- Translates the World's origin. Useful in large worlds where floating point precision issues become noticeable at far distances from the origin.
-- @function[parent=#World] translateOrigin
-- @param self self 
-- @param #number x The x component of the new origin with respect to the old origin.
-- @param #number y The y component of the new origin with respect to the old origin.
-- 

-------------------------------------------------------------------------------
-- Update the state of the world.
-- @function[parent=#World] update
-- @param self self 
-- @param #number dt The time (in seconds) to advance the physics simulation.
-- 


-------------------------------------------------------------------------------
-- Returns the two closest points between two fixtures and their distance.
-- @function[parent=#love.physics] getDistance
-- @param love.physics#Fixture fixture1 The first fixture.
-- @param love.physics#Fixture fixture2 The second fixture.
-- @return #number distance The distance of the two points.
-- @return #number x1 The x-coordinate of the first point.
-- @return #number y1 The y-coordinate of the first point.
-- @return #number x2 The x-coordinate of the second point.
-- @return #number y2 The y-coordinate of the second point.
-- 

-------------------------------------------------------------------------------
-- Get the scale of the world.
-- 
-- The world scale is the number of pixels per meter. Try to keep your shape sizes less than 10 times this scale.
-- 
-- This is important because the physics in Box2D is tuned to work well for objects of size 0.1m up to 10m. All physics coordinates are divided by this number for the physics calculations.
-- @function[parent=#love.physics] getMeter
-- @return #number scale The size of 1 meter in pixels.
-- 

-------------------------------------------------------------------------------
-- Creates a new body.
-- 
-- There are three types of bodies. Static bodies do not move, have a infinite mass, and can be used for level boundaries. Dynamic bodies are the main actors in the simulation, they collide with everything. Kinematic bodies do not react to forces and only collide with dynamic bodies.
-- 
-- The mass of the body gets calculated when a Fixture is attached or removed, but can be changed at any time with Body:setMass or Body:resetMassData.
-- @function[parent=#love.physics] newBody
-- @param love.physics#World world The world to create the body in.
-- @param #number x The x position of the body.
-- @param #number y The y position of the body.
-- @param love.physics#BodyType type The type of the body.
-- @return love.physics#Body body A new body.
-- 

-------------------------------------------------------------------------------
-- Creates a new ChainShape.
-- @function[parent=#love.physics] newChainShape
-- @param #boolean loop If the chain should loop back to the first point.
-- @param #number x1 The x position of the first point.
-- @param #number y1 The y position of the first point.
-- @param #number x2 The x position of the second point.
-- @param #number y2 The y position of the second point.
-- @param #number ... Additional point positions.
-- @return love.physics#ChainShape shape The new shape.
-- 

-------------------------------------------------------------------------------
-- Creates a new ChainShape.
-- @function[parent=#love.physics] newChainShape
-- @param #boolean loop If the chain should loop back to the first point.
-- @param #table points A list of points to construct the ChainShape, in the form of {x1, y1, x2, y2, ...}.
-- @return love.physics#ChainShape shape The new shape.
-- 

-------------------------------------------------------------------------------
-- Creates a new CircleShape.
-- @function[parent=#love.physics] newCircleShape
-- @param #number radius The radius of the circle.
-- @return love.physics#CircleShape shape The new shape.
-- 

-------------------------------------------------------------------------------
-- Creates a new CircleShape.
-- @function[parent=#love.physics] newCircleShape
-- @param #number x The x offset of the circle.
-- @param #number y The y offset of the circle.
-- @param #number radius The radius of the circle.
-- @return love.physics#CircleShape shape The new shape.
-- 

-------------------------------------------------------------------------------
-- Create a distance joint between two bodies.
-- 
-- This joint constrains the distance between two points on two bodies to be constant. These two points are specified in world coordinates and the two bodies are assumed to be in place when this joint is created. The first anchor point is connected to the first body and the second to the second body, and the points define the length of the distance joint.
-- @function[parent=#love.physics] newDistanceJoint
-- @param love.physics#Body body1 The first body to attach to the joint.
-- @param love.physics#Body body2 The second body to attach to the joint.
-- @param #number x1 The x position of the first anchor point.
-- @param #number y1 The y position of the first anchor point.
-- @param #number x2 The x position of the second anchor point.
-- @param #number y2 The y position of the second anchor point.
-- @param #boolean collideConnected Specifies whether the two bodies should collide with each other.
-- @return love.physics#DistanceJoint joint The new distance joint.
-- 

-------------------------------------------------------------------------------
-- Creates a edge shape.
-- @function[parent=#love.physics] newEdgeShape
-- @param #number x1 The x position of the first point.
-- @param #number y1 The y position of the first point.
-- @param #number x2 The x position of the second point.
-- @param #number y2 The y position of the second point.
-- @return love.physics#EdgeShape shape The new shape.
-- 

-------------------------------------------------------------------------------
-- Creates and attaches a Fixture to a body.
-- @function[parent=#love.physics] newFixture
-- @param love.physics#Body body The body which gets the fixture attached.
-- @param love.physics#Shape shape The shape of the fixture.
-- @param #number density The density of the fixture.
-- @return love.physics#Fixture fixture The new fixture.
-- 

-------------------------------------------------------------------------------
-- Create a friction joint between two bodies. A FrictionJoint applies friction to a body.
-- @function[parent=#love.physics] newFrictionJoint
-- @param love.physics#Body body1 The first body to attach to the joint.
-- @param love.physics#Body body2 The second body to attach to the joint.
-- @param #number x The x position of the anchor point.
-- @param #number y The y position of the anchor point.
-- @param #boolean collideConnected Specifies whether the two bodies should collide with eachother.
-- @return love.physics#FrictionJoint joint The new FrictionJoint.
-- 

-------------------------------------------------------------------------------
-- Create a gear joint connecting two joints.
-- 
-- The gear joint connects two joints that must be either prismatic or revolute joints. Using this joint requires that the joints it uses connect their respective bodies to the ground and have the ground as the first body. When destroying the bodies and joints you must make sure you destroy the gear joint before the other joints.
-- 
-- The gear joint has a ratio the determines how the angular or distance values of the connected joints relate to each other. The formula coordinate1 + ratio * coordinate2 always has a constant value that is set when the gear joint is created.
-- @function[parent=#love.physics] newGearJoint
-- @param love.physics#Joint joint1 The first joint to connect with a gear joint.
-- @param love.physics#Joint joint2 The second joint to connect with a gear joint.
-- @param #number ratio The gear ratio.
-- @param #boolean collideConnected Specifies whether the two bodies should collide with each other.
-- @return love.physics#Joint joint The new gear joint.
-- 

-------------------------------------------------------------------------------
-- Creates a joint between two bodies which controls the relative motion between them.
-- 
-- Position and rotation offsets can be specified once the MotorJoint has been created, as well as the maximum motor force and torque that will be be applied to reach the target offsets.
-- @function[parent=#love.physics] newMotorJoint
-- @param love.physics#Body body1 The first body to attach to the joint.
-- @param love.physics#Body body2 The second body to attach to the joint.
-- @param #number correctionFactor The joint's initial position correction factor, in the range of [0, 1].
-- @return love.physics#MotorJoint joint The new MotorJoint.
-- 

-------------------------------------------------------------------------------
-- Creates a joint between two bodies which controls the relative motion between them.
-- 
-- Position and rotation offsets can be specified once the MotorJoint has been created, as well as the maximum motor force and torque that will be be applied to reach the target offsets.
-- @function[parent=#love.physics] newMotorJoint
-- @param love.physics#Body body1 The first body to attach to the joint.
-- @param love.physics#Body body2 The second body to attach to the joint.
-- @param #number correctionFactor The joint's initial position correction factor, in the range of [0, 1].
-- @param #boolean collideConnected Specifies whether the two bodies should collide with each other.
-- @return love.physics#MotorJoint joint The new MotorJoint.
-- 

-------------------------------------------------------------------------------
-- Create a joint between a body and the mouse.
-- 
-- This joint actually connects the body to a fixed point in the world. To make it follow the mouse, the fixed point must be updated every timestep (example below).
-- 
-- The advantage of using a MouseJoint instead of just changing a body position directly is that collisions and reactions to other joints are handled by the physics engine.
-- @function[parent=#love.physics] newMouseJoint
-- @param love.physics#Body body The body to attach to the mouse.
-- @param #number x The x position of the connecting point.
-- @param #number y The y position of the connecting point.
-- @return love.physics#Joint joint The new mouse joint.
-- 

-------------------------------------------------------------------------------
-- Creates a new PolygonShape.
-- 
-- This shape can have 8 vertices at most, and must form a convex shape.
-- @function[parent=#love.physics] newPolygonShape
-- @param #number x1 The position of first point on the x-axis.
-- @param #number y1 The position of first point on the y-axis.
-- @param #number x2 The position of second point on the x-axis.
-- @param #number y2 The position of second point on the y-axis.
-- @param #number ... You can continue passing more point positions to create the PolygonShape.
-- @return love.physics#PolygonShape shape A new PolygonShape.
-- 

-------------------------------------------------------------------------------
-- Creates a new PolygonShape.
-- 
-- This shape can have 8 vertices at most, and must form a convex shape.
-- @function[parent=#love.physics] newPolygonShape
-- @param #table vertices A list of vertices to construct the polygon, in the form of {x1, y1, x2, y2, x3, y3, ...}.
-- @return love.physics#PolygonShape shape A new PolygonShape.
-- 

-------------------------------------------------------------------------------
-- Create a prismatic joints between two bodies.
-- 
-- A prismatic joint constrains two bodies to move relatively to each other on a specified axis. It does not allow for relative rotation. Its definition and operation are similar to a revolute joint, but with translation and force substituted for angle and torque.
-- @function[parent=#love.physics] newPrismaticJoint
-- @param love.physics#Body body1 The first body to connect with a prismatic joint.
-- @param love.physics#Body body2 The second body to connect with a prismatic joint.
-- @param #number x The x coordinate of the anchor point.
-- @param #number y The y coordinate of the anchor point.
-- @param #number ax The x coordinate of the axis unit vector.
-- @param #number ay The y coordinate of the axis unit vector.
-- @param #boolean collideConnected Specifies whether the two bodies should collide with each other.
-- @return love.physics#PrismaticJoint joint The new prismatic joint.
-- 

-------------------------------------------------------------------------------
-- Create a prismatic joints between two bodies.
-- 
-- A prismatic joint constrains two bodies to move relatively to each other on a specified axis. It does not allow for relative rotation. Its definition and operation are similar to a revolute joint, but with translation and force substituted for angle and torque.
-- @function[parent=#love.physics] newPrismaticJoint
-- @param love.physics#Body body1 The first body to connect with a prismatic joint.
-- @param love.physics#Body body2 The second body to connect with a prismatic joint.
-- @param #number x1 The x coordinate of the first anchor point.
-- @param #number y1 The y coordinate of the first anchor point.
-- @param #number x2 The x coordinate of the second anchor point.
-- @param #number y2 The y coordinate of the second anchor point.
-- @param #number ax The x coordinate of the axis unit vector.
-- @param #number ay The y coordinate of the axis unit vector.
-- @param #boolean collideConnected Specifies whether the two bodies should collide with each other.
-- @return love.physics#PrismaticJoint joint The new prismatic joint.
-- 

-------------------------------------------------------------------------------
-- Create a pulley joint to join two bodies to each other and the ground.
-- 
-- The pulley joint simulates a pulley with an optional block and tackle. If the ratio parameter has a value different from one, then the simulated rope extends faster on one side than the other. In a pulley joint the total length of the simulated rope is the constant length1 + ratio * length2, which is set when the pulley joint is created.
-- 
-- Pulley joints can behave unpredictably if one side is fully extended. It is recommended that the method setMaxLengths  be used to constrain the maximum lengths each side can attain.
-- @function[parent=#love.physics] newPulleyJoint
-- @param love.physics#Body body1 The first body to connect with a pulley joint.
-- @param love.physics#Body body2 The second body to connect with a pulley joint.
-- @param #number gx1 The x coordinate of the first body's ground anchor.
-- @param #number gy1 The y coordinate of the first body's ground anchor.
-- @param #number gx2 The x coordinate of the second body's ground anchor.
-- @param #number gy2 The y coordinate of the second body's ground anchor.
-- @param #number x1 The x coordinate of the pulley joint anchor in the first body.
-- @param #number y1 The y coordinate of the pulley joint anchor in the first body.
-- @param #number x2 The x coordinate of the pulley joint anchor in the second body.
-- @param #number y2 The y coordinate of the pulley joint anchor in the second body.
-- @param #number ratio The joint ratio.
-- @param #boolean collideConnected Specifies whether the two bodies should collide with each other.
-- @return love.physics#Joint joint The new pulley joint.
-- 

-------------------------------------------------------------------------------
-- Shorthand for creating rectangluar PolygonShapes.
-- 
-- By default, the local origin is located at the center of the rectangle as opposed to the top left for graphics.
-- @function[parent=#love.physics] newRectangleShape
-- @param #number width The width of the rectangle.
-- @param #number height The height of the rectangle.
-- @return love.physics#PolygonShape shape A new PolygonShape.
-- 

-------------------------------------------------------------------------------
-- Shorthand for creating rectangluar PolygonShapes.
-- 
-- By default, the local origin is located at the center of the rectangle as opposed to the top left for graphics.
-- @function[parent=#love.physics] newRectangleShape
-- @param #number x The offset along the x-axis.
-- @param #number y The offset along the y-axis.
-- @param #number width The width of the rectangle.
-- @param #number height The height of the rectangle.
-- @param #number angle The initial angle of the rectangle.
-- @return love.physics#PolygonShape shape A new PolygonShape.
-- 

-------------------------------------------------------------------------------
-- Creates a pivot joint between two bodies.
-- 
-- This joint connects two bodies to a point around which they can pivot.
-- @function[parent=#love.physics] newRevoluteJoint
-- @param love.physics#Body body1 The first body to connect with a Revolute Joint.
-- @param love.physics#Body body2 The second body to connect with a Revolute Joint.
-- @param #number x The x position of the connecting point.
-- @param #number y The y position of the connecting point.
-- @param #number collideConnected Specifies whether the two bodies should collide with each other.
-- @return love.physics#Joint joint The new revolute joint.
-- 

-------------------------------------------------------------------------------
-- Create a joint between two bodies. Its only function is enforcing a max distance between these bodies.
-- @function[parent=#love.physics] newRopeJoint
-- @param love.physics#Body body1 The first body to attach to the joint.
-- @param love.physics#Body body2 The second body to attach to the joint.
-- @param #number x1 The x position of the first anchor point.
-- @param #number y1 The y position of the first anchor point.
-- @param #number x2 The x position of the second anchor point.
-- @param #number y2 The y position of the second anchor point.
-- @param #number maxLength The maximum distance for the bodies.
-- @param #boolean collideConnected Specifies whether the two bodies should collide with each other.
-- @return love.physics#RopeJoint joint The new RopeJoint.
-- 

-------------------------------------------------------------------------------
-- Create a friction joint between two bodies. A WeldJoint essentially glues two bodies together.
-- @function[parent=#love.physics] newWeldJoint
-- @param love.physics#Body body1 The first body to attach to the joint.
-- @param love.physics#Body body2 The second body to attach to the joint.
-- @param #number x The x position of the anchor point.
-- @param #number y The y position of the anchor point.
-- @param #boolean collideConnected Specifies whether the two bodies should collide with each other.
-- @return love.physics#WeldJoint joint The new WeldJoint.
-- 

-------------------------------------------------------------------------------
-- Creates a wheel joint.
-- @function[parent=#love.physics] newWheelJoint
-- @param love.physics#Body body1 The first body.
-- @param love.physics#Body body2 The second body.
-- @param #number x The x position of the anchor point.
-- @param #number y The y position of the anchor point.
-- @param #number ax The x position of the axis unit vector.
-- @param #number ay The y position of the axis unit vector.
-- @param #boolean collideConnected Specifies whether the two bodies should collide with each other.
-- @return love.physics#WheelJoint joint The new WheelJoint.
-- 

-------------------------------------------------------------------------------
-- Creates a new World.
-- @function[parent=#love.physics] newWorld
-- @param #number xg The x component of gravity.
-- @param #number yg The y component of gravity.
-- @param #boolean sleep Whether the bodies in this world are allowed to sleep.
-- @return love.physics#World world A brave new World.
-- 

-------------------------------------------------------------------------------
-- Sets the pixels to meter scale factor.
-- 
-- All coordinates in the physics module are divided by this number and converted to meters, and it creates a convenient way to draw the objects directly to the screen without the need for graphics transformations.
-- 
-- It is recommended to create shapes no larger than 10 times the scale. This is important because Box2D is tuned to work well with shape sizes from 0.1 to 10 meters. The default meter scale is 30.
-- 
-- love.physics.setMeter does not apply retroactively to created objects. Created objects retain their meter coordinates but the scale factor will affect their pixel coordinates.
-- @function[parent=#love.physics] setMeter
-- @param #number scale The scale factor as an integer.
-- 


return nil
