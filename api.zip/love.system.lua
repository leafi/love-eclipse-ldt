--------------------------------------------------------------------------------
-- Provides access to information about the user's system.
-- 
-- @module love.system
-- 

-------------------------------------------------------------------------------
-- Gets text from the clipboard.
-- @function[parent=#love.system] getClipboardText
-- @return #string text The text currently held in the system's clipboard.
-- 

-------------------------------------------------------------------------------
-- Gets the current operating system. In general, LÖVE abstracts away the need to know the current operating system, but there are a few cases where it can be useful (especially in combination with os.execute.)
-- @function[parent=#love.system] getOS
-- @return #string osString The current operating system. "OS X", "Windows", "Linux", "Android" or "iOS".
-- 

-------------------------------------------------------------------------------
-- Gets information about the system's power supply.
-- @function[parent=#love.system] getPowerInfo
-- @return love.system#PowerState state The basic state of the power supply.
-- @return #number percent Percentage of battery life left, between 0 and 100. nil if the value can't be determined or there's no battery.
-- @return #number seconds Seconds of battery life left. nil if the value can't be determined or there's no battery.
-- 

-------------------------------------------------------------------------------
-- Gets the amount of logical processor in the system.
-- @function[parent=#love.system] getProcessorCount
-- @return #number processorCount Amount of logical processors.
-- 

-------------------------------------------------------------------------------
-- Opens a URL with the user's web or file browser.
-- @function[parent=#love.system] openURL
-- @param #string url The URL to open. Must be formatted as a proper URL.
-- @return #boolean success Whether the URL was opened successfully.
-- 

-------------------------------------------------------------------------------
-- Puts text in the clipboard.
-- @function[parent=#love.system] setClipboardText
-- @param #string text The new text to hold in the system's clipboard.
-- 

-------------------------------------------------------------------------------
-- Causes the device to vibrate, if possible. Currently this will only work on Android and iOS devices that have a built-in vibration motor.
-- @function[parent=#love.system] vibrate
-- @param #number seconds The duration to vibrate for. If called on an iOS device, it will always vibrate for 0.5 seconds due to limitations in the iOS system APIs.
-- 


return nil
