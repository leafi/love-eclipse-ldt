--------------------------------------------------------------------------------
-- This module is responsible for decoding, controlling, and streaming video files.
-- 
-- It can't draw the videos, see love.graphics.newVideo and Video objects for that.
-- 
-- @module love.video
-- 

-------------------------------------------------------------------------------
-- An object which decodes, streams, and controls Videos.
-- @type VideoStream
-- @extends love#Object


-------------------------------------------------------------------------------
-- Creates a new VideoStream. Currently only Ogg Theora video files are supported. VideoStreams can't draw videos, see love.graphics.newVideo for that.
-- @function[parent=#love.video] newVideoStream
-- @param #string filename The file path to the Ogg Theora video file.
-- @return love.video#VideoStream videostream A new VideoStream.
-- 

-------------------------------------------------------------------------------
-- Creates a new VideoStream. Currently only Ogg Theora video files are supported. VideoStreams can't draw videos, see love.graphics.newVideo for that.
-- @function[parent=#love.video] newVideoStream
-- @param love.filesystem#File file The File object containing the Ogg Theora video.
-- @return love.video#VideoStream videostream A new VideoStream.
-- 


return nil
