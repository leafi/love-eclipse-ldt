---
-- Provides an interface to the user's mouse.
-- 
-- @module mouse
-- 

---
-- Gets the current Cursor.
-- @function [parent = #mouse] getCursor
-- @return mouse#Cursor cursor The current cursor, or nil if no cursor is set.
-- 

---
-- Returns the current position of the mouse.
-- @function [parent = #mouse] getPosition
-- @return #number x The position of the mouse along the x-axis.
-- @return #number y The position of the mouse along the y-axis.
-- 

---
-- Gets whether relative mode is enabled for the mouse.
-- 
-- If relative mode is enabled, the cursor is hidden and doesn't move when the mouse does, but relative mouse motion events are still generated via love.mousemoved. This lets the mouse move in any direction indefinitely without the cursor getting stuck at the edges of the screen.
-- 
-- The reported position of the mouse is not updated while relative mode is enabled, even when relative mouse motion events are generated.
-- @function [parent = #mouse] getRelativeMode
-- @return #boolean enabled True if relative mode is enabled, false if it's disabled.
-- 

---
-- Gets a Cursor object representing a system-native hardware cursor.
-- 
--  Hardware cursors are framerate-independent and work the same way as normal operating system cursors. Unlike drawing an image at the mouse's current coordinates, hardware cursors never have visible lag between when the mouse is moved and when the cursor position updates, even at low framerates.
-- @function [parent = #mouse] getSystemCursor
-- @param mouse#CursorType ctype The type of system cursor to get.
-- @return mouse#Cursor cursor The Cursor object representing the system cursor type.
-- 

---
-- Returns the current x position of the mouse.
-- @function [parent = #mouse] getX
-- @return #number x The position of the mouse along the x-axis.
-- 

---
-- Returns the current y position of the mouse.
-- @function [parent = #mouse] getY
-- @return #number y The position of the mouse along the y-axis.
-- 

---
-- Checks whether a certain mouse button is down. This function does not detect mousewheel scrolling; you must use the love.mousepressed callback for that.
-- @function [parent = #mouse] isDown
-- @param mouse#MouseConstant button The button to check.
-- @return #boolean down True if the specified button is down.
-- 

---
-- Checks if the mouse is grabbed.
-- @function [parent = #mouse] isGrabbed
-- @return #boolean grabbed True if the cursor is grabbed, false if it is not.
-- 

---
-- Checks if the cursor is visible.
-- @function [parent = #mouse] isVisible
-- @return #boolean visible True if the cursor to visible, false if the cursor is hidden.
-- 

---
-- Creates a new hardware Cursor object from an image file or ImageData.
-- 
-- Hardware cursors are framerate-independent and work the same way as normal operating system cursors. Unlike drawing an image at the mouse's current coordinates, hardware cursors never have visible lag between when the mouse is moved and when the cursor position updates, even at low frameratesn
-- 
-- The hot spot is the point the operating system uses to determine what was clicked and at what position the mouse cursor is. For example, the normal arrow pointer normally has its hot spot at the top left of the image, but a crosshair cursor might have it in the middle.
-- @function [parent = #mouse] newCursor
-- @param image#ImageData imageData The ImageData to use for the the new Cursor.
-- @param #number hotx The x-coordinate in the ImageData of the cursor's hot spot.
-- @param #number hoty The y-coordinate in the ImageData of the cursor's hot spot.
-- @return mouse#Cursor cursor The new Cursor object.
-- 

---
-- Sets the current mouse cursor.
-- 
-- Resets the current mouse cursor to the default when called without arguments.
-- @function [parent = #mouse] setCursor
-- 

---
-- Grabs the mouse and confines it to the window.
-- @function [parent = #mouse] setGrabbed
-- @param #boolean grab True to confine the mouse, false to let it leave the window.
-- 

---
-- Sets the position of the mouse.
-- @function [parent = #mouse] setPosition
-- @param #number x The new position of the mouse along the x-axis.
-- @param #number y The new position of the mouse along the y-axis.
-- 

---
-- Sets whether relative mode is enabled for the mouse.
-- 
-- When relative mode is enabled, the cursor is hidden and doesn't move when the mouse does, but relative mouse motion events are still generated via love.mousemoved. This lets the mouse move in any direction indefinitely without the cursor getting stuck at the edges of the screen.
-- 
-- The reported position of the mouse is not updated while relative mode is enabled, even when relative mouse motion events are generated.
-- @function [parent = #mouse] setRelativeMode
-- @param #boolean enable True to enable relative mode, false to disable it.
-- 

---
-- Sets the visibility of the cursor.
-- @function [parent = #mouse] setVisible
-- @param #boolean visible True to set the cursor to visible, false to hide the cursor.
-- 

---
-- Sets the current X position of the mouse.
-- @function [parent = #mouse] setX
-- @param #number x The new position of the mouse along the x-axis.
-- 

---
-- Sets the current Y position of the mouse.
-- @function [parent = #mouse] setY
-- @param #number y The new position of the mouse along the y-axis.
-- 


return nil
