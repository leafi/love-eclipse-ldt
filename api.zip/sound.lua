---
-- This module is responsible for decoding sound files. It can't play the sounds, see love.audio for that.
-- 
-- @module sound
-- 

---
-- Creates new SoundData from a file. It's also possible to create SoundData with a custom sample rate, channel and bit depth.
-- 
-- The sound data will be decoded to the memory in a raw format. It is recommended to create only short sounds like effects, as a 3 minute song uses 30 MB of memory this way.
-- @function [parent = #sound] newSoundData
-- @param #string filename The filename of the file to load.
-- @return sound#SoundData soundData A new SoundData object.
-- 


return nil
