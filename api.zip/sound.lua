--------------------------------------------------------------------------------
-- This module is responsible for decoding sound files. It can't play the sounds, see love.audio for that.
-- 
-- @module sound
-- 

-------------------------------------------------------------------------------
-- An object which can gradually decode a sound file.
-- @type Decoder
-- @extends love#Object

-------------------------------------------------------------------------------
-- Returns the number of bits per sample.
-- @function[parent=#Decoder] getBitDepth
-- @param self self 
-- @return #number bitDepth Either 8 or 16.
-- 

-------------------------------------------------------------------------------
-- Returns the number of channels in the stream.
-- @function[parent=#Decoder] getChannels
-- @param self self 
-- @return #number channels 1 for mono, 2 for stereo.
-- 

-------------------------------------------------------------------------------
-- Gets the duration of the sound file. It may not always be sample-accurate, and it may return -1 if the duration cannot be determined at all.
-- @function[parent=#Decoder] getDuration
-- @param self self 
-- @return #number duration The duration of the sound file in seconds, or -1 if it cannot be determined.
-- 

-------------------------------------------------------------------------------
-- Returns the sample rate of the Decoder.
-- @function[parent=#Decoder] getSampleRate
-- @param self self 
-- @return #number rate Number of samples per second.
-- 


-------------------------------------------------------------------------------
-- Contains raw audio samples. You can not play SoundData back directly. You must wrap a Source object around it.
-- @type SoundData
-- @extends love#Data
-- @extends love#Object

-------------------------------------------------------------------------------
-- Returns the number of bits per sample.
-- @function[parent=#SoundData] getBitDepth
-- @param self self 
-- @return #number bits Either 8 or 16.
-- 

-------------------------------------------------------------------------------
-- Returns the number of channels in the stream.
-- @function[parent=#SoundData] getChannels
-- @param self self 
-- @return #number channels 1 for mono, 2 for stereo.
-- 

-------------------------------------------------------------------------------
-- Returns the number of channels in the stream.
-- @function[parent=#SoundData] getDuration
-- @param self self 
-- @return #number duration The duration of the sound data in seconds.
-- 

-------------------------------------------------------------------------------
-- Gets the sample at the specified position.
-- @function[parent=#SoundData] getSample
-- @param self self 
-- @param #number i The position of the sample (0 means first sample).
-- @return #number sample The normalized sample (range -1.0 to 1.0).
-- 

-------------------------------------------------------------------------------
-- Returns the sample count of the SoundData.
-- @function[parent=#SoundData] getSampleCount
-- @param self self 
-- @return #number count Total number of samples.
-- 

-------------------------------------------------------------------------------
-- Returns the sample rate of the SoundData.
-- @function[parent=#SoundData] getSampleRate
-- @param self self 
-- @return #number rate Number of samples per second.
-- 

-------------------------------------------------------------------------------
-- Sets the sample at the specified position.
-- @function[parent=#SoundData] setSample
-- @param self self 
-- @param #number i The position of the sample (0 means first sample).
-- @param #number sample A normalized sample (range -1.0 to 1.0).
-- 


-------------------------------------------------------------------------------
-- Attempts to find a decoder for the encoded sound data in the specified file.
-- @function[parent=#sound] newDecoder
-- @param filesystem#File file The file with encoded sound data.
-- @param #number buffer The size of each decoded chunk, in bytes.
-- @return sound#Decoder decoder A new Decoder object.
-- 

-------------------------------------------------------------------------------
-- Attempts to find a decoder for the encoded sound data in the specified file.
-- @function[parent=#sound] newDecoder
-- @param #string filename The filename of the file with encoded sound data.
-- @param #number buffer The size of each decoded chunk, in bytes.
-- @return sound#Decoder decoder A new Decoder object.
-- 

-------------------------------------------------------------------------------
-- Creates new SoundData from a file. It's also possible to create SoundData with a custom sample rate, channel and bit depth.
-- 
-- The sound data will be decoded to the memory in a raw format. It is recommended to create only short sounds like effects, as a 3 minute song uses 30 MB of memory this way.
-- @function[parent=#sound] newSoundData
-- @param #string filename The filename of the file to load.
-- @return sound#SoundData soundData A new SoundData object.
-- 

-------------------------------------------------------------------------------
-- Creates new SoundData from a file. It's also possible to create SoundData with a custom sample rate, channel and bit depth.
-- 
-- The sound data will be decoded to the memory in a raw format. It is recommended to create only short sounds like effects, as a 3 minute song uses 30 MB of memory this way.
-- @function[parent=#sound] newSoundData
-- @param filesystem#File file A File pointing to an audio file.
-- @return sound#SoundData soundData A new SoundData object.
-- 

-------------------------------------------------------------------------------
-- Creates new SoundData from a file. It's also possible to create SoundData with a custom sample rate, channel and bit depth.
-- 
-- The sound data will be decoded to the memory in a raw format. It is recommended to create only short sounds like effects, as a 3 minute song uses 30 MB of memory this way.
-- @function[parent=#sound] newSoundData
-- @param love#Data data The encoded data to decode into audio.
-- @return sound#SoundData soundData A new SoundData object.
-- 

-------------------------------------------------------------------------------
-- Creates new SoundData from a file. It's also possible to create SoundData with a custom sample rate, channel and bit depth.
-- 
-- The sound data will be decoded to the memory in a raw format. It is recommended to create only short sounds like effects, as a 3 minute song uses 30 MB of memory this way.
-- @function[parent=#sound] newSoundData
-- @param #number samples Total number of samples.
-- @param #number rate Number of samples per second
-- @param #number bits Bits per sample (8 or 16).
-- @param #number channels Either 1 for mono or 2 for stereo.
-- @return sound#SoundData soundData A new SoundData object.
-- 


return nil
