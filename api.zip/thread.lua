---
-- Allows you to work with threads.
-- 
-- Threads are separate Lua environments, running in parallel to the main code. As their code runs separately, they can be used to compute complex operations without adversely affecting the frame rate of the main thread. However, as they are separate environments, they cannot access the variables and functions of the main thread, and communication between threads is limited.
-- 
-- All LOVE objects (userdata) are shared among threads so you'll only have to send their references across threads. You may run into concurrency issues if you manipulate an object on multiple threads at the same time.
-- 
-- When a Thread is started, it only loads the love.thread module. Every other module has to be loaded with require.
-- 
-- @module thread
-- 

---
-- A Thread is a chunk of code that can run in parallel with other threads.
-- 
-- Threads will place all Lua errors in "error". To retrieve the error, call Thread:get('error') in the main thread.
-- @type Thread
-- @extends love#Object

---
-- Retrieves the error string from the thread if it produced a error.
-- @function [parent = #Thread] getError
-- @param self self 
-- @return #string message The error message.
-- 

---
-- Starts the thread.
-- 
-- Threads can be restarted after they have completed their execution.
-- @function [parent = #Thread] start
-- @param self self 
-- 

---
-- Wait for a thread to finish. This call will block until the thread finishes.
-- @function [parent = #Thread] wait
-- @param self self 
-- 

---
-- Returns whether the thread is currently running.
-- 
-- Threads which are not running can be (re)started with Thread:start.
-- @function [parent = #Thread] isRunning
-- @param self self 
-- 


---
-- A channel is a way to send and receive data to and from different threads.
-- @type Channel
-- @extends love#Object

---
-- Clears all the messages in the Channel queue.
-- @function [parent = #Channel] clear
-- @param self self 
-- 

---
-- Retrieves the value of a Channel message and removes it from the message queue.
-- 
-- The value of the message can be a boolean, string, number, LÖVE userdata, or a simple flat table. It waits until a message is in the queue then returns the message value.
-- @function [parent = #Channel] demand
-- @param self self 
-- @return value The contents of the message.
-- 

---
-- Retrieves the number of messages in the thread Channel queue.
-- @function [parent = #Channel] getCount
-- @param self self 
-- @return #number count The number of messages in the queue.
-- 

---
-- Retrieves the value of a Channel message, but leaves it in the queue.
-- 
-- The value of the message can be a boolean, string, number or a LÖVE userdata. It returns nil if there's no message in the queue.
-- @function [parent = #Channel] peek
-- @param self self 
-- @return value The contents of the message.
-- 

---
-- Retrieves the value of a Channel message and removes it from the message queue.
-- 
-- The value of the message can be a boolean, string, number, LÖVE userdata, or a simple flat table. It returns nil if there are no messages in the queue.
-- @function [parent = #Channel] pop
-- @param self self 
-- @return value The contents of the message.
-- 

---
-- Send a message to the thread Channel.
-- 
-- The value of the message can be a boolean, string, number, LÖVE userdata, or a simple flat table. Foreign userdata (Lua's files, LuaSocket, ENet, ...), functions, and tables inside tables are not supported.
-- @function [parent = #Channel] push
-- @param self self 
-- @param value The contents of the message.
-- 

---
-- Send a message to the thread Channel and wait for a thread to accept it.
-- 
-- The value of the message can be a boolean, string, number, LÖVE userdata, or a simple flat table. Foreign userdata (Lua's files, LuaSocket, ENet, ...), functions, and tables inside tables are not supported.
-- @function [parent = #Channel] supply
-- @param self self 
-- @param value The contents of the message.
-- 


---
-- Creates or retrieves a named thread channel.
-- @function [parent = #thread] getChannel
-- @param #string name The name of the channel you want to create or retrieve.
-- @return thread#Channel channel A named channel object which can be further manipulated.
-- 

---
-- Create a new unnamed thread channel.
-- 
-- One use for them is to pass new unnamed channels to other threads via Channel:push
-- @function [parent = #thread] newChannel
-- @return thread#Channel channel A unnamed channel object which can be further manipulated.
-- 

---
-- Creates a new Thread from a File or Data object.
-- @function [parent = #thread] newThread
-- @param #string filename The name of the Lua File to use as source.
-- @return thread#Thread thread A new Thread that has yet to be started.
-- 


return nil
