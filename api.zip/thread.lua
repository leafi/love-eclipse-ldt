---
-- Allows you to work with threads.
-- 
-- Threads are separate Lua environments, running in parallel to the main code. As their code runs separately, they can be used to compute complex operations without adversely affecting the frame rate of the main thread. However, as they are separate environments, they cannot access the variables and functions of the main thread, and communication between threads is limited.
-- 
-- All LOVE objects (userdata) are shared among threads so you'll only have to send their references across threads. You may run into concurrency issues if you manipulate an object on multiple threads at the same time.
-- 
-- When a Thread is started, it only loads the love.thread module. Every other module has to be loaded with require.
-- 
-- @module thread
-- 

---
-- Creates or retrieves a named thread channel.
-- @function [parent = #thread] getChannel
-- @param #string name The name of the channel you want to create or retrieve.
-- @return thread#Channel channel A named channel object which can be further manipulated.
-- 

---
-- Create a new unnamed thread channel.
-- 
-- One use for them is to pass new unnamed channels to other threads via Channel:push
-- @function [parent = #thread] newChannel
-- @return thread#Channel channel A unnamed channel object which can be further manipulated.
-- 

---
-- Creates a new Thread from a File or Data object.
-- @function [parent = #thread] newThread
-- @param #string filename The name of the Lua File to use as source.
-- @return thread#Thread thread A new Thread that has yet to be started.
-- 


return nil
