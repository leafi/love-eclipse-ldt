--------------------------------------------------------------------------------
-- Provides an interface to touch-screen presses.
-- 
-- @module touch
-- 

-------------------------------------------------------------------------------
-- Gets the current position of the specified touch-press, in pixels.
-- @function[parent=#touch] getPosition
-- @param #table id The identifier of the touch-press. Use love.touch.getTouches, love.touchpressed, or love.touchmoved to obtain touch id values.
-- @return #number x The position along the x-axis of the touch-press inside the window, in pixels.
-- @return #number y The position along the y-axis of the touch-press inside the window, in pixels.
-- 

-------------------------------------------------------------------------------
-- Gets the current pressure of the specified touch-press.
-- @function[parent=#touch] getPressure
-- @param #table id The identifier of the touch-press. Use love.touch.getTouches, love.touchpressed, or love.touchmoved to obtain touch id values.
-- @return #number pressure The pressure of the touch-press. Most touch screens aren't pressure sensitive, in which case the pressure will be 1.
-- 

-------------------------------------------------------------------------------
-- Gets a list of all active touch-presses.
-- @function[parent=#touch] getTouches
-- @return #table touches A list of active touch-press id values, which can be used with love.touch.getPosition.
-- 


return nil
