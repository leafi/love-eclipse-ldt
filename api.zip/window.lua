--------------------------------------------------------------------------------
-- Provides an interface for modifying and retrieving information about the program's window.
-- 
-- @module window
-- 

-------------------------------------------------------------------------------
-- Closes the window. It can be reopened with love.window.setMode.
-- @function[parent=#window] close
-- 

-------------------------------------------------------------------------------
-- Converts a number from pixels to density-independent units.
-- 
-- The pixel density inside the window might be greater (or smaller) than the "size" of the window. For example on a retina screen in Mac OS X with the highdpi window flag enabled, the window may take up the same physical size as an 800x600 window, but the area inside the window uses 1600x1200 pixels. love.window.fromPixels(1600) would return 800 in that case.
-- 
-- This function converts coordinates from pixels to the size users are expecting them to display at onscreen. love.window.toPixels does the opposite. The highdpi window flag must be enabled to use the full pixel density of a Retina screen on Mac OS X and iOS. The flag currently does nothing on Windows and Linux, and on Android it is effectively always enabled.
-- 
-- Most LÖVE functions return values and expect arguments in terms of pixels rather than density-independent units.
-- @function[parent=#window] fromPixels
-- @param #number pixelvalue A number in pixels to convert to density-independent units.
-- @return #number value The converted number, in density-independent units.
-- 

-------------------------------------------------------------------------------
-- Converts a number from pixels to density-independent units.
-- 
-- The pixel density inside the window might be greater (or smaller) than the "size" of the window. For example on a retina screen in Mac OS X with the highdpi window flag enabled, the window may take up the same physical size as an 800x600 window, but the area inside the window uses 1600x1200 pixels. love.window.fromPixels(1600) would return 800 in that case.
-- 
-- This function converts coordinates from pixels to the size users are expecting them to display at onscreen. love.window.toPixels does the opposite. The highdpi window flag must be enabled to use the full pixel density of a Retina screen on Mac OS X and iOS. The flag currently does nothing on Windows and Linux, and on Android it is effectively always enabled.
-- 
-- Most LÖVE functions return values and expect arguments in terms of pixels rather than density-independent units.
-- @function[parent=#window] fromPixels
-- @param #number px The x-axis value of a coordinate in pixels.
-- @param #number py The y-axis value of a coordinate in pixels.
-- @return #number x The converted x-axis value of the coordinate, in density-independent units.
-- @return #number y The converted y-axis value of the coordinate, in density-independent units.
-- 

-------------------------------------------------------------------------------
-- Gets the name of a display.
-- @function[parent=#window] getDisplayName
-- @param #number displayindex The index of the display to get the name of.
-- @return #string name The name of the specified display.
-- 

-------------------------------------------------------------------------------
-- Gets whether the window is fullscreen.
-- @function[parent=#window] getFullscreen
-- @return #boolean fullscreen True if the window is fullscreen, false otherwise.
-- @return window#FullscreenType fstype The type of fullscreen mode used.
-- 

-------------------------------------------------------------------------------
-- Gets a list of supported fullscreen modes.
-- @function[parent=#window] getFullscreenModes
-- @param #number display The index of the display, if multiple monitors are available.
-- @return #table modes A table of width/height pairs. (Note that this may not be in order.)
-- 

-------------------------------------------------------------------------------
-- Gets the window icon.
-- @function[parent=#window] getIcon
-- @return image#ImageData imagedata The window icon imagedata, or nil of no icon has been set with love.window.setIcon.
-- 

-------------------------------------------------------------------------------
-- Returns the current display mode.
-- @function[parent=#window] getMode
-- @return #number width Window width.
-- @return #number height Window height.
-- @return #table flags Table containing the window properties.
-- 

-------------------------------------------------------------------------------
-- Gets the DPI scale factor associated with the window.
-- 
-- The pixel density inside the window might be greater (or smaller) than the "size" of the window. For example on a retina screen in Mac OS X with the highdpi window flag enabled, the window may take up the same physical size as an 800x600 window, but the area inside the window uses 1600x1200 pixels. love.window.getPixelScale() would return 2.0 in that case.
-- 
-- The love.window.fromPixels and love.window.toPixels functions can also be used to convert between units.
-- 
-- The highdpi window flag must be enabled to use the full pixel density of a Retina screen on Mac OS X and iOS. The flag currently does nothing on Windows and Linux, and on Android it is effectively always enabled.
-- @function[parent=#window] getPixelScale
-- @return #number scale The pixel scale factor associated with the window.
-- 

-------------------------------------------------------------------------------
-- Gets the position of the window on the screen.
-- 
-- The window position is in the coordinate space of the display it is currently in.
-- @function[parent=#window] getPosition
-- @return #number x The x-coordinate of the window's position.
-- @return #number y The y-coordinate of the window's position.
-- @return #number display The index of the display that the window is in.
-- 

-------------------------------------------------------------------------------
-- Gets the window title.
-- @function[parent=#window] getTitle
-- @return #string title The current window title.
-- 

-------------------------------------------------------------------------------
-- Checks if the game window has keyboard focus.
-- @function[parent=#window] hasFocus
-- @return #boolean focus True if the window has the focus or false if not.
-- 

-------------------------------------------------------------------------------
-- Checks if the game window has mouse focus.
-- @function[parent=#window] hasMouseFocus
-- @return #boolean focus True if the window has mouse focus or false if not.
-- 

-------------------------------------------------------------------------------
-- Checks if the window has been created.
-- @function[parent=#window] isCreated
-- @return #boolean created True if the window has been created, false otherwise.
-- 

-------------------------------------------------------------------------------
-- Gets whether the display is allowed to sleep while the program is running.
-- 
-- Display sleep is disabled by default. Some types of input (e.g. joystick button presses) might not prevent the display from sleeping, if display sleep is allowed.
-- @function[parent=#window] isDisplaySleepEnabled
-- @return #boolean enabled True if system display sleep is enabled / allowed, false otherwise.
-- 

-------------------------------------------------------------------------------
-- Checks if the game window is visible.
-- 
-- The window is considered visible if it's not minimized and the program isn't hidden.
-- @function[parent=#window] isVisible
-- @return #boolean visible True if the window is visible or false if not.
-- 

-------------------------------------------------------------------------------
-- Makes the window as large as possible.
-- 
-- This function has no effect if the window isn't resizable, since it essentially programmatically presses the window's "maximize" button.
-- @function[parent=#window] maximize
-- 

-------------------------------------------------------------------------------
-- Minimizes the window to the system's task bar / dock.
-- @function[parent=#window] minimize
-- 

-------------------------------------------------------------------------------
-- Causes the window to request the attention of the user if it is not in the foreground.
-- 
-- In Windows the taskbar icon will flash, and in OS X the dock icon will bounce.
-- @function[parent=#window] requestAttention
-- @param #boolean continuous Whether to continuously request attention until the window becomes active, or to do it only once.
-- 

-------------------------------------------------------------------------------
-- Sets whether the display is allowed to sleep while the program is running.
-- 
-- Display sleep is disabled by default. Some types of input (e.g. joystick button presses) might not prevent the display from sleeping, if display sleep is allowed.
-- @function[parent=#window] setDisplaySleepEnabled
-- @param #boolean enable True to enable system display sleep, false to disable it.
-- 

-------------------------------------------------------------------------------
-- Enters or exits fullscreen. The display to use when entering fullscreen is chosen based on which display the window is currently in, if multiple monitors are connected.
-- 
-- If fullscreen mode is entered and the window size doesn't match one of the monitor's display modes (in normal fullscreen mode) or the window size doesn't match the desktop size (in 'desktop' fullscreen mode), the window will be resized appropriately. The window will revert back to its original size again when fullscreen mode is exited using this function.
-- @function[parent=#window] setFullscreen
-- @param #boolean fullscreen Whether to enter or exit fullscreen mode.
-- @return #boolean success True if successful, false otherwise.
-- 

-------------------------------------------------------------------------------
-- Enters or exits fullscreen. The display to use when entering fullscreen is chosen based on which display the window is currently in, if multiple monitors are connected.
-- 
-- If fullscreen mode is entered and the window size doesn't match one of the monitor's display modes (in normal fullscreen mode) or the window size doesn't match the desktop size (in 'desktop' fullscreen mode), the window will be resized appropriately. The window will revert back to its original size again when fullscreen mode is exited using this function.
-- @function[parent=#window] setFullscreen
-- @param #boolean fullscreen Whether to enter or exit fullscreen mode.
-- @param window#FullscreenType fstype The type of fullscreen mode to use.
-- @return #boolean success True if successful, false otherwise.
-- 

-------------------------------------------------------------------------------
-- Sets the window icon until the game is quit. Not all operating systems support very large icon images.
-- @function[parent=#window] setIcon
-- @param image#ImageData imagedata The window icon image.
-- @return #boolean success Whether the icon has been set successfully.
-- 

-------------------------------------------------------------------------------
-- Sets the display mode and properties of the window.
-- 
-- If width or height is 0, setMode will use the width and height of the desktop.
-- 
-- Changing the display mode may have side effects: for example, canvases will be cleared and values sent to shaders with Shader:send will be erased. Make sure to save the contents of canvases beforehand or re-draw to them afterward if you need to.
-- @function[parent=#window] setMode
-- @param #number width Display width.
-- @param #number height Display height.
-- @param #table flags The flags table with the options:
-- @return #boolean success True if successful, false otherwise.
-- 

-------------------------------------------------------------------------------
-- Sets the position of the window on the screen.
-- 
-- The window position is in the coordinate space of the specified display.
-- @function[parent=#window] setPosition
-- @param #number x The x-coordinate of the window's position.
-- @param #number y The y-coordinate of the window's position.
-- @param #number display The index of the display that the new window position is relative to.
-- 

-------------------------------------------------------------------------------
-- Sets the window title.
-- @function[parent=#window] setTitle
-- @param #string title The new window title.
-- 

-------------------------------------------------------------------------------
-- Displays a message box dialog above the love window. The message box contains a title, optional text, and buttons.
-- @function[parent=#window] showMessageBox
-- @param #string title The title of the message box.
-- @param #string message The text inside the message box.
-- @param window#MessageBoxType type The type of the message box.
-- @param #boolean attachtowindow Whether the message box should be attached to the love window or free-floating.
-- @return #boolean success Whether the message box was successfully displayed.
-- 

-------------------------------------------------------------------------------
-- Displays a message box dialog above the love window. The message box contains a title, optional text, and buttons.
-- @function[parent=#window] showMessageBox
-- @param #string title The title of the message box.
-- @param #string message The text inside the message box.
-- @param #table buttonlist A table containing a list of button names to show. The table can also contain the fields enterbutton and escapebutton, which should be the index of the default button to use when the user presses 'enter' or 'escape', respectively.
-- @param window#MessageBoxType type The type of the message box.
-- @param #boolean attachtowindow Whether the message box should be attached to the love window or free-floating.
-- @return #number pressedbutton The index of the button pressed by the user. May be 0 if the message box dialog was closed without pressing a button.
-- 

-------------------------------------------------------------------------------
-- Converts a number from density-independent units to pixels.
-- 
-- The pixel density inside the window might be greater (or smaller) than the "size" of the window. For example on a retina screen in Mac OS X with the highdpi window flag enabled, the window may take up the same physical size as an 800x600 window, but the area inside the window uses 1600x1200 pixels. love.window.toPixels(800) would return 1600 in that case.
-- 
-- This is used to convert coordinates from the size users are expecting them to display at onscreen to pixels. love.window.fromPixels does the opposite. The highdpi window flag must be enabled to use the full pixel density of a Retina screen on Mac OS X and iOS. The flag currently does nothing on Windows and Linux, and on Android it is effectively always enabled.
-- 
-- Most LÖVE functions return values and expect arguments in terms of pixels rather than density-independent units.
-- @function[parent=#window] toPixels
-- @param #number value A number in density-independent units to convert to pixels.
-- @return #number pixelvalue The converted number, in pixels.
-- 

-------------------------------------------------------------------------------
-- Converts a number from density-independent units to pixels.
-- 
-- The pixel density inside the window might be greater (or smaller) than the "size" of the window. For example on a retina screen in Mac OS X with the highdpi window flag enabled, the window may take up the same physical size as an 800x600 window, but the area inside the window uses 1600x1200 pixels. love.window.toPixels(800) would return 1600 in that case.
-- 
-- This is used to convert coordinates from the size users are expecting them to display at onscreen to pixels. love.window.fromPixels does the opposite. The highdpi window flag must be enabled to use the full pixel density of a Retina screen on Mac OS X and iOS. The flag currently does nothing on Windows and Linux, and on Android it is effectively always enabled.
-- 
-- Most LÖVE functions return values and expect arguments in terms of pixels rather than density-independent units.
-- @function[parent=#window] toPixels
-- @param #number x The x-axis value of a coordinate in density-independent units to convert to pixels.
-- @param #number y The y-axis value of a coordinate in density-independent units to convert to pixels.
-- @return #number px The converted x-axis value of the coordinate, in pixels.
-- @return #number py The converted y-axis value of the coordinate, in pixels.
-- 


return nil
