---
-- The primary responsibility for the love.graphics module is the drawing of lines, shapes, text, Images and other Drawable objects onto the screen. Its secondary responsibilities include loading external files (including Images and Fonts) into memory, creating specialized objects (such as ParticleSystems or Framebuffers) and managing screen geometry.
-- 
-- LÖVE's coordinate system is rooted in the upper-left corner of the screen, which is at location (0, 0). The x-axis is horizontal: larger values are further to the right. The y-axis is vertical: larger values are further towards the bottom.
-- 
-- In many cases, you draw images or shapes in terms of their upper-left corner (See the picture above).
-- 
-- Many of the functions are used to manipulate the graphics coordinate system, which is essentially the way coordinates are mapped to the display. You can change the position, scale, and even rotation in this way.
-- 
-- @module window
-- 

---
-- Converts a number from pixels to density-independent units.
-- 
-- If the highdpi window flag is enabled in Mac OS X and the window is in a retina screen, density-independent units will be twice the size of pixels. Otherwise they will usually be the same. This function can be used to convert coordinates from pixels to the the size users are expecting them to display at onscreen. love.window.toPixels does the opposite.
-- 
-- Most LÖVE functions return values and expect arguments in terms of pixels rather than density-independent units.
-- @function [parent = #window] fromPixels
-- @param #number pixelvalue A number in pixels to convert to density-independent units.
-- @return #number value The converted number, in density-independent units.
-- 

---
-- Gets the width and height of the window.
-- @function [parent = #window] getDimensions
-- @return #number width The width of the window.
-- @return #number height The height of the window.
-- 

---
-- Gets the name of a display.
-- @function [parent = #window] getDisplayName
-- @param #number displayindex The index of the display to get the name of.
-- @return #string name The name of the specified display.
-- 

---
-- Gets whether the window is fullscreen.
-- @function [parent = #window] getFullscreen
-- @return #boolean fullscreen True if the window is fullscreen, false otherwise.
-- @return window#FullscreenType fstype The type of fullscreen mode used.
-- 

---
-- Gets a list of supported fullscreen modes.
-- @function [parent = #window] getFullscreenModes
-- @param #number display The index of the display, if multiple monitors are available.
-- @return #table modes A table of width/height pairs. (Note that this may not be in order.)
-- 

---
-- Gets the height of the window.
-- @function [parent = #window] getHeight
-- @return #number height The height of the window.
-- 

---
-- Gets the window icon.
-- @function [parent = #window] getIcon
-- @return image#ImageData imagedata The window icon imagedata, or nil of no icon has been set with love.window.setIcon.
-- 

---
-- Returns the current display mode.
-- @function [parent = #window] getMode
-- @return #number width Window width.
-- @return #number height Window height.
-- @return #table flags Table containing the window properties.
-- 

---
-- Gets the scale factor associated with the window. In Mac OS X with the window in a retina screen and the highdpi window flag enabled this will be 2.0, otherwise it will be 1.0.
-- 
-- The scale factor is used to display graphics at a size the user is expecting, rather than the size of the pixels. On retina displays with the highdpi window flag enabled, the pixels in the window are 2x smaller than the scale of the normal content on the screen, so love.window.getPixelScale will return 2.
-- 
-- The units of love.graphics.getWidth, love.graphics.getHeight, love.mouse.getPosition, and mouse events are always in terms of pixels.
-- @function [parent = #window] getPixelScale
-- @return #number scale The pixel scale factor associated with the window.
-- 

---
-- Gets the position of the window on the screen.
-- 
-- The window position is in the coordinate space of the display it is currently in.
-- @function [parent = #window] getPosition
-- @return #number x The x-coordinate of the window's position.
-- @return #number y The y-coordinate of the window's position.
-- @return #number display The index of the display that the window is in.
-- 

---
-- Gets the window title.
-- @function [parent = #window] getTitle
-- @return #string title The current window title.
-- 

---
-- Gets the width of the window.
-- @function [parent = #window] getWidth
-- @return #number width The width of the window.
-- 

---
-- Checks if the game window has keyboard focus.
-- @function [parent = #window] hasFocus
-- @return #boolean focus True if the window has the focus or false if not.
-- 

---
-- Checks if the game window has mouse focus.
-- @function [parent = #window] hasMouseFocus
-- @return #boolean focus True if the window has mouse focus or false if not.
-- 

---
-- Checks if the window has been created.
-- @function [parent = #window] isCreated
-- @return #boolean created True if the window has been created, false otherwise.
-- 

---
-- Checks if the game window is visible.
-- 
-- The window is considered visible if it's not minimized and the program isn't hidden.
-- @function [parent = #window] isVisible
-- @return #boolean visible True if the window is visible or false if not.
-- 

---
-- Minimizes the window to the system's task bar / dock.
-- @function [parent = #window] minimize
-- 

---
-- Enters or exits fullscreen. The display to use when entering fullscreen is chosen based on which display the window is currently in, if multiple monitors are connected.
-- 
-- If fullscreen mode is entered and the window size doesn't match one of the monitor's display modes (in normal fullscreen mode) or the window size doesn't match the desktop size (in 'desktop' fullscreen mode), the window will be resized appropriately. The window will revert back to its original size again when fullscreen mode is exited using this function.
-- @function [parent = #window] setFullscreen
-- @param #boolean fullscreen Whether to enter or exit fullscreen mode.
-- @return #boolean success True if successful, false otherwise.
-- 

---
-- Sets the window icon until the game is quit. Not all operating systems support very large icon images.
-- @function [parent = #window] setIcon
-- @param image#ImageData imagedata The window icon image.
-- @return #boolean success Whether the icon has been set successfully.
-- 

---
-- Changes the display mode.
-- 
-- If width or height is 0, the width or height of the desktop will be used.
-- @function [parent = #window] setMode
-- @param #number width Display width.
-- @param #number height Display height.
-- @param #table flags The flags table.
-- @return #boolean success True if successful, false otherwise.
-- 

---
-- Sets the position of the window on the screen.
-- 
-- The window position is in the coordinate space of the specified display.
-- @function [parent = #window] setPosition
-- @param #number x The x-coordinate of the window's position.
-- @param #number y The y-coordinate of the window's position.
-- @param #number display The index of the display that the new window position is relative to.
-- 

---
-- Sets the window title.
-- @function [parent = #window] setTitle
-- @param #string title The new window title.
-- 

---
-- Displays a message box dialog above the love window. The message box contains a title, optional text, and buttons.
-- @function [parent = #window] showMessageBox
-- @param #string title The title of the message box.
-- @param #string message The text inside the message box.
-- @param window#MessageBoxType type ("info") The type of the message box.
-- @param #boolean attachtowindow (true) Whether the message box should be attached to the love window or free-floating.
-- @return #boolean success Whether the message box was successfully displayed.
-- 

---
-- Converts a number from density-independent units to pixels.
-- 
-- If the highdpi window flag is enabled in Mac OS X and the window is in a retina screen, density-independent units will be twice the size of pixels. Otherwise they will usually be the same. This function can be used to convert coordinates from the size users are expecting them to display at onscreen to pixels. love.window.fromPixels does the opposite.
-- 
-- Most LÖVE functions return values and expect arguments in terms of pixels rather than density-independent units.
-- @function [parent = #window] toPixels
-- @param #number value A number in density-independent units to convert to pixels.
-- @return #number pixelvalue The converted number, in pixels.
-- 


return nil
